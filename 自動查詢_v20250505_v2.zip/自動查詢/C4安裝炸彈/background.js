const TARGET_URL = 'https://b9a9vnfik.becgame88168.com/index/Home';
let backgroundWindowId = null;

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'CREATE_BACKGROUND_WINDOW') {
        const { url = TARGET_URL, incognito = true } = message;

        const doCreate = () => {
            chrome.alarms.clear('BEC_INTERVAL');
            
            const windowConfig = {
                url,
                type: 'normal',
                state: 'minimized',
                focused: false,
                incognito
            };

            chrome.windows.create(windowConfig, (win) => {
                if (chrome.runtime.lastError || !win) {
                    sendResponse({ success: false, error: chrome.runtime.lastError?.message || 'Window creation failed' });
                    return;
                }
                if (incognito && !win.incognito) {
                    chrome.windows.remove(win.id, () => { void chrome.runtime.lastError; });
                    sendResponse({ success: false, error: 'INCOGNITO_DISABLED' });
                    return;
                }

                backgroundWindowId = win.id;
                const tabId = win.tabs[0].id;
                chrome.storage.local.set(
                    { targetTabId: tabId, bgWindowId: win.id },
                    () => {
                        if (win.tabs[0].status === 'complete') {
                            chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] }).catch(()=>{});
                        }
                        sendResponse({ success: true, tabId });
                    }
                );
            });
        };

        chrome.storage.local.get(['bgWindowId'], (data) => {
            const toClose = backgroundWindowId || data.bgWindowId;
            if (toClose) {
                chrome.windows.remove(toClose, () => {
                    void chrome.runtime.lastError;
                    backgroundWindowId = null;
                    doCreate();
                });
            } else {
                doCreate();
            }
        });
        return true;
    }

    if (message.action === 'CLOSE_BACKGROUND_WINDOW') {
        chrome.alarms.clear('BEC_INTERVAL');
        chrome.storage.local.get(['bgWindowId'], (data) => {
            const wid = backgroundWindowId || data.bgWindowId;
            if (wid) {
                chrome.windows.remove(wid, () => { void chrome.runtime.lastError; });
                backgroundWindowId = null;
                chrome.storage.local.remove(['bgWindowId', 'targetTabId']);
            }
            sendResponse({ success: true });
        });
        return true;
    }

    if (message.action === 'DEBUG_LOG') {
        chrome.storage.local.get(['debugLog'], (data) => {
            const log = data.debugLog || [];
            log.push(`[${new Date().toLocaleTimeString('en-US', { hour12: false })}] ${message.text}`);
            if (log.length > 40) log.shift();
            chrome.storage.local.set({ debugLog: log });
        });
        return false;
    }

    if (message.action === 'SHOW_ALERT') {
        chrome.notifications.create({
            type: 'basic',
            title: message.title,
            message: message.message,
            priority: 2,
            requireInteraction: true
        });
        return false;
    }

    if (message.action === 'START_INTERVAL') {
        chrome.alarms.create('BEC_INTERVAL', { delayInMinutes: message.minutes });
        chrome.storage.local.get(['bgWindowId'], (data) => {
            const wid = backgroundWindowId || data.bgWindowId;
            if (wid) {
                chrome.windows.remove(wid, () => { void chrome.runtime.lastError; });
                backgroundWindowId = null;
                chrome.storage.local.remove(['bgWindowId', 'targetTabId']);
            }
        });
        sendResponse({ success: true });
        return true;
    }
});

chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === 'BEC_INTERVAL') {
        chrome.storage.local.get(['isRunning', 'debugLog'], (data) => {
            if (data.isRunning) {
                const log = data.debugLog || [];
                log.push(`[${new Date().toLocaleTimeString('en-US', { hour12: false })}] System: Interval reached, next batch...`);
                if (log.length > 40) log.shift();

                chrome.storage.local.set({ 
                    currentIndex: 0, 
                    step: 'SEARCH', 
                    isWaiting: false, 
                    startUrl: TARGET_URL, 
                    debugLog: log 
                }, () => {
                    const windowConfig = {
                        url: TARGET_URL,
                        type: 'normal',
                        state: 'minimized',
                        focused: false,
                        incognito: true
                    };
                    chrome.windows.create(windowConfig, (win) => {
                        if (!chrome.runtime.lastError && win) {
                            backgroundWindowId = win.id;
                            const tabId = win.tabs[0].id;
                            chrome.storage.local.set({ targetTabId: tabId, bgWindowId: win.id }, () => {
                                if (win.tabs[0].status === 'complete') {
                                    chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] }).catch(()=>{});
                                }
                            });
                        }
                    });
                });
            }
        });
    }
});

chrome.windows.onRemoved.addListener((windowId) => {
    chrome.storage.local.get(['bgWindowId', 'isWaiting'], (data) => {
        if (data.bgWindowId === windowId || backgroundWindowId === windowId) {
            backgroundWindowId = null;
            chrome.storage.local.remove(['bgWindowId', 'targetTabId']);
            
            if (!data.isWaiting) {
                chrome.storage.local.set({ isRunning: false, isWaiting: false });
                chrome.alarms.clear('BEC_INTERVAL');
            }
        }
    });
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status !== 'complete') return;
    chrome.storage.local.get(['isRunning', 'targetTabId'], (data) => {
        if (!data.isRunning || data.targetTabId !== tabId) return;
        chrome.scripting.executeScript({
            target: { tabId },
            files: ['content.js']
        }).catch(() => {});
    });
});