const TARGET_URL = 'https://b9a9vnfik.becgame88168.com/index/Home';

document.addEventListener('DOMContentLoaded', () => {
    const startBtn      = document.getElementById('startBtn');
    const stopBtn       = document.getElementById('stopBtn');
    const logBtn        = document.getElementById('logBtn');
    const accountList   = document.getElementById('accountList');
    const resultBody    = document.getElementById('resultBody');
    const statusText    = document.getElementById('statusText');
    const debugPanel    = document.getElementById('debugPanel');
    const alertPanel    = document.getElementById('alertPanel');
    const incognitoNote = document.getElementById('incognitoNote');
    const logModal      = document.getElementById('logModal');
    const closeLogBtn   = document.getElementById('closeLogBtn');
    const delayDisplay  = document.getElementById('delayDisplay');
    const intervalBtns  = document.querySelectorAll('.int-btn');

    let selectedInterval = 0;

    intervalBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            intervalBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            selectedInterval = parseInt(btn.getAttribute('data-val'), 10);
        });
    });

    logBtn.addEventListener('click', () => logModal.style.display = 'block');
    closeLogBtn.addEventListener('click', () => logModal.style.display = 'none');
    window.addEventListener('click', (e) => {
        if (e.target === logModal) logModal.style.display = 'none';
    });

    const formatPayout = (valStr) => {
        if (!valStr || valStr === 'Not Found' || valStr === '—' || valStr === '查無資料' || valStr === 'No Data')
            return `<span style="color:#555">${valStr || '—'}</span>`;
        const num = parseFloat(valStr.replace(/,/g, ''));
        if (isNaN(num) || num === 0) return `<span style="color:#888">0</span>`;
        const fmt = Math.abs(num).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        return num > 0
            ? `<span style="color:var(--blue); font-weight:bold;">贏 ${fmt}</span>`
            : `<span style="color:var(--red); font-weight:bold;">輸 ${fmt}</span>`;
    };

    const updateUI = () => {
        chrome.storage.local.get(['results', 'isRunning', 'isWaiting', 'currentIndex', 'accounts', 'debugLog', 'adaptiveDelay'], (data) => {
            if (data.isRunning && data.adaptiveDelay) {
                delayDisplay.innerText = `${data.adaptiveDelay} ms`;
            } else if (!data.isRunning) {
                delayDisplay.innerText = `800 ms`;
            }

            resultBody.innerHTML = '';
            let alertsHTML = '';
            
            (data.results || []).forEach(res => {
                const tr = document.createElement('tr');
                if (res.exceeded) tr.className = 'exceeded';
                
                const balColor = res.balance?.startsWith('Error') || res.balance?.startsWith('錯誤') ? 'color:var(--red)' : 'color:#ccc';
                tr.innerHTML = `
                    <td style="color:var(--dim)">#${res.id}</td>
                    <td>${res.account}</td>
                    <td style="${balColor}">${res.balance}</td>
                    <td>${formatPayout(res.payout)}</td>
                    <td style="color:var(--dim); font-size:11px; text-align:right;">${res.time || '-'}</td>`;
                resultBody.appendChild(tr);

                if (res.exceeded) {
                    alertsHTML += `<div class="alert-item">⚠️ ${res.account}: ${res.payout}</div>`;
                }
            });

            if (alertsHTML) {
                alertPanel.innerHTML = alertsHTML;
                alertPanel.style.display = 'block';
            } else {
                alertPanel.style.display = 'none';
                alertPanel.innerHTML = '';
            }

            debugPanel.innerHTML = '';
            (data.debugLog || []).forEach(line => {
                const div = document.createElement('div');
                const isErr  = line.toLowerCase().includes('error') || line.includes('錯誤');
                const isWarn = line.toLowerCase().includes('warning') || line.includes('警告') || line.includes('alert');
                div.className = isErr ? 'err' : isWarn ? 'warn' : 'info';
                div.textContent = line;
                debugPanel.appendChild(div);
            });
            debugPanel.scrollTop = debugPanel.scrollHeight;

            if (data.isRunning) {
                if (data.isWaiting) {
                    statusText.innerHTML = `<span style="color:var(--blue)">Waiting</span> | Done`;
                } else {
                    statusText.innerHTML = `<span style="color:var(--green)">Running</span> | ${(data.currentIndex || 0) + 1} / ${data.accounts?.length || 0}`;
                }
                startBtn.disabled  = true;
                stopBtn.disabled = false;
            } else {
                statusText.innerHTML = `<span style="color:var(--dim)">Standby</span> | ${(data.results || []).length}`;
                startBtn.disabled  = false;
                stopBtn.disabled = true;
            }
        });
    };

    updateUI();
    setInterval(updateUI, 800);

    startBtn.addEventListener('click', () => {
        const rawLines = accountList.value.split('\n').filter(line => line.trim() !== '');
        if (!rawLines.length) return;

        const accounts = [];
        for (const line of rawLines) {
            const parts = line.split(',');
            if (parts.length >= 2) {
                const accName = parts[0].trim();
                const limitVal = parseFloat(parts[1].trim());
                const dateVal = parts.length >= 3 ? parts[2].trim() : '0';
                
                accounts.push({
                    name: accName,
                    limit: isNaN(limitVal) ? null : limitVal * 10000,
                    date: dateVal
                });
            }
        }

        if (!accounts.length) return;

        startBtn.disabled = true;
        statusText.innerHTML = `<span style="color:var(--yellow)">Init...</span>`;
        incognitoNote.classList.remove('show');

        chrome.storage.local.set({
            accounts,
            currentIndex: 0,
            adaptiveDelay: 800,
            intervalMin: selectedInterval,
            isRunning: true,
            isWaiting: false,
            step: 'SEARCH',
            startUrl: TARGET_URL,
            results: [],
            debugLog: []
        }, () => {
            chrome.runtime.sendMessage(
                { action: 'CREATE_BACKGROUND_WINDOW', url: TARGET_URL, incognito: true, foreground: false },
                (resp) => {
                    if (resp?.success) {
                        updateUI();
                    } else {
                        chrome.storage.local.set({ isRunning: false, isWaiting: false });
                        if (resp?.error === 'INCOGNITO_DISABLED') {
                            incognitoNote.classList.add('show');
                            statusText.innerHTML = `<span style="color:var(--red)">Incognito Disabled</span>`;
                        } else {
                            statusText.innerHTML = `<span style="color:var(--red)">Error: ${resp?.error || 'Unknown'}</span>`;
                        }
                        startBtn.disabled = false;
                        stopBtn.disabled = true;
                    }
                }
            );
        });
    });

    stopBtn.addEventListener('click', () => {
        chrome.storage.local.set({ isRunning: false, isWaiting: false }, () => {
            chrome.runtime.sendMessage({ action: 'CLOSE_BACKGROUND_WINDOW' }, updateUI);
        });
    });
});