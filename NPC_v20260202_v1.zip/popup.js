document.addEventListener('DOMContentLoaded', () => {
    // --- 導覽切換 ---
    const navBtns = document.querySelectorAll('.nav-btn');
    const tabPanes = document.querySelectorAll('.tab-pane');

    navBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            navBtns.forEach(b => b.classList.remove('active'));
            tabPanes.forEach(p => p.classList.remove('active'));
            btn.classList.add('active');
            document.getElementById(btn.dataset.target).classList.add('active');
        });
    });

    // --- 複製功能 (含 Fallback) ---
    function copyToClipboard(text) {
        if (!text) return;
        const cleanText = text.toString().trim();
        if (cleanText === "") return;

        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(cleanText).then(() => {
                showToast();
            }).catch(err => {
                fallbackCopyTextSelection(cleanText);
            });
        } else {
            fallbackCopyTextSelection(cleanText);
        }
    }

    function fallbackCopyTextSelection(text) {
        const textArea = document.createElement("textarea");
        textArea.value = text;
        textArea.style.position = "fixed";
        textArea.style.left = "-9999px";
        textArea.style.top = "0";
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        try {
            document.execCommand('copy');
            showToast();
        } catch (err) {}
        document.body.removeChild(textArea);
    }

    function showToast() {
        const toast = document.getElementById('toast');
        toast.classList.add('show');
        setTimeout(() => { toast.classList.remove('show'); }, 1500);
    }

    // --- 按鈕監聽 ---
    document.getElementById('btn-copy-dep-combined').addEventListener('click', () => {
        const no = document.getElementById('dep-no').value;
        const acc = document.getElementById('dep-acc').value;
        const amt = document.getElementById('dep-amt').value;
        if(no && acc && amt) copyToClipboard(`${no}\t${acc}\t${amt}`);
    });

    document.getElementById('btn-copy-dep-time-only').addEventListener('click', () => {
        const time = document.getElementById('dep-time').value;
        if(time) copyToClipboard(time);
    });

    document.getElementById('btn-copy-wd-full-combined').addEventListener('click', () => {
        const no = document.getElementById('wd-no').value;
        const acc = document.getElementById('wd-acc').value;
        const amt = document.getElementById('wd-amt').value;
        const today = new Date().toISOString().split('T')[0].replace(/-/g, '/');
        if(no && acc && amt) copyToClipboard(`${today}\t出款\t${no}\t${acc}\t\t${amt}`);
    });

    // --- 資料讀取 ---
    async function handleFetch(statusId, type) {
        const statusEl = document.getElementById(statusId);
        statusEl.textContent = "SCANNING...";
        statusEl.classList.add('rgb-text-flow'); 

        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            chrome.scripting.executeScript({
                target: { tabId: tab.id },
                func: grabPageData,
                args: [type]
            }, (results) => {
                statusEl.classList.remove('rgb-text-flow');
                if (results && results[0].result) {
                    const data = results[0].result;
                    if(type === 'deposit') {
                        document.getElementById('dep-no').value = data.no || '';
                        document.getElementById('dep-acc').value = data.acc || '';
                        document.getElementById('dep-amt').value = data.amt || '';
                        document.getElementById('dep-time').value = data.time || '';
                    } else {
                        document.getElementById('wd-no').value = data.no || '';
                        document.getElementById('wd-acc').value = data.acc || '';
                        document.getElementById('wd-amt').value = data.amt || '';
                    }
                    statusEl.textContent = "DATA LOCKED";
                    statusEl.style.color = "#ffb347"; // 配合暖色系，成功狀態改為溫暖的金色
                } else {
                    statusEl.textContent = "FETCH FAILED";
                    statusEl.style.color = "#ff4d4d"; // 配合暖色系，失敗狀態改為柔和紅
                }
            });
        } catch (e) {
            statusEl.textContent = "ERROR";
        }
    }

    function grabPageData(type) {
        const allTDs = Array.from(document.querySelectorAll('td'));
        const getValue = (labels) => {
            const target = allTDs.find(td => labels.some(l => td.innerText.replace(/\s/g, '').includes(l)));
            if (target && target.nextElementSibling) return target.nextElementSibling.innerText.trim();
            if (target) {
                const parts = target.innerText.split(/[:：]/);
                if (parts.length > 1) return parts[1].trim();
            }
            return '';
        };

        if(type === 'deposit') {
            return {
                acc: getValue(['會員帳號']),
                no: getValue(['存款單號']),
                amt: getValue(['金額', '實際金額']).replace(/[^0-9.]/g, ''),
                time: getValue(['存款時間'])
            };
        } else {
            return {
                acc: getValue(['會員帳號']),
                no: getValue(['提款單號']),
                amt: getValue(['金額', '實際金額']).replace(/[^0-9.]/g, '')
            };
        }
    }

    document.getElementById('btn-fetch-deposit').addEventListener('click', () => handleFetch('dep-status', 'deposit'));
    document.getElementById('btn-fetch-withdraw').addEventListener('click', () => handleFetch('wd-status', 'withdraw'));
});