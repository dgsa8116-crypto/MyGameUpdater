const TARGET_URL = 'https://b9a9vnfik.becgame88168.com/index/Home';
let backgroundWindowId = null;
let pumpInFlight = false;
const AUTO_WATCHDOG_ALARM = 'BEC_WATCHDOG';
const AUTO_TASK_TIMEOUT_MS = 180000;
const AUTO_ORPHAN_WINDOW_TIMEOUT_MS = 90000;
const AUTO_TASK_MAX_RETRIES = 2;
const TRC_MONITOR_ALARM = 'BEC_TRC_MONITOR';
const DEFAULT_TRC_ADDRESS = 'TDnznHwt1BVDDZfYScLksF1pi92K2MkoqU';
const DEFAULT_TRC_USDT_CONTRACT = 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t';

const storageGet = (keys) => new Promise(resolve => chrome.storage.local.get(keys, resolve));
const storageSet = (obj) => new Promise(resolve => chrome.storage.local.set(obj, resolve));
const storageRemove = (keys) => new Promise(resolve => chrome.storage.local.remove(keys, resolve));
const accountKey = (name) => String(name || '').trim().toLowerCase();
const normalizePoolId = (raw) => String(raw || '').trim().toUpperCase().replace(/\s+/g, '-');
const isBecGameUrl = (url) => {
    try {
        const hostname = new URL(url || '').hostname.toLowerCase();
        return hostname === 'becgame88168.com' || hostname.endsWith('.becgame88168.com');
    } catch (error) {
        return false;
    }
};

const closeWindowQuiet = (id) => {
    if (!id) return;
    chrome.windows.remove(id, () => { void chrome.runtime.lastError; });
};

const closeTabQuiet = (id) => {
    if (!id) return;
    chrome.tabs.remove(id, () => { void chrome.runtime.lastError; });
};

const closeAutoWindows = async () => {
    const data = await storageGet(['bgWindowId', 'bgWindowIds', 'activeAutoWindows', 'targetTabIds']);
    const ids = new Set();
    if (backgroundWindowId) ids.add(backgroundWindowId);
    if (data.bgWindowId) ids.add(data.bgWindowId);
    (Array.isArray(data.bgWindowIds) ? data.bgWindowIds : []).forEach(id => ids.add(id));
    (Array.isArray(data.activeAutoWindows) ? data.activeAutoWindows : []).forEach(id => ids.add(id));
    ids.forEach(closeWindowQuiet);
    const targetTabIds = data.targetTabIds && typeof data.targetTabIds === 'object' ? data.targetTabIds : {};
    Object.keys(targetTabIds).forEach(id => closeTabQuiet(Number(id)));
    backgroundWindowId = null;
    await storageRemove(['bgWindowId', 'bgWindowIds', 'targetTabId', 'targetTabIds', 'activeAutoWindows', 'activeWindowOpenedAt', 'activeTasks', 'parallelRunnerMode']);
};


// TRC_MONITOR_START
const normalizeTronAddress = (raw) => String(raw || '').trim();
const shortTrcHash = (hash) => String(hash || '').length > 16 ? String(hash).slice(0, 8) + '...' + String(hash).slice(-6) : String(hash || '');
const isValidTronAddress = (raw) => /^T[1-9A-HJ-NP-Za-km-z]{25,40}$/.test(normalizeTronAddress(raw));
const formatUsdt2 = (amount) => Number(amount || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });

const getTrcAlarmPeriod = (settings) => {
    const sec = Math.max(30, Number(settings && settings.intervalSec || 60) || 60);
    return Math.max(0.5, sec / 60);
};

const buildTrcMonitorUrl = (settings) => {
    const address = encodeURIComponent(normalizeTronAddress(settings && settings.address));
    const params = new URLSearchParams();
    params.set('limit', '30');
    params.set('order_by', 'block_timestamp,desc');
    if (settings && settings.onlyIncoming) params.set('only_to', 'true');
    const tokenContract = String(settings && settings.tokenContract || DEFAULT_TRC_USDT_CONTRACT).trim();
    if (tokenContract) params.set('contract_address', tokenContract);
    return 'https://api.trongrid.io/v1/accounts/' + address + '/transactions/trc20?' + params.toString();
};

const buildTrcRiskTransferUrl = (settings) => {
    const address = encodeURIComponent(normalizeTronAddress(settings && settings.address));
    const params = new URLSearchParams();
    params.set('limit', String(Math.max(30, Math.min(200, Number(settings && settings.limit || 100) || 100))));
    params.set('order_by', 'block_timestamp,desc');
    const tokenContract = String(settings && settings.tokenContract || DEFAULT_TRC_USDT_CONTRACT).trim();
    if (tokenContract) params.set('contract_address', tokenContract);
    return 'https://api.trongrid.io/v1/accounts/' + address + '/transactions/trc20?' + params.toString();
};

const buildTrcAccountUrl = (settings) => {
    const address = encodeURIComponent(normalizeTronAddress(settings && settings.address));
    return 'https://api.trongrid.io/v1/accounts/' + address;
};

const parseTrcTokenBalance = (account, tokenContract) => {
    const target = String(tokenContract || DEFAULT_TRC_USDT_CONTRACT).trim().toLowerCase();
    const rows = Array.isArray(account && account.trc20) ? account.trc20 : [];
    for (const row of rows) {
        if (!row || typeof row !== 'object') continue;
        for (const [contract, raw] of Object.entries(row)) {
            if (String(contract).toLowerCase() === target) return Number(raw || 0) / 1_000_000;
        }
    }
    return 0;
};

const updateTrcUsdtBalance = async (settings) => {
    const data = await storageGet(['trcMonitorBalance']);
    const previous = Number(data.trcMonitorBalance && data.trcMonitorBalance.amount);
    const resp = await fetch(buildTrcAccountUrl(settings), { cache: 'no-store' });
    if (!resp.ok) throw new Error('TRONGRID_ACCOUNT_HTTP_' + resp.status);
    const json = await resp.json();
    const account = (Array.isArray(json && json.data) ? json.data[0] : null) || {};
    const amount = parseTrcTokenBalance(account, settings && settings.tokenContract);
    const changed = Number.isFinite(previous) && Math.abs(previous - amount) >= 0.000001;
    const balance = {
        address: normalizeTronAddress(settings && settings.address),
        amount,
        symbol: 'USDT',
        previousAmount: Number.isFinite(previous) ? previous : null,
        changed,
        updatedAt: Date.now(),
        error: ''
    };
    await storageSet({ trcMonitorBalance: balance });
    if (changed) {
        const text = 'USDT 持倉更新：' + formatUsdt2(amount) + ' USDT';
        await storageSet({ trcMonitorLastAlert: { text, time: Date.now(), amount, symbol: 'USDT', kind: 'balance' } });
        await broadcastPetSay(text, 'alert');
    }
    return balance;
};

const normalizeTrcTransfer = (item, watchAddress) => {
    const tokenInfo = item && (item.token_info || item.tokenInfo || {}) || {};
    const txid = String(item && (item.transaction_id || item.transactionId || item.hash || item.txID) || '').trim();
    const from = String(item && (item.from || item.transferFromAddress || item.owner_address) || '').trim();
    const to = String(item && (item.to || item.transferToAddress || item.to_address) || '').trim();
    const rawValue = String(item && (item.value || item.quant || item.amount || '0') || '0');
    const decimals = Math.max(0, Number(tokenInfo.decimals ?? tokenInfo.tokenDecimal ?? 6) || 6);
    const amount = Number(rawValue) / Math.pow(10, decimals);
    const timeMs = Number(item && (item.block_timestamp || item.blockTimestamp || item.timestamp) || Date.now());
    const contract = String(tokenInfo.address || item.contract_address || item.contractAddress || '').trim();
    const symbol = String(tokenInfo.symbol || tokenInfo.tokenAbbr || tokenInfo.name || 'TRC20').trim();
    const watch = normalizeTronAddress(watchAddress).toLowerCase();
    const inbound = to.toLowerCase() === watch;
    const outbound = from.toLowerCase() === watch;
    return { txid, from, to, rawValue, decimals, amount, time: timeMs, contract, symbol, inbound, outbound, direction: inbound ? 'in' : outbound ? 'out' : '' };
};

const broadcastPetSay = async (text, mood = 'alert', voice = null, options = {}) => {
    chrome.tabs.query({}, (tabs) => {
        (tabs || []).forEach(tab => {
            if (!tab.id || !/^https?:/i.test(tab.url || '') || !isBecGameUrl(tab.url)) return;
            chrome.tabs.sendMessage(tab.id, { action: 'BEC_PET_SAY', text, mood, voice, ...(options || {}) }, () => { void chrome.runtime.lastError; });
        });
    });
};

const localDateKey = (time = Date.now()) => {
    const d = new Date(time);
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};

const normalizeYongxuCvsRows = (result) => {
    const source = Array.isArray(result && result.abnormalRows) && result.abnormalRows.length
        ? result.abnormalRows
        : result && result.abnormal
            ? [result]
            : [];
    const seen = new Set();
    return source
        .map(row => row && typeof row === 'object' ? row : null)
        .filter(Boolean)
        .map(row => ({ ...row, orderNo: String(row.orderNo || '').trim(), abnormal: true }))
        .filter(row => row.orderNo)
        .filter(row => {
            if (seen.has(row.orderNo)) return false;
            seen.add(row.orderNo);
            return true;
        });
};

const yongxuCvsAlertKey = (date, rows) => {
    const orderNos = rows.map(row => row.orderNo).filter(Boolean).sort();
    return `${date}|${orderNos.join(',')}`;
};

const cleanupYongxuCvsDailyMemory = async () => {
    const today = localDateKey();
    const data = await storageGet(['momoYongxuCvsPromptedDate']);
    if (!data.momoYongxuCvsPromptedDate || data.momoYongxuCvsPromptedDate === today) return false;
    await storageSet({
        momoYongxuCvsPromptedDate: today,
        momoYongxuCvsPromptedOrderNos: [],
        momoYongxuCvsDismissedKey: '',
        momoYongxuCvsDismissedAt: 0,
        momoYongxuCvsAlert: null,
        momoYongxuCvsAlertKey: '',
        momoYongxuCvsAlertText: null
    });
    return true;
};

const handleYongxuCvsScanResult = async (message) => {
    await cleanupYongxuCvsDailyMemory();
    const result = message && message.result && typeof message.result === 'object' ? message.result : null;
    if (!result) return { success: false, error: 'NO_RESULT' };
    const today = localDateKey();
    const abnormalRows = normalizeYongxuCvsRows(result);
    const orderNos = abnormalRows.map(row => row.orderNo);
    const abnormal = abnormalRows.length > 0;
    const latestOrderNo = String(result.orderNo || orderNos[0] || '').trim();
    if (!latestOrderNo && !orderNos.length) return { success: false, error: 'NO_ORDER_NO' };
    const data = await storageGet([
        'momoYongxuCvsPromptedDate',
        'momoYongxuCvsPromptedOrderNos',
        'momoYongxuCvsDismissedKey'
    ]);
    const sameDate = data.momoYongxuCvsPromptedDate === today;
    const prompted = new Set(sameDate && Array.isArray(data.momoYongxuCvsPromptedOrderNos) ? data.momoYongxuCvsPromptedOrderNos : []);
    const unseenRows = abnormalRows.filter(row => !prompted.has(row.orderNo));
    const payload = {
        momoYongxuCvsPromptedDate: today,
        momoYongxuCvsLast: {
            ...result,
            orderNo: latestOrderNo,
            abnormal,
            abnormalRows,
            orderNos,
            abnormalCount: abnormalRows.length,
            updatedAt: Date.now()
        }
    };
    if (!sameDate) {
        payload.momoYongxuCvsDismissedKey = '';
        payload.momoYongxuCvsPromptedOrderNos = [];
    }
    if (!abnormal) {
        payload.momoYongxuCvsAlert = null;
        payload.momoYongxuCvsAlertKey = '';
        payload.momoYongxuCvsAlertText = null;
        await storageSet(payload);
        return { success: true, alerted: false, result: payload.momoYongxuCvsLast };
    }
    if (unseenRows.length) {
        const key = yongxuCvsAlertKey(today, unseenRows);
        const orderText = unseenRows.map(row => row.orderNo).join('、');
        const text = unseenRows.length === 1
            ? '超商預約異常：' + unseenRows[0].orderNo
            : '超商預約異常 ' + unseenRows.length + ' 筆：' + orderText;
        const alertResult = {
            ...payload.momoYongxuCvsLast,
            orderNo: unseenRows[0].orderNo,
            orderNos: unseenRows.map(row => row.orderNo),
            abnormalRows: unseenRows,
            abnormalCount: unseenRows.length,
            key,
            alertDate: today
        };
        payload.momoYongxuCvsAlert = alertResult;
        payload.momoYongxuCvsAlertKey = key;
        payload.momoYongxuCvsAlertText = { text, orderNos: alertResult.orderNos, key, date: today, time: Date.now(), kind: 'yongxu_cvs_abnormal' };
        payload.momoYongxuCvsLastAlertKey = key;
        payload.momoYongxuCvsLastAlertAt = Date.now();
        payload.momoYongxuCvsPromptedOrderNos = [...new Set([...prompted, ...alertResult.orderNos])];
        await storageSet(payload);
        await broadcastPetSay(text, 'alert', { key: 'cvs_alert', text: '超商預約異常，請確認商戶訂單號。' }, {
            kind: 'yongxu_cvs_abnormal',
            persist: true,
            orderNo: alertResult.orderNo,
            orderNos: alertResult.orderNos,
            alertKey: key,
            result: alertResult
        });
        chrome.notifications.create('yongxu_cvs_' + Date.now(), {
            type: 'basic',
            title: unseenRows.length === 1 ? '超商預約異常' : '超商預約異常 ' + unseenRows.length + ' 筆',
            message: '商戶訂單號：' + orderText,
            iconUrl: chrome.runtime.getURL('icon128.png'),
            priority: 2,
            requireInteraction: true
        }, () => { void chrome.runtime.lastError; });
        return { success: true, alerted: true, result: alertResult };
    }
    await storageSet(payload);
    return { success: true, alerted: false, result: payload.momoYongxuCvsLast };
};

const notifyTrcTransfers = async (rows) => {
    if (!rows.length) return;
    const first = rows[0];
    const text = rows.length === 1
        ? 'TRC 入款 ' + Number(first.amount || 0).toLocaleString(undefined, { maximumFractionDigits: 6 }) + ' ' + first.symbol + '，交易 ' + shortTrcHash(first.txid)
        : 'TRC 收到 ' + rows.length + ' 筆新入款，最新 ' + Number(first.amount || 0).toLocaleString(undefined, { maximumFractionDigits: 6 }) + ' ' + first.symbol;
    const voiceText = rows.length === 1 ? 'USDT 收到一筆款項，賺到錢啦。' : 'USDT 收到多筆款項，賺到錢啦。';
    const voice = { key: 'usdt_profit', text: voiceText };
    const alert = { text, time: Date.now(), txid: first.txid, amount: first.amount, symbol: first.symbol, kind: 'trc_transfer', voiceKey: voice.key, voiceText };
    await storageSet({ trcMonitorLastAlert: alert });
    await broadcastPetSay(text, 'alert', voice);
    chrome.notifications.create('trc_' + Date.now(), {
        type: 'basic',
        title: 'TRC 鏈上入款提醒',
        message: text,
        iconUrl: chrome.runtime.getURL('icon128.png'),
        priority: 2,
        requireInteraction: true
    }, () => { void chrome.runtime.lastError; });
};

const runTrcMonitorOnce = async ({ baseline = false, force = false, overrideSettings = null } = {}) => {
    const data = await storageGet(['trcMonitorSettings', 'trcMonitorSeenTxIds', 'trcMonitorResults']);
    const settings = { ...(data.trcMonitorSettings || {}), ...(overrideSettings || {}) };
    if (!force && !settings.enabled) return { success: true, skipped: true };
    if (!isValidTronAddress(settings.address)) throw new Error('BAD_TRC_ADDRESS');

    const balance = await updateTrcUsdtBalance(settings).catch(async err => {
        await storageSet({ trcMonitorBalance: { address: normalizeTronAddress(settings.address), error: err && err.message || String(err), changed: false, updatedAt: Date.now() } });
        await appendLog('TRC_BALANCE_ERR ' + (err && err.message || String(err)));
        return null;
    });

    const resp = await fetch(buildTrcMonitorUrl(settings), { cache: 'no-store' });
    if (!resp.ok) throw new Error('TRONGRID_HTTP_' + resp.status);
    const json = await resp.json();
    const sourceRows = Array.isArray(json && json.data) ? json.data : [];
    const minAmount = Math.max(0, Number(settings.minAmount || 0) || 0);
    const tokenContract = String(settings.tokenContract || DEFAULT_TRC_USDT_CONTRACT).trim().toLowerCase();
    const startedAt = Number(settings.startedAt || 0);
    const seen = data.trcMonitorSeenTxIds && typeof data.trcMonitorSeenTxIds === 'object' ? { ...data.trcMonitorSeenTxIds } : {};

    const rows = sourceRows
        .map(item => normalizeTrcTransfer(item, settings.address))
        .filter(row => row.txid && (row.inbound || row.outbound))
        .filter(row => !tokenContract || !row.contract || row.contract.toLowerCase() === tokenContract)
        .filter(row => Number(row.amount) >= minAmount)
        .sort((a, b) => Number(b.time || 0) - Number(a.time || 0));

    const newRows = [];
    rows.forEach(row => {
        if (!seen[row.txid] && row.inbound && !baseline && (!startedAt || Number(row.time || 0) >= startedAt - 60000)) newRows.push(row);
        seen[row.txid] = Number(row.time || Date.now());
    });

    Object.keys(seen).slice(200).forEach(key => delete seen[key]);
    const oldResults = Array.isArray(data.trcMonitorResults) ? data.trcMonitorResults : [];
    const merged = [...rows, ...oldResults]
        .filter((row, idx, arr) => row && row.txid && arr.findIndex(item => item.txid === row.txid) === idx)
        .sort((a, b) => Number(b.time || 0) - Number(a.time || 0))
        .slice(0, 80);

    await storageSet({
        trcMonitorSettings: { ...settings, lastCheckedAt: Date.now(), lastError: '' },
        trcMonitorSeenTxIds: seen,
        trcMonitorResults: merged
    });

    if (newRows.length) await notifyTrcTransfers(newRows);
    await appendLog('TRC_MONITOR checked=' + rows.length + ' new=' + newRows.length);
    return { success: true, count: rows.length, newCount: newRows.length, balance };
};

const clampRiskScore = (value) => Math.max(0, Math.min(100, Math.round(Number(value || 0))));
const riskLevelFromScore = (score) => {
    if (score >= 80) return { level: '高風險', state: 'high' };
    if (score >= 50) return { level: '中風險', state: 'medium' };
    if (score >= 25) return { level: '觀察', state: 'watch' };
    return { level: '低風險', state: 'low' };
};
const riskDirectionText = (direction) => direction === 'in' ? '入款來源' : direction === 'out' ? '出款去向' : '關聯地址';
const appendRiskAudit = async (entry) => {
    const data = await storageGet(['riskAuditLog']);
    const list = Array.isArray(data.riskAuditLog) ? data.riskAuditLog : [];
    const next = [{ time: Date.now(), ...entry }, ...list].slice(0, 120);
    await storageSet({ riskAuditLog: next });
    return next;
};
const evaluateRiskAml = async (address, rows, balance) => {
    const data = await storageGet(['riskAmlConfig']);
    const cfg = data.riskAmlConfig && typeof data.riskAmlConfig === 'object' ? data.riskAmlConfig : {};
    if (!cfg.endpoint) return { status: 'not_configured', score: 0, reasons: ['尚未設定 AML API，已使用公開情資與鏈上規則評估。'] };
    try {
        const headers = { 'content-type': 'application/json' };
        if (cfg.apiKey) headers.authorization = `Bearer ${cfg.apiKey}`;
        const resp = await fetch(String(cfg.endpoint), {
            method: 'POST',
            headers,
            body: JSON.stringify({ address, chain: 'TRON', asset: 'USDT', balance, transfers: rows.slice(0, 50) })
        });
        if (!resp.ok) throw new Error('AML_HTTP_' + resp.status);
        const json = await resp.json();
        const score = clampRiskScore(json.score ?? json.riskScore ?? (json.risk === 'high' ? 90 : json.risk === 'medium' ? 55 : 0));
        const reasons = Array.isArray(json.reasons) ? json.reasons.map(String) : (json.reason ? [String(json.reason)] : []);
        return { status: 'ok', score, provider: cfg.name || 'AML API', rawRisk: json.risk || '', reasons };
    } catch (err) {
        return { status: 'error', score: 8, reasons: ['AML API 查詢失敗：' + (err && err.message || String(err))] };
    }
};
const truthyRiskFlag = (value) => {
    if (value === true || value === 1) return true;
    const text = String(value ?? '').trim().toLowerCase();
    return text === 'true' || text === '1' || text === 'yes' || text === 'risk' || text === 'high';
};
const getRiskFlag = (data, keys) => keys.some(key => truthyRiskFlag(data && data[key]));
const buildTronScanAccountSecurityUrl = (address) => {
    const params = new URLSearchParams();
    params.set('address', normalizeTronAddress(address));
    return 'https://apilist.tronscanapi.com/api/security/account/data?' + params.toString();
};
const buildTronScanTransactionSecurityUrl = (hashes) => {
    const params = new URLSearchParams();
    params.set('hashes', hashes.join(','));
    return 'https://apilist.tronscanapi.com/api/security/transaction/data?' + params.toString();
};
const fetchPublicRiskIntel = async (address, rows = []) => {
    const reasons = [];
    const sources = [];
    let score = 0;

    try {
        const resp = await fetch(buildTronScanAccountSecurityUrl(address), { cache: 'no-store' });
        if (!resp.ok) throw new Error('TRONSCAN_ACCOUNT_SECURITY_HTTP_' + resp.status);
        const json = await resp.json();
        const data = json && json.data && typeof json.data === 'object' && !Array.isArray(json.data) ? json.data : json || {};
        const flags = {
            stablecoinBlacklist: getRiskFlag(data, ['is_black_list', 'isBlackList', 'blacklist', 'black_list']),
            fraudTransaction: getRiskFlag(data, ['has_fraud_transaction', 'hasFraudTransaction', 'fraud_transaction']),
            fraudTokenCreator: getRiskFlag(data, ['fraud_token_creator', 'fraudTokenCreator']),
            memoSpam: getRiskFlag(data, ['send_ad_by_memo', 'sendAdByMemo']),
            riskAddress: getRiskFlag(data, ['riskAddress', 'risk_address', 'is_risk', 'isRisk', 'risk'])
        };
        if (flags.stablecoinBlacklist) { score += 90; reasons.push('TRONSCAN 公開情資：地址命中穩定幣黑名單。'); }
        if (flags.fraudTransaction) { score += 55; reasons.push('TRONSCAN 公開情資：地址存在詐騙交易紀錄。'); }
        if (flags.fraudTokenCreator) { score += 25; reasons.push('TRONSCAN 公開情資：地址曾建立詐騙風險代幣。'); }
        if (flags.riskAddress) { score += 25; reasons.push('TRONSCAN 公開情資：地址被標記為風險地址。'); }
        if (flags.memoSpam) { score += 8; reasons.push('TRONSCAN 公開情資：地址有 Memo 廣告或垃圾訊息行為。'); }
        sources.push({ name: 'TRONSCAN 帳戶安全', status: 'ok', flags });
    } catch (err) {
        sources.push({ name: 'TRONSCAN 帳戶安全', status: 'error', error: err && err.message || String(err) });
        reasons.push('TRONSCAN 帳戶安全情資查詢失敗，已改用鏈上規則評估。');
    }

    const hashes = rows
        .map(row => String(row && row.txid || '').trim())
        .filter(Boolean)
        .filter((hash, index, list) => list.indexOf(hash) === index)
        .slice(0, 20);

    if (hashes.length) {
        try {
            const resp = await fetch(buildTronScanTransactionSecurityUrl(hashes), { cache: 'no-store' });
            if (!resp.ok) throw new Error('TRONSCAN_TX_SECURITY_HTTP_' + resp.status);
            const json = await resp.json();
            const txMap = json && json.data && typeof json.data === 'object' && !Array.isArray(json.data) ? json.data : json || {};
            const riskRows = Object.entries(txMap).filter(([, item]) => {
                if (!item || typeof item !== 'object') return false;
                return getRiskFlag(item, ['riskTransaction', 'risk_transaction', 'risk']) ||
                    getRiskFlag(item, ['riskAddress', 'risk_address']) ||
                    getRiskFlag(item, ['riskToken', 'risk_token']) ||
                    getRiskFlag(item, ['sameTailAttach', 'same_tail_attach']) ||
                    getRiskFlag(item, ['zeroTransfer', 'zero_transfer']);
            });
            if (riskRows.length) {
                const riskAddressCount = riskRows.filter(([, item]) => getRiskFlag(item, ['riskAddress', 'risk_address'])).length;
                const riskTxCount = riskRows.filter(([, item]) => getRiskFlag(item, ['riskTransaction', 'risk_transaction', 'risk'])).length;
                const sameTailCount = riskRows.filter(([, item]) => getRiskFlag(item, ['sameTailAttach', 'same_tail_attach'])).length;
                score += Math.min(35, 12 + riskRows.length * 5 + riskAddressCount * 6);
                reasons.push(`TRONSCAN 交易情資：最近 ${hashes.length} 筆中有 ${riskRows.length} 筆被標記為風險交易。`);
                if (riskAddressCount) reasons.push(`TRONSCAN 交易情資：有 ${riskAddressCount} 筆交易涉及公開風險地址。`);
                if (riskTxCount) reasons.push(`TRONSCAN 交易情資：有 ${riskTxCount} 筆交易被判定為整體風險交易。`);
                if (sameTailCount) reasons.push(`TRONSCAN 交易情資：有 ${sameTailCount} 筆疑似尾號相似地址攻擊。`);
            }
            sources.push({ name: 'TRONSCAN 交易安全', status: 'ok', checked: hashes.length, riskCount: riskRows.length });
        } catch (err) {
            sources.push({ name: 'TRONSCAN 交易安全', status: 'error', checked: hashes.length, error: err && err.message || String(err) });
        }
    } else {
        sources.push({ name: 'TRONSCAN 交易安全', status: 'skipped', checked: 0 });
    }

    return {
        status: sources.some(source => source.status === 'ok') ? 'ok' : 'error',
        score: clampRiskScore(score),
        reasons,
        sources
    };
};
const buildRiskPathAnalysis = (rows, address) => {
    const watch = normalizeTronAddress(address).toLowerCase();
    const map = new Map();
    rows.forEach(row => {
        const from = String(row.from || '').trim();
        const to = String(row.to || '').trim();
        const counterparty = row.inbound ? from : row.outbound ? to : '';
        if (!counterparty) return;
        const key = counterparty.toLowerCase();
        const item = map.get(key) || {
            address: counterparty,
            direction: row.inbound ? 'in' : row.outbound ? 'out' : '',
            directionText: riskDirectionText(row.inbound ? 'in' : row.outbound ? 'out' : ''),
            count: 0,
            amount: 0,
            latestTime: 0
        };
        item.count += 1;
        item.amount += Number(row.amount || 0) || 0;
        item.latestTime = Math.max(item.latestTime, Number(row.time || 0) || 0);
        if (row.inbound) item.inCount = (item.inCount || 0) + 1;
        if (row.outbound) item.outCount = (item.outCount || 0) + 1;
        map.set(key, item);
    });
    return Array.from(map.values())
        .filter(item => item.address.toLowerCase() !== watch)
        .sort((a, b) => Number(b.amount || 0) - Number(a.amount || 0) || Number(b.count || 0) - Number(a.count || 0));
};
const enrichRiskPathAnalysis = async (pathAnalysis) => {
    const list = Array.isArray(pathAnalysis) ? pathAnalysis : [];
    const topItems = list
        .filter(item => isValidTronAddress(item.address))
        .slice(0, 8);
    const intelRows = await Promise.all(topItems.map(async item => {
        try {
            const intel = await fetchPublicRiskIntel(item.address, []);
            const level = riskLevelFromScore(intel.score || 0);
            return {
                key: item.address.toLowerCase(),
                riskScore: intel.score || 0,
                riskLevel: intel.score ? level.level : '',
                riskState: intel.score ? level.state : '',
                riskReasons: (intel.reasons || []).slice(0, 3),
                riskStatus: intel.status || 'unknown'
            };
        } catch (err) {
            return {
                key: item.address.toLowerCase(),
                riskScore: 0,
                riskLevel: '',
                riskState: '',
                riskReasons: [],
                riskStatus: 'error'
            };
        }
    }));
    const intelMap = new Map(intelRows.map(row => [row.key, row]));
    return list.map(item => {
        const intel = intelMap.get(String(item.address || '').toLowerCase());
        return intel ? { ...item, ...intel } : item;
    });
};
const hasRapidInOutPattern = (rows) => {
    const sorted = rows.slice().sort((a, b) => Number(a.time || 0) - Number(b.time || 0));
    for (let i = 0; i < sorted.length; i += 1) {
        const a = sorted[i];
        if (!a.inbound) continue;
        for (let j = i + 1; j < sorted.length; j += 1) {
            const b = sorted[j];
            const delta = Number(b.time || 0) - Number(a.time || 0);
            if (delta > 30 * 60 * 1000) break;
            if (b.outbound && Number(b.amount || 0) >= Number(a.amount || 0) * 0.8) return true;
        }
    }
    return false;
};
const evaluateUsdtRisk = async (rawAddress, context = {}) => {
    const address = normalizeTronAddress(rawAddress);
    if (!isValidTronAddress(address)) throw new Error('BAD_TRC_ADDRESS');
    const source = String(context.source || '').trim();
    const pageUrl = String(context.pageUrl || '').trim();
    const settings = { address, tokenContract: DEFAULT_TRC_USDT_CONTRACT, limit: 100 };
    const [accountResp, transferResp] = await Promise.all([
        fetch(buildTrcAccountUrl(settings), { cache: 'no-store' }),
        fetch(buildTrcRiskTransferUrl(settings), { cache: 'no-store' })
    ]);
    if (!accountResp.ok) throw new Error('TRONGRID_ACCOUNT_HTTP_' + accountResp.status);
    if (!transferResp.ok) throw new Error('TRONGRID_HTTP_' + transferResp.status);
    const accountJson = await accountResp.json();
    const transferJson = await transferResp.json();
    const account = (Array.isArray(accountJson && accountJson.data) ? accountJson.data[0] : null) || {};
    const balance = parseTrcTokenBalance(account, DEFAULT_TRC_USDT_CONTRACT);
    const sourceRows = Array.isArray(transferJson && transferJson.data) ? transferJson.data : [];
    const rows = sourceRows
        .map(item => normalizeTrcTransfer(item, address))
        .filter(row => row.txid && (row.inbound || row.outbound))
        .filter(row => !row.contract || row.contract.toLowerCase() === DEFAULT_TRC_USDT_CONTRACT.toLowerCase())
        .sort((a, b) => Number(b.time || 0) - Number(a.time || 0));
    const pathAnalysis = buildRiskPathAnalysis(rows, address);
    const totalIn = rows.filter(row => row.inbound).reduce((sum, row) => sum + Number(row.amount || 0), 0);
    const totalOut = rows.filter(row => row.outbound).reduce((sum, row) => sum + Number(row.amount || 0), 0);
    const totalVolume = totalIn + totalOut;
    const maxTx = rows.reduce((max, row) => Math.max(max, Number(row.amount || 0)), 0);
    const now = Date.now();
    const last24hRows = rows.filter(row => now - Number(row.time || 0) <= 24 * 60 * 60 * 1000);
    const times = rows.map(row => Number(row.time || 0)).filter(Boolean);
    const spanDays = times.length >= 2 ? Math.max(0, (Math.max(...times) - Math.min(...times)) / 86400000) : 0;
    const topPath = pathAnalysis[0] || null;
    const topShare = totalVolume > 0 && topPath ? Number(topPath.amount || 0) / totalVolume : 0;
    const [aml, publicIntel, enrichedPathAnalysis] = await Promise.all([
        evaluateRiskAml(address, rows, balance),
        fetchPublicRiskIntel(address, rows),
        enrichRiskPathAnalysis(pathAnalysis)
    ]);
    const relatedHighRiskPaths = enrichedPathAnalysis.filter(item => Number(item.riskScore || 0) >= 80);
    const relatedMediumRiskPaths = enrichedPathAnalysis.filter(item => Number(item.riskScore || 0) >= 50 && Number(item.riskScore || 0) < 80);
    const lowTransferCount = rows.length <= 2;
    const lowTransferAbnormal = lowTransferCount && (balance > 0 || totalVolume > 0 || relatedHighRiskPaths.length > 0);

    let score = 0;
    const reasons = [];
    if (aml.score) {
        score += aml.score >= 80 ? 35 : aml.score >= 50 ? 22 : aml.score >= 25 ? 12 : 4;
        reasons.push(...(aml.reasons || []).slice(0, 3).map(reason => `AML：${reason}`));
    } else if (aml.status !== 'not_configured' && aml.reasons?.length) {
        reasons.push(...aml.reasons.slice(0, 1));
    }
    if (publicIntel.score) {
        score += Math.min(85, publicIntel.score);
        reasons.push(...(publicIntel.reasons || []).slice(0, 5));
    } else if (publicIntel.reasons?.length) {
        reasons.push(...publicIntel.reasons.slice(0, 1));
    }
    if (relatedHighRiskPaths.length) {
        score += Math.min(42, 28 + relatedHighRiskPaths.length * 7);
        reasons.push('關聯帳戶屬高危險係數：' + relatedHighRiskPaths.slice(0, 3).map(item => shortTrcHash(item.address) + `(${item.riskScore})`).join('、'));
    } else if (relatedMediumRiskPaths.length) {
        score += Math.min(18, 10 + relatedMediumRiskPaths.length * 4);
        reasons.push('關聯帳戶存在中度風險：' + relatedMediumRiskPaths.slice(0, 3).map(item => shortTrcHash(item.address) + `(${item.riskScore})`).join('、'));
    }
    if (relatedHighRiskPaths.length && lowTransferCount) {
        score += 35;
        score = Math.max(score, 85);
        reasons.push('關聯帳戶為高危險係數且本帳戶交易筆數過低，列為異常帳戶。');
    } else if (lowTransferAbnormal) {
        score += 28;
        reasons.push(`交易筆數過低（${rows.length} 筆）但已有持倉或資金流，列為異常帳戶。`);
    }
    if (balance >= 100000) { score += 14; reasons.push('USDT 持倉超過 100,000。'); }
    else if (balance >= 30000) { score += 8; reasons.push('USDT 持倉偏高，超過 30,000。'); }
    if (totalVolume >= 250000) { score += 18; reasons.push('近 100 筆 USDT 交易總量超過 250,000。'); }
    else if (totalVolume >= 80000) { score += 10; reasons.push('近 100 筆 USDT 交易總量偏高，超過 80,000。'); }
    if (maxTx >= 50000) { score += 12; reasons.push('存在單筆大額交易超過 50,000 USDT。'); }
    else if (maxTx >= 10000) { score += 6; reasons.push('存在單筆交易超過 10,000 USDT。'); }
    if (last24hRows.length >= 12) { score += 12; reasons.push('24 小時內交易筆數偏高。'); }
    if (pathAnalysis.length >= 25) { score += 12; reasons.push('關聯交易地址過多，資金流向分散。'); }
    else if (pathAnalysis.length >= 12) { score += 6; reasons.push('關聯交易地址數量偏高。'); }
    if (topShare >= 0.85 && rows.length >= 5) { score += 8; reasons.push('資金高度集中在單一交易對手。'); }
    if (hasRapidInOutPattern(rows)) { score += 14; reasons.push('偵測到入款後短時間內近額出款的快速流轉模式。'); }
    if (spanDays > 0 && spanDays <= 3 && totalVolume >= 10000) { score += 10; reasons.push('帳戶近期才出現活動但交易量偏高。'); }
    if (!rows.length && balance > 0) { score += 5; reasons.push('目前有持倉但近期未取得 USDT 交易紀錄。'); }
    if (!reasons.length) reasons.push('未命中公開情資、AML 或鏈上高風險規則，危險係數偏低。');
    score = clampRiskScore(score);
    const level = riskLevelFromScore(score);
    const result = {
        success: true,
        address,
        score,
        level: level.level,
        state: level.state,
        reasons: reasons.slice(0, 10),
        metrics: {
            balance,
            transferCount: rows.length,
            inboundCount: rows.filter(row => row.inbound).length,
            outboundCount: rows.filter(row => row.outbound).length,
            totalIn,
            totalOut,
            totalVolume,
            maxTx,
            counterparties: pathAnalysis.length,
            highRiskCounterparties: relatedHighRiskPaths.length,
            mediumRiskCounterparties: relatedMediumRiskPaths.length,
            lowTransferAbnormal,
            last24hCount: last24hRows.length,
            topCounterpartyShare: topShare
        },
        abnormalFlags: [
            ...(relatedHighRiskPaths.length ? ['關聯帳戶高危險係數'] : []),
            ...(lowTransferAbnormal ? ['交易筆數過低異常'] : [])
        ],
        pathAnalysis: enrichedPathAnalysis.slice(0, 20),
        aml,
        publicIntel,
        latestTransfers: rows.slice(0, 12),
        evaluatedAt: Date.now(),
        source,
        pageUrl
    };
    await storageSet({ riskLastResult: result });
    await appendRiskAudit({ type: 'evaluate', address, score, level: result.level, summary: result.reasons[0] || '完成評估' });
    return result;
};
const startTrcMonitor = async (settings) => {
    const next = {
        enabled: true,
        address: normalizeTronAddress(settings && settings.address || DEFAULT_TRC_ADDRESS),
        tokenContract: String(settings && settings.tokenContract || DEFAULT_TRC_USDT_CONTRACT).trim(),
        minAmount: Math.max(0, Number(settings && settings.minAmount || 0) || 0),
        intervalSec: Math.max(30, Number(settings && settings.intervalSec || 60) || 60),
        startedAt: Date.now(),
        lastError: ''
    };
    if (!isValidTronAddress(next.address)) throw new Error('BAD_TRC_ADDRESS');
    await storageSet({ trcMonitorSettings: next });
    chrome.alarms.create(TRC_MONITOR_ALARM, { periodInMinutes: getTrcAlarmPeriod(next) });
    await runTrcMonitorOnce({ baseline: true, force: true, overrideSettings: next });
    await broadcastPetSay('TRC 監測已啟動，墨墨會提醒新入款。', 'working');
    return { success: true };
};

const stopTrcMonitor = async () => {
    const data = await storageGet(['trcMonitorSettings']);
    await storageSet({ trcMonitorSettings: { ...(data.trcMonitorSettings || {}), enabled: false } });
    chrome.alarms.clear(TRC_MONITOR_ALARM);
    await broadcastPetSay('TRC 監測已停止。', '');
    return { success: true };
};

const recoverTrcMonitorOnLoad = async () => {
    const data = await storageGet(['trcMonitorSettings']);
    const settings = data.trcMonitorSettings || {};
    const next = {
        enabled: true,
        address: isValidTronAddress(settings.address) ? normalizeTronAddress(settings.address) : DEFAULT_TRC_ADDRESS,
        tokenContract: String(settings.tokenContract || DEFAULT_TRC_USDT_CONTRACT).trim(),
        minAmount: Math.max(0, Number(settings.minAmount || 0) || 0),
        intervalSec: Math.max(30, Number(settings.intervalSec || 60) || 60),
        startedAt: Number(settings.startedAt || Date.now()),
        lastError: ''
    };
    if (!isValidTronAddress(next.address)) return;
    await storageSet({ trcMonitorSettings: next });
    chrome.alarms.create(TRC_MONITOR_ALARM, { periodInMinutes: getTrcAlarmPeriod(next) });
    setTimeout(() => runTrcMonitorOnce({ baseline: true, force: true, overrideSettings: next }).catch(err => appendLog('TRC_MONITOR_BOOT_ERR ' + (err && err.message || String(err)))), 1000);
};
// TRC_MONITOR_END
const getDisabledKeySet = (data) => {
    const set = new Set();
    const disabledAccounts = data.disabledAccounts && typeof data.disabledAccounts === 'object' ? data.disabledAccounts : {};
    Object.keys(disabledAccounts).forEach(k => { if (disabledAccounts[k]) set.add(accountKey(k)); });
    (Array.isArray(data.disabledRecords) ? data.disabledRecords : []).forEach(r => {
        const k = accountKey(r && r.account);
        if (k) set.add(k);
    });
    return set;
};

const appendLog = async (text) => {
    const data = await storageGet(['debugLog']);
    const log = data.debugLog || [];
    log.push('[' + new Date().toLocaleTimeString('zh-TW', { hour12: false }) + '] ' + text);
    if (log.length > 80) log.shift();
    await storageSet({ debugLog: log });
};

const getLimitHit = (value, winLimitRaw, lossLimitRaw) => {
    const amount = Number(value);
    if (!Number.isFinite(amount) || amount === 0) return { hit: false };
    const winLimit = Number(winLimitRaw);
    const lossLimit = Number(lossLimitRaw);
    if (amount > 0 && Number.isFinite(winLimit) && winLimit > 0 && amount >= winLimit) return { hit: true, direction: '贏', limit: winLimit };
    if (amount < 0 && Number.isFinite(lossLimit) && lossLimit > 0 && Math.abs(amount) >= lossLimit) return { hit: true, direction: '輸', limit: lossLimit };
    return { hit: false };
};

const poolModeOf = (pool) => {
    const raw = String((pool && pool.mode) || '').toLowerCase();
    return raw === 'hybrid' ? 'hybrid' : 'total';
};

const maybeQueuePoolForceDisables = async () => {
    const data = await storageGet(['isRunning', 'autoConfig', 'results', 'autoQueue', 'activeTasks', 'disabledAccounts', 'disabledRecords', 'poolForceMembers']);
    if (!data.isRunning || !data.autoConfig) return;

    const cfg = data.autoConfig || {};
    const pools = Array.isArray(cfg.sharedPools) ? cfg.sharedPools : [];
    const accounts = Array.isArray(cfg.accounts) ? cfg.accounts : [];
    const results = Array.isArray(data.results) ? data.results : [];
    const queue = Array.isArray(data.autoQueue) ? [...data.autoQueue] : [];
    const activeTasks = data.activeTasks && typeof data.activeTasks === 'object' ? data.activeTasks : {};
    const forceMap = data.poolForceMembers && typeof data.poolForceMembers === 'object' ? { ...data.poolForceMembers } : {};
    const disabledSet = getDisabledKeySet(data);
    const queuedSet = new Set(queue.map(acc => accountKey(acc && acc.name)));
    Object.values(activeTasks).forEach(task => queuedSet.add(accountKey(task && task.account && task.account.name)));
    let changed = false;

    pools.forEach(pool => {
        const poolId = normalizePoolId(pool && pool.id);
        if (!poolId) return;
        const members = accounts.filter(acc => normalizePoolId(acc && acc.poolId) === poolId && String(acc && acc.name || '').trim());
        if (!members.length) return;
        const resultMap = new Map(results.filter(r => !(r && r.queryFailed)).map(r => [accountKey(r && r.account), r]));
        const allDone = members.every(acc => resultMap.has(accountKey(acc.name)));
        if (!allDone) return;

        const total = members.reduce((sum, acc) => {
            const r = resultMap.get(accountKey(acc.name));
            const n = Number(r && (r.resetPayoutNumber ?? r.payoutNumber));
            return Number.isFinite(n) ? sum + n : sum;
        }, 0);
        const winLimit = Number(pool.winLimitWan || pool.limitWan || 0) * 10000;
        const lossLimit = Number(pool.lossLimitWan || pool.limitWan || 0) * 10000;
        const hit = getLimitHit(total, winLimit, lossLimit);
        if (!hit.hit) return;

        const reason = '共用池 ' + poolId + ' 全部查完，總和' + hit.direction + '達上限 ' + Number(hit.limit).toLocaleString() + '，目前總和 ' + total.toLocaleString();
                const forceInfo = {
            poolId,
            reason,
            poolTotalNumber: total,
            poolLimitNumber: Number(hit.limit),
            poolDirection: hit.direction || '',
            poolMemberCount: members.length
        };
        members.forEach(member => {
            const key = accountKey(member.name);
            if (!key || queuedSet.has(key)) return;
            forceMap[key] = forceInfo;
            queue.unshift({
                name: member.name,
                poolId: poolId,
                poolLimit: Math.max(winLimit, lossLimit) || null,
                poolWinLimit: winLimit || null,
                poolLossLimit: lossLimit || null,
                poolMode: poolModeOf(pool),
                limit: null,
                winLimit: null,
                lossLimit: null,
                date: member.date || '0',
                resetAt: member.resetAt || (cfg.resetRule && cfg.resetRule.anchor) || '',
                repeatWeekly: !(cfg.resetRule && cfg.resetRule.repeatWeekly === false),
                forceDisableOnly: true
            });
            queuedSet.add(key);
            changed = true;
        });
        if (changed) appendLog(reason);
    });

    if (changed) await storageSet({ autoQueue: queue, poolForceMembers: forceMap });
};

const getAdaptiveWindowLimit = (pendingCount, maxCapRaw) => {
    const pending = Math.max(0, Number(pendingCount) || 0);
    const maxCap = Math.max(1, Math.min(4, Number(maxCapRaw) || 4));
    if (pending <= 0) return 0;
    if (pending <= 2) return Math.min(maxCap, pending);
    if (pending <= 8) return Math.min(maxCap, 2);
    if (pending <= 20) return Math.min(maxCap, 3);
    return maxCap;
};

const getWindowQuiet = (id) => new Promise(resolve => {
    if (!id) {
        resolve(null);
        return;
    }
    chrome.windows.get(id, { populate: false }, (win) => {
        if (chrome.runtime.lastError || !win) resolve(null);
        else resolve(win);
    });
});

const reserveNextTask = async () => {
    const data = await storageGet(['isRunning', 'autoQueue', 'activeTasks', 'autoConfig', 'startUrl', 'completedCount']);
    if (!data.isRunning) return { success: false, empty: true };

    const queue = Array.isArray(data.autoQueue) ? [...data.autoQueue] : [];
    let account = null;

    while (queue.length > 0 && !account) {
        const candidate = queue.shift();
        const key = accountKey(candidate && candidate.name);
        if (!key) continue;

        account = candidate;
    }

    if (!account) {
        await storageSet({ autoQueue: queue });
        return { success: false, empty: true };
    }

    const taskId = 'task_' + Date.now() + '_' + Math.random().toString(16).slice(2);
    const activeTasks = data.activeTasks && typeof data.activeTasks === 'object' ? { ...data.activeTasks } : {};
    activeTasks[taskId] = {
        account,
        tabId: null,
        windowId: null,
        startedAt: 0,
        assignedAt: Date.now()
    };
    const completedBase = Number(data.completedCount || 0);
    await storageSet({ autoQueue: queue, activeTasks, currentIndex: completedBase + Object.keys(activeTasks).length });
    return { success: true, taskId, account, startUrl: data.startUrl || TARGET_URL, autoConfig: data.autoConfig || {} };
};

const releaseReservedTask = async (taskId, reason = '') => {
    const data = await storageGet(['autoQueue', 'activeTasks']);
    const activeTasks = data.activeTasks && typeof data.activeTasks === 'object' ? { ...data.activeTasks } : {};
    const task = activeTasks[taskId];
    if (!task) return;
    const queue = Array.isArray(data.autoQueue) ? [...data.autoQueue] : [];
    if (task.account && task.account.name) queue.unshift(task.account);
    delete activeTasks[taskId];
    await storageSet({ autoQueue: queue, activeTasks });
    if (reason) await appendLog('TASK_RELEASE ' + (task.account && task.account.name || taskId) + ' ' + reason);
};

const recordWorkerTab = async (windowId, tabId, taskId) => {
    const data = await storageGet(['bgWindowIds', 'activeAutoWindows', 'targetTabIds', 'activeWindowOpenedAt', 'activeTasks']);
    const bgWindowIds = Array.isArray(data.bgWindowIds) ? data.bgWindowIds : [];
    const activeAutoWindows = Array.isArray(data.activeAutoWindows) ? data.activeAutoWindows : [];
    const targetTabIds = data.targetTabIds && typeof data.targetTabIds === 'object' ? data.targetTabIds : {};
    const activeWindowOpenedAt = data.activeWindowOpenedAt && typeof data.activeWindowOpenedAt === 'object' ? data.activeWindowOpenedAt : {};
    const activeTasks = data.activeTasks && typeof data.activeTasks === 'object' ? { ...data.activeTasks } : {};
    if (!bgWindowIds.includes(windowId)) bgWindowIds.push(windowId);
    if (!activeAutoWindows.includes(windowId)) activeAutoWindows.push(windowId);
    if (tabId) {
        targetTabIds[String(tabId)] = true;
        activeWindowOpenedAt['tab:' + tabId] = Date.now();
    }
    if (taskId && activeTasks[taskId]) {
        activeTasks[taskId] = {
            ...activeTasks[taskId],
            tabId,
            windowId,
            assignedAt: Date.now()
        };
    }
    backgroundWindowId = windowId;
    await storageSet({
        bgWindowId: windowId,
        bgWindowIds,
        activeAutoWindows,
        activeWindowOpenedAt,
        targetTabId: tabId,
        targetTabIds,
        activeTasks,
        parallelRunnerMode: 'tabs'
    });
};

const openAutoWindow = async (url, incognito, taskId) => new Promise(resolve => {
    chrome.windows.getCurrent({ populate: false }, async (currentWin) => {
        const data = await storageGet(['bgWindowId']);
        let runnerId = data.bgWindowId || backgroundWindowId || null;
        let runner = await getWindowQuiet(runnerId);
        if (runner && incognito && !runner.incognito) runner = null;

        const finishCreated = async (tab, windowId) => {
            if (!tab || !tab.id || !windowId) {
                resolve({ success: false, error: 'TAB_CREATE_FAILED' });
                return;
            }
            await recordWorkerTab(windowId, tab.id, taskId);
            if (currentWin && currentWin.id) chrome.windows.update(currentWin.id, { focused: true }, () => { void chrome.runtime.lastError; });
            if (tab.status === 'complete') {
                chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] }).catch(() => {});
            }
            resolve({ success: true, tabId: tab.id, windowId });
        };

        if (runner && runner.id) {
            chrome.tabs.create({ windowId: runner.id, url, active: false }, async (tab) => {
                if (chrome.runtime.lastError || !tab) {
                    resolve({ success: false, error: chrome.runtime.lastError && chrome.runtime.lastError.message || 'TAB_CREATE_FAILED' });
                    return;
                }
                await finishCreated(tab, runner.id);
            });
            return;
        }

        chrome.windows.create({
            url,
            type: 'normal',
            state: 'normal',
            focused: false,
            incognito,
            width: 520,
            height: 680,
            left: 20,
            top: 20
        }, async (win) => {
            if (chrome.runtime.lastError || !win) {
                resolve({ success: false, error: chrome.runtime.lastError && chrome.runtime.lastError.message || 'Failed' });
                return;
            }
            if (incognito && !win.incognito) {
                closeWindowQuiet(win.id);
                resolve({ success: false, error: 'INCOGNITO_DISABLED' });
                return;
            }
            const tab = win.tabs && win.tabs[0];
            await finishCreated(tab, win.id);
        });
    });
});

const pumpParallelWindows = async () => {
    if (pumpInFlight) return { success: true, opened: 0, skipped: true };
    pumpInFlight = true;
    try {
        const data = await storageGet(['isRunning', 'isWaiting', 'autoQueue', 'activeTasks', 'maxParallelWindows', 'parallelWindowMode', 'parallelAuto', 'startUrl']);
        if (!data.isRunning || data.isWaiting || !data.parallelAuto) return { success: true, opened: 0 };
        const queue = Array.isArray(data.autoQueue) ? data.autoQueue : [];
        const activeTasks = data.activeTasks && typeof data.activeTasks === 'object' ? data.activeTasks : {};
        const activeCount = Object.keys(activeTasks).length;
        const pendingCount = queue.length + activeCount;
        const maxCap = Math.max(1, Math.min(4, Number(data.maxParallelWindows) || 4));
        const limit = data.parallelWindowMode === 'fixed' ? maxCap : getAdaptiveWindowLimit(pendingCount, maxCap);
        const need = Math.max(0, Math.min(limit - activeCount, queue.length));
        await storageSet({ currentParallelLimit: limit, currentParallelActive: activeCount, currentParallelPending: pendingCount, parallelRunnerMode: 'tabs' });
        let openedCount = 0;

        for (let i = 0; i < need; i += 1) {
            const reserved = await reserveNextTask();
            if (!reserved.success) break;
            const opened = await openAutoWindow(reserved.startUrl || data.startUrl || TARGET_URL, true, reserved.taskId);
            if (!opened.success) {
                await releaseReservedTask(reserved.taskId, opened.error || 'OPEN_FAILED');
                await storageSet({ isRunning: false, isWaiting: false, parallelAuto: false, lastAutoError: opened.error || 'OPEN_FAILED' });
                await appendLog('OPEN_FAILED ' + (opened.error || ''));
                return { success: false, error: opened.error || 'OPEN_FAILED', opened: openedCount };
            }
            openedCount += 1;
        }

        if (openedCount > 0) {
            await storageSet({ currentParallelActive: activeCount + openedCount });
            await appendLog('AUTO_TABS active=' + (activeCount + openedCount) + ' limit=' + limit + ' pending=' + pendingCount);
        }
        const finalData = await storageGet(['isRunning', 'autoQueue', 'activeTasks']);
        const finalQueue = Array.isArray(finalData.autoQueue) ? finalData.autoQueue : [];
        const finalActiveTasks = finalData.activeTasks && typeof finalData.activeTasks === 'object' ? finalData.activeTasks : {};
        if (finalData.isRunning && finalQueue.length === 0 && Object.keys(finalActiveTasks).length === 0) {
            setTimeout(() => finishIfDone(), 100);
        }
        return { success: true, opened: openedCount, limit };
    } finally {
        pumpInFlight = false;
    }
};

const mergeResultRows = (rows, row) => {
    const list = Array.isArray(rows) ? [...rows] : [];
    const key = accountKey(row && row.account);
    const idx = list.findIndex(item => accountKey(item && item.account) === key);
    if (idx >= 0) list[idx] = { ...list[idx], ...row };
    else list.push(row);
    return list;
};

const runAutoWatchdog = async () => {
    const data = await storageGet([
        'isRunning', 'parallelAuto', 'parallelRunnerMode', 'autoQueue', 'activeTasks', 'activeAutoWindows',
        'activeWindowOpenedAt', 'targetTabIds', 'completedCount', 'results', 'bgWindowId', 'bgWindowIds'
    ]);
    if (!data.isRunning || !data.parallelAuto) return;

    const nowMs = Date.now();
    const useTabRunner = data.parallelRunnerMode !== 'windows';
    const queue = Array.isArray(data.autoQueue) ? [...data.autoQueue] : [];
    let activeTasks = data.activeTasks && typeof data.activeTasks === 'object' ? { ...data.activeTasks } : {};
    let activeWindows = Array.isArray(data.activeAutoWindows) ? [...data.activeAutoWindows] : [];
    let bgWindowIds = Array.isArray(data.bgWindowIds) ? [...data.bgWindowIds] : [];
    const openedAt = data.activeWindowOpenedAt && typeof data.activeWindowOpenedAt === 'object' ? { ...data.activeWindowOpenedAt } : {};
    const targetTabIds = data.targetTabIds && typeof data.targetTabIds === 'object' ? { ...data.targetTabIds } : {};
    let completedCount = Number(data.completedCount || 0);
    let results = Array.isArray(data.results) ? [...data.results] : [];
    let changed = false;

    const clearTabTrack = (tabId) => {
        if (!tabId) return;
        delete targetTabIds[String(tabId)];
        delete openedAt[String(tabId)];
        delete openedAt['tab:' + tabId];
    };

    const markTaskTimeout = async (task, reason) => {
        const account = task && task.account ? { ...task.account } : null;
        const accountName = String(account && account.name || '').trim();
        const retryCount = Number(account && account.__retryCount || 0);
        if (!account || !accountName) return;

        if (retryCount < AUTO_TASK_MAX_RETRIES) {
            account.__retryCount = retryCount + 1;
            queue.unshift(account);
            await appendLog(reason + '_RETRY ' + accountName + ' ' + account.__retryCount + '/' + AUTO_TASK_MAX_RETRIES);
        } else {
            completedCount += 1;
            results = mergeResultRows(results, {
                account: accountName,
                balance: 'Timeout',
                payout: 'Error',
                payoutNumber: null,
                resetPayout: 'Error',
                resetPayoutNumber: null,
                time: new Date().toLocaleTimeString('zh-TW', { hour12: false }),
                exceeded: false,
                queryFailed: true,
                error: reason
            });
            await appendLog(reason + '_FAIL ' + accountName + ' timeout');
        }
    };

    const timedOutTaskIds = [];
    for (const [taskId, task] of Object.entries(activeTasks)) {
        const claimedAt = Number(task && task.startedAt || 0);
        const assignedAt = Number(task && task.assignedAt || 0);
        const startedAt = claimedAt || assignedAt;
        const timeoutMs = claimedAt ? AUTO_TASK_TIMEOUT_MS : AUTO_ORPHAN_WINDOW_TIMEOUT_MS;
        if (!startedAt || nowMs - startedAt < timeoutMs) continue;

        if (useTabRunner) {
            timedOutTaskIds.push(taskId);
            continue;
        }

        delete activeTasks[taskId];
        if (task && task.tabId) clearTabTrack(task.tabId);
        if (task && task.windowId) {
            activeWindows = activeWindows.filter(id => id !== task.windowId);
            delete openedAt[String(task.windowId)];
            closeWindowQuiet(task.windowId);
        }
        await markTaskTimeout(task, 'WATCHDOG');
        changed = true;
    }

    if (useTabRunner) {
        const taskTabIds = new Set(Object.values(activeTasks).map(task => String(task && task.tabId || '')).filter(Boolean));
        const staleOrphanTabs = Object.keys(targetTabIds).filter((tabIdRaw) => {
            if (taskTabIds.has(tabIdRaw)) return false;
            const ts = Number(openedAt['tab:' + tabIdRaw] || openedAt[tabIdRaw] || 0);
            return !!ts && nowMs - ts >= AUTO_ORPHAN_WINDOW_TIMEOUT_MS;
        });

        if (timedOutTaskIds.length > 0 || staleOrphanTabs.length > 0) {
            const restartWindowIds = new Set();
            if (data.bgWindowId) restartWindowIds.add(data.bgWindowId);
            if (backgroundWindowId) restartWindowIds.add(backgroundWindowId);
            activeWindows.forEach(id => restartWindowIds.add(id));
            bgWindowIds.forEach(id => restartWindowIds.add(id));

            for (const [taskId, task] of Object.entries(activeTasks)) {
                if (task && task.tabId) clearTabTrack(task.tabId);
                delete activeTasks[taskId];
                if (timedOutTaskIds.includes(taskId)) {
                    await markTaskTimeout(task, 'WINDOW_STUCK');
                } else {
                    const account = task && task.account ? { ...task.account } : null;
                    const accountName = String(account && account.name || '').trim();
                    if (accountName) {
                        queue.unshift(account);
                        await appendLog('WINDOW_RESTART_REQUEUE ' + accountName);
                    }
                }
            }

            Object.keys(targetTabIds).forEach((tabIdRaw) => {
                delete targetTabIds[tabIdRaw];
                delete openedAt[tabIdRaw];
                delete openedAt['tab:' + tabIdRaw];
            });
            activeWindows = [];
            bgWindowIds = [];
            backgroundWindowId = null;

            await storageSet({
                autoQueue: queue,
                activeTasks,
                activeAutoWindows: [],
                activeWindowOpenedAt: {},
                targetTabIds: {},
                targetTabId: null,
                bgWindowId: null,
                bgWindowIds: [],
                completedCount,
                currentIndex: completedCount,
                results,
                watchdogAt: nowMs,
                parallelRunnerMode: 'tabs'
            });
            restartWindowIds.forEach(id => closeWindowQuiet(id));
            await appendLog('WATCHDOG_RESTART_WINDOW tasks=' + timedOutTaskIds.length + ' orphanTabs=' + staleOrphanTabs.length);
            setTimeout(() => pumpParallelWindows(), 800);
            setTimeout(() => finishIfDone(), 1200);
            return;
        }
    } else {
        const taskWindowIds = new Set(Object.values(activeTasks).map(task => task && task.windowId).filter(Boolean));
        for (const windowId of [...activeWindows]) {
            if (taskWindowIds.has(windowId)) continue;
            const ts = Number(openedAt[String(windowId)] || 0);
            if (!ts || nowMs - ts < AUTO_ORPHAN_WINDOW_TIMEOUT_MS) continue;
            activeWindows = activeWindows.filter(id => id !== windowId);
            delete openedAt[String(windowId)];
            closeWindowQuiet(windowId);
            await appendLog('WATCHDOG_CLOSE_ORPHAN_WINDOW ' + windowId);
            changed = true;
        }
    }

    if (changed) {
        await storageSet({
            autoQueue: queue,
            activeTasks,
            activeAutoWindows: activeWindows,
            activeWindowOpenedAt: openedAt,
            targetTabIds,
            completedCount,
            currentIndex: completedCount + Object.keys(activeTasks).length,
            results,
            watchdogAt: nowMs
        });
        await pumpParallelWindows();
        await finishIfDone();
    }
};
const finishIfDone = async () => {
    await maybeQueuePoolForceDisables();
    const data = await storageGet([
        'isRunning', 'parallelAuto', 'autoQueue', 'activeAutoWindows', 'targetTabIds', 'activeTasks',
        'intervalMin', 'isWaiting', 'parallelRunnerMode', 'completedCount', 'totalAccounts', 'accounts'
    ]);
    if (!data.isRunning || !data.parallelAuto) return;

    const queue = Array.isArray(data.autoQueue) ? data.autoQueue : [];
    const activeWindows = Array.isArray(data.activeAutoWindows) ? data.activeAutoWindows : [];
    const targetTabIds = data.targetTabIds && typeof data.targetTabIds === 'object' ? data.targetTabIds : {};
    const activeWorkerCount = data.parallelRunnerMode !== 'windows'
        ? Object.keys(targetTabIds).filter(id => targetTabIds[id]).length
        : activeWindows.length;
    const activeTasks = data.activeTasks && typeof data.activeTasks === 'object' ? data.activeTasks : {};
    const activeTaskCount = Object.keys(activeTasks).length;
    const completedCount = Number(data.completedCount || 0);
    const plannedTotal = Number(data.totalAccounts || (Array.isArray(data.accounts) ? data.accounts.length : 0) || 0);
    const completedAllPlanned = plannedTotal > 0 && completedCount >= plannedTotal;
    const noActiveWorkers = activeWorkerCount === 0 && activeTaskCount === 0;

    if (queue.length === 0 && (noActiveWorkers || completedAllPlanned)) {
        if (completedAllPlanned && !noActiveWorkers) {
            await appendLog('FORCE_FINISH_STALE_WORKERS completed=' + completedCount + '/' + plannedTotal + ' active=' + activeWorkerCount + '/' + activeTaskCount);
        }
        await closeAutoWindows();
        const clearProgress = {
            activeTasks: {},
            activeAutoWindows: [],
            activeWindowOpenedAt: {},
            targetTabIds: {},
            targetTabId: null,
            currentParallelActive: 0,
            currentParallelPending: 0,
            currentParallelLimit: 0,
            currentIndex: completedCount,
            parallelRunnerMode: 'tabs'
        };
        if (data.intervalMin > 0 && !data.isWaiting) {
            await appendLog('WAIT_' + data.intervalMin);
            await storageSet({ ...clearProgress, isWaiting: true });
            chrome.alarms.clear(AUTO_WATCHDOG_ALARM);
            chrome.alarms.create('BEC_INTERVAL', { delayInMinutes: data.intervalMin });
        } else if (!data.intervalMin && !data.isWaiting) {
            await storageSet({ ...clearProgress, isRunning: false, isWaiting: false, parallelAuto: false });
            chrome.alarms.clear(AUTO_WATCHDOG_ALARM);
            await appendLog('FINISH');
        }
    }
};

const closeSenderWorker = async (sender) => {
    const tabId = sender && sender.tab && sender.tab.id;
    const winId = sender && sender.tab && sender.tab.windowId;
    const data = await storageGet(['parallelRunnerMode', 'targetTabIds', 'activeWindowOpenedAt']);
    const targetTabIds = data.targetTabIds && typeof data.targetTabIds === 'object' ? { ...data.targetTabIds } : {};
    const openedAt = data.activeWindowOpenedAt && typeof data.activeWindowOpenedAt === 'object' ? { ...data.activeWindowOpenedAt } : {};
    if (tabId) {
        delete targetTabIds[String(tabId)];
        delete openedAt[String(tabId)];
        delete openedAt['tab:' + tabId];
    }
    await storageSet({ targetTabIds, activeWindowOpenedAt: openedAt });
    if (data.parallelRunnerMode !== 'windows') {
        if (tabId) setTimeout(() => closeTabQuiet(tabId), 250);
    } else if (winId) {
        setTimeout(() => closeWindowQuiet(winId), 250);
    }
};

const claimTask = async (sender, sendResponse) => {
    const tabId = sender && sender.tab && sender.tab.id;
    const data = await storageGet(['isRunning', 'activeTasks', 'targetTabIds', 'autoConfig', 'startUrl']);
    if (!data.isRunning) {
        sendResponse({ success: false, done: true });
        await closeSenderWorker(sender);
        return;
    }

    const activeTasks = data.activeTasks && typeof data.activeTasks === 'object' ? { ...data.activeTasks } : {};
    const assignedEntry = Object.entries(activeTasks).find(([, task]) => String(task && task.tabId || '') === String(tabId));
    if (!assignedEntry) {
        sendResponse({ success: false, done: true, error: 'NO_ASSIGNED_TASK' });
        await appendLog('NO_ASSIGNED_TASK tab=' + (tabId || 'unknown'));
        await closeSenderWorker(sender);
        setTimeout(() => pumpParallelWindows(), 500);
        return;
    }

    const [taskId, task] = assignedEntry;
    if (!task || !task.account || !task.account.name) {
        delete activeTasks[taskId];
        await storageSet({ activeTasks });
        sendResponse({ success: false, done: true, error: 'BAD_ASSIGNED_TASK' });
        await closeSenderWorker(sender);
        setTimeout(() => pumpParallelWindows(), 500);
        return;
    }

    activeTasks[taskId] = {
        ...task,
        startedAt: Date.now()
    };
    await storageSet({ activeTasks });
    sendResponse({ success: true, taskId, account: task.account, startUrl: data.startUrl || TARGET_URL, autoConfig: data.autoConfig || {} });
};

const taskDone = async (message, sender, sendResponse) => {
    const data = await storageGet(['activeTasks', 'completedCount', 'activeAutoWindows', 'targetTabIds', 'activeWindowOpenedAt', 'parallelRunnerMode']);
    const activeTasks = data.activeTasks && typeof data.activeTasks === 'object' ? { ...data.activeTasks } : {};
    const hadTask = !!(message.taskId && activeTasks[message.taskId]);
    if (hadTask) delete activeTasks[message.taskId];
    const completedCount = Number(data.completedCount || 0) + (hadTask ? 1 : 0);
    const tabId = sender && sender.tab && sender.tab.id;
    const windowId = sender && sender.tab && sender.tab.windowId;
    const targetTabIds = data.targetTabIds && typeof data.targetTabIds === 'object' ? { ...data.targetTabIds } : {};
    const openedAt = data.activeWindowOpenedAt && typeof data.activeWindowOpenedAt === 'object' ? { ...data.activeWindowOpenedAt } : {};
    if (tabId) {
        delete targetTabIds[String(tabId)];
        delete openedAt[String(tabId)];
        delete openedAt['tab:' + tabId];
    }
    await storageSet({ activeTasks, completedCount, currentIndex: completedCount, targetTabIds, activeWindowOpenedAt: openedAt });
    if (!hadTask) await appendLog('TASK_DONE_IGNORED ' + (message.account || message.taskId || 'unknown'));
    sendResponse({ success: true, ignored: !hadTask });
    setTimeout(async () => {
        await pumpParallelWindows();
        if (data.parallelRunnerMode !== 'windows') {
            if (tabId) closeTabQuiet(tabId);
        } else if (windowId) {
            closeWindowQuiet(windowId);
        }
        await finishIfDone();
    }, 300);
};
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'YONGXU_CVS_SCAN_RESULT') {
        handleYongxuCvsScanResult(message).then(sendResponse).catch(err => sendResponse({ success: false, error: err && err.message || String(err) }));
        return true;
    }

    if (message.action === 'CREATE_PARALLEL_WINDOWS') {
        sendResponse({ success: true });
        (async () => {
            chrome.alarms.clear('BEC_INTERVAL');
            chrome.alarms.clear(AUTO_WATCHDOG_ALARM);
            await closeAutoWindows();
            chrome.alarms.create(AUTO_WATCHDOG_ALARM, { periodInMinutes: 1 });
            await storageSet({ parallelAuto: true, parallelRunnerMode: 'tabs', parallelWindowMode: message.mode === 'fixed' ? 'fixed' : 'auto', maxParallelWindows: Math.max(1, Math.min(4, Number(message.maxLimit || message.limit || 4))) });
            const pumped = await pumpParallelWindows();
            if (pumped && pumped.success === false) await appendLog('PARALLEL_START_FAILED ' + (pumped.error || ''));
        })().catch(err => appendLog('PARALLEL_START_ERR ' + (err && err.message || String(err))));
        return false;
    }

    if (message.action === 'CLAIM_AUTO_TASK') {
        claimTask(sender, sendResponse).catch(err => sendResponse({ success: false, error: err && err.message || String(err) }));
        return true;
    }

    if (message.action === 'AUTO_TASK_DONE') {
        taskDone(message, sender, sendResponse).catch(err => sendResponse({ success: false, error: err && err.message || String(err) }));
        return true;
    }

    if (message.action === 'CREATE_BACKGROUND_WINDOW') {
        (async () => {
            chrome.alarms.clear('BEC_INTERVAL');
            await closeAutoWindows();
            await storageSet({ parallelAuto: false, parallelRunnerMode: 'tabs' });
            const opened = await openAutoWindow(message.url || TARGET_URL, message.incognito !== false);
            sendResponse(opened);
        })().catch(err => sendResponse({ success: false, error: err && err.message || String(err) }));
        return true;
    }

    if (message.action === 'CLOSE_BACKGROUND_WINDOW') {
        (async () => {
            chrome.alarms.clear('BEC_INTERVAL');
            chrome.alarms.clear(AUTO_WATCHDOG_ALARM);
            await storageSet({ isRunning: false, isWaiting: false, parallelAuto: false, parallelRunnerMode: 'tabs' });
            await closeAutoWindows();
            sendResponse({ success: true });
        })().catch(err => sendResponse({ success: false, error: err && err.message || String(err) }));
        return true;
    }

    if (message.action === 'DEBUG_LOG') {
        appendLog(message.text || '');
        return false;
    }

    if (message.action === 'STOP_TTS') {
        return false;
    }

    if (message.action === 'SHOW_ALERT') {
        // SHOW_ALERT_TO_PET: keep the page pet in sync with regular limit/disable alerts.
        broadcastPetSay(message.message || message.title || 'BEC 提醒', 'alert').catch(() => {});
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (tabs.length > 0 && tabs[0].url && tabs[0].url.startsWith('http')) {
                chrome.scripting.executeScript({
                    target: { tabId: tabs[0].id },
                    func: (msg, accName) => {
                        const divId = 'bec-alert-' + accName;
                        if (document.getElementById(divId)) return;
                        const div = document.createElement('div');
                        div.id = divId;
                        div.style.position = 'fixed';
                        div.style.top = '6px';
                        div.style.right = '320px';
                        div.style.backgroundColor = '#ff4d4f';
                        div.style.color = '#fff';
                        div.style.padding = '6px 14px';
                        div.style.fontSize = '14px';
                        div.style.fontWeight = 'bold';
                        div.style.fontFamily = 'sans-serif';
                        div.style.borderRadius = '4px';
                        div.style.boxShadow = '0 2px 10px rgba(0,0,0,0.5)';
                        div.style.zIndex = '2147483647';
                        div.style.display = 'flex';
                        div.style.alignItems = 'center';
                        div.style.gap = '12px';
                        div.innerHTML = '<span>警告 ' + msg + '</span><button class="bec-alert-close-btn" style="background:#fff; color:#ff4d4f; border:none; padding:4px 10px; border-radius:4px; cursor:pointer; font-weight:bold; font-size:12px; outline:none;">已確認</button>';
                        div.querySelector('.bec-alert-close-btn').addEventListener('click', () => {
                            div.remove();
                            chrome.runtime.sendMessage({ action: 'STOP_TTS' });
                        });
                        document.body.appendChild(div);
                    },
                    args: [message.message, message.account]
                }).catch(() => {});
            }
        });
        chrome.notifications.create({
            type: 'basic',
            title: message.title || 'BEC LITE',
            message: message.message || '',
            priority: 2,
            requireInteraction: true,
            iconUrl: chrome.runtime.getURL('icon128.png')
        }, () => { if (chrome.runtime.lastError) console.warn('Notification failed:', chrome.runtime.lastError.message); });
        return false;
    }


    if (message.action === 'START_TRC_MONITOR') {
        startTrcMonitor(message.settings || {})
            .then(result => sendResponse(result))
            .catch(async err => {
                await storageSet({ trcMonitorSettings: { ...(await storageGet(['trcMonitorSettings'])).trcMonitorSettings, enabled: false, lastError: err && err.message || String(err) } });
                sendResponse({ success: false, error: err && err.message || String(err) });
            });
        return true;
    }

    if (message.action === 'STOP_TRC_MONITOR') {
        stopTrcMonitor()
            .then(result => sendResponse(result))
            .catch(err => sendResponse({ success: false, error: err && err.message || String(err) }));
        return true;
    }

    if (message.action === 'CHECK_TRC_MONITOR') {
        (async () => {
            const current = await storageGet(['trcMonitorSettings']);
            const mergedSettings = { ...(current.trcMonitorSettings || {}), ...(message.settings || {}) };
            const result = await runTrcMonitorOnce({ force: true, baseline: !(current.trcMonitorSettings && current.trcMonitorSettings.enabled), overrideSettings: mergedSettings });
            sendResponse(result);
        })().catch(err => sendResponse({ success: false, error: err && err.message || String(err) }));
        return true;
    }

    if (message.action === 'EVALUATE_USDT_RISK') {
        evaluateUsdtRisk(message.address, { source: message.source, pageUrl: message.pageUrl })
            .then(result => sendResponse(result))
            .catch(err => sendResponse({ success: false, error: err && err.message || String(err) }));
        return true;
    }

    if (message.action === 'GET_RISK_AUDIT_LOG') {
        storageGet(['riskAuditLog', 'riskLastResult'])
            .then(data => sendResponse({ success: true, auditLog: data.riskAuditLog || [], lastResult: data.riskLastResult || null }))
            .catch(err => sendResponse({ success: false, error: err && err.message || String(err) }));
        return true;
    }
    if (message.action === 'START_INTERVAL') {
        chrome.alarms.create('BEC_INTERVAL', { delayInMinutes: message.minutes });
        chrome.alarms.clear(AUTO_WATCHDOG_ALARM);
        closeAutoWindows();
        sendResponse({ success: true });
        return true;
    }
});

chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === AUTO_WATCHDOG_ALARM) {
        runAutoWatchdog()
            .then(() => finishIfDone())
            .catch(err => appendLog('WATCHDOG_ERR ' + (err && err.message || String(err))));
        return;
    }
    if (alarm.name === TRC_MONITOR_ALARM) {
        runTrcMonitorOnce()
            .catch(async err => {
                const data = await storageGet(['trcMonitorSettings']);
                await storageSet({ trcMonitorSettings: { ...(data.trcMonitorSettings || {}), lastError: err && err.message || String(err) } });
                await appendLog('TRC_MONITOR_ERR ' + (err && err.message || String(err)));
            });
        return;
    }
    if (alarm.name !== 'BEC_INTERVAL') return;
    chrome.storage.local.get(['isRunning', 'accounts'], async (data) => {
        if (!data.isRunning) return;
        await appendLog('啟動背景查詢');
        chrome.alarms.create(AUTO_WATCHDOG_ALARM, { periodInMinutes: 1 });
        await storageSet({
            autoQueue: Array.isArray(data.accounts) ? data.accounts : [],
            activeTasks: {},
            activeAutoWindows: [],
            activeWindowOpenedAt: {},
            targetTabIds: {},
            parallelRunnerMode: 'tabs',
            completedCount: 0,
            currentIndex: 0,
            step: 'SEARCH',
            isWaiting: false,
            startUrl: TARGET_URL,
            poolStatus: {},
            currentPeriodKey: '',
            forceDisableQueue: [],
            poolForceMembers: {}
        });
        await pumpParallelWindows();
    });
});
chrome.windows.onRemoved.addListener((windowId) => {
    (async () => {
        const data = await storageGet(['activeAutoWindows', 'bgWindowIds', 'bgWindowId', 'targetTabIds', 'activeWindowOpenedAt', 'isWaiting', 'isRunning', 'parallelAuto', 'parallelRunnerMode', 'activeTasks', 'autoQueue', 'completedCount']);
        const activeAutoWindows = (Array.isArray(data.activeAutoWindows) ? data.activeAutoWindows : []).filter(id => id !== windowId);
        const bgWindowIds = (Array.isArray(data.bgWindowIds) ? data.bgWindowIds : []).filter(id => id !== windowId);
        const activeWindowOpenedAt = data.activeWindowOpenedAt && typeof data.activeWindowOpenedAt === 'object' ? { ...data.activeWindowOpenedAt } : {};
        delete activeWindowOpenedAt[String(windowId)];
        const patch = { activeAutoWindows, bgWindowIds, activeWindowOpenedAt };
        const isRunnerWindow = data.bgWindowId === windowId || backgroundWindowId === windowId;
        if (isRunnerWindow) {
            backgroundWindowId = null;
            patch.bgWindowId = bgWindowIds[0] || null;
            if (data.parallelRunnerMode !== 'windows') {
                patch.targetTabIds = {};
                patch.activeWindowOpenedAt = {};
                if (data.parallelAuto && data.isRunning !== false) {
                    const activeTasks = data.activeTasks && typeof data.activeTasks === 'object' ? { ...data.activeTasks } : {};
                    const queue = Array.isArray(data.autoQueue) ? [...data.autoQueue] : [];
                    let requeued = 0;
                    Object.entries(activeTasks).forEach(([, task]) => {
                        const account = task && task.account ? { ...task.account } : null;
                        const accountName = String(account && account.name || '').trim();
                        if (accountName) {
                            queue.unshift(account);
                            requeued += 1;
                        }
                    });
                    patch.autoQueue = queue;
                    patch.activeTasks = {};
                    patch.currentIndex = Number(data.completedCount || 0);
                    if (requeued > 0) await appendLog('RUNNER_WINDOW_CLOSED_REQUEUE ' + requeued);
                }
            }
        }
        await storageSet(patch);
        if (data.parallelAuto && data.isRunning !== false) {
            await pumpParallelWindows();
            await finishIfDone();
        } else if (isRunnerWindow && !data.isWaiting) {
            await storageSet({ isRunning: false, isWaiting: false, parallelAuto: false, parallelRunnerMode: 'tabs' });
            chrome.alarms.clear('BEC_INTERVAL');
        }
    })();
});

chrome.tabs.onRemoved.addListener((tabId) => {
    (async () => {
        const data = await storageGet(['isRunning', 'parallelAuto', 'parallelRunnerMode', 'targetTabIds', 'activeWindowOpenedAt', 'activeTasks', 'autoQueue', 'completedCount', 'results']);
        if (!data.parallelAuto || data.parallelRunnerMode === 'windows') return;
        const targetTabIds = data.targetTabIds && typeof data.targetTabIds === 'object' ? { ...data.targetTabIds } : {};
        const openedAt = data.activeWindowOpenedAt && typeof data.activeWindowOpenedAt === 'object' ? { ...data.activeWindowOpenedAt } : {};
        const activeTasks = data.activeTasks && typeof data.activeTasks === 'object' ? { ...data.activeTasks } : {};
        const queue = Array.isArray(data.autoQueue) ? [...data.autoQueue] : [];
        let completedCount = Number(data.completedCount || 0);
        let results = Array.isArray(data.results) ? [...data.results] : [];
        let changed = false;

        if (targetTabIds[String(tabId)]) {
            delete targetTabIds[String(tabId)];
            changed = true;
        }
        delete openedAt[String(tabId)];
        delete openedAt['tab:' + tabId];

        const taskEntry = Object.entries(activeTasks).find(([, task]) => String(task && task.tabId || '') === String(tabId));
        if (taskEntry) {
            const [taskId, task] = taskEntry;
            delete activeTasks[taskId];
            const account = task && task.account ? { ...task.account } : null;
            const accountName = String(account && account.name || '').trim();
            const retryCount = Number(account && account.__retryCount || 0);
            if (account && retryCount < AUTO_TASK_MAX_RETRIES) {
                account.__retryCount = retryCount + 1;
                queue.unshift(account);
                await appendLog('TAB_CLOSED_RETRY ' + accountName + ' ' + account.__retryCount + '/' + AUTO_TASK_MAX_RETRIES);
            } else if (account) {
                completedCount += 1;
                results = mergeResultRows(results, {
                    account: accountName,
                    balance: 'Closed',
                    payout: 'Error',
                    payoutNumber: null,
                    resetPayout: 'Error',
                    resetPayoutNumber: null,
                    time: new Date().toLocaleTimeString('zh-TW', { hour12: false }),
                    exceeded: false,
                    queryFailed: true,
                    error: 'TAB_CLOSED'
                });
                await appendLog('TAB_CLOSED_FAIL ' + accountName);
            }
            changed = true;
        }

        if (changed) {
            await storageSet({
                autoQueue: queue,
                activeTasks,
                activeWindowOpenedAt: openedAt,
                targetTabIds,
                completedCount,
                currentIndex: completedCount + Object.keys(activeTasks).length,
                results
            });
            if (data.isRunning !== false) await pumpParallelWindows();
            await finishIfDone();
        }
    })();
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
    if (changeInfo.status !== 'complete') return;
    chrome.storage.local.get(['isRunning', 'targetTabId', 'targetTabIds'], (data) => {
        const targetTabIds = data.targetTabIds && typeof data.targetTabIds === 'object' ? data.targetTabIds : {};
        if (!data.isRunning || (data.targetTabId !== tabId && !targetTabIds[String(tabId)])) return;
        chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] }).catch(() => {});
    });
});
const recoverAutoStateOnLoad = async () => {
    const data = await storageGet(['isRunning', 'parallelAuto', 'isWaiting']);
    if (!data.isRunning || !data.parallelAuto || data.isWaiting) return;
    chrome.alarms.create(AUTO_WATCHDOG_ALARM, { periodInMinutes: 1 });
    setTimeout(() => finishIfDone(), 500);
    setTimeout(() => runAutoWatchdog().catch(err => appendLog('WATCHDOG_ERR ' + (err && err.message || String(err)))), 1000);
};

recoverAutoStateOnLoad().catch(err => appendLog('RECOVER_AUTO_STATE_ERR ' + (err && err.message || String(err))));
recoverTrcMonitorOnLoad().catch(err => appendLog('RECOVER_TRC_MONITOR_ERR ' + (err && err.message || String(err))));
cleanupYongxuCvsDailyMemory().catch(err => appendLog('YONGXU_CVS_DAILY_CLEANUP_ERR ' + (err && err.message || String(err))));
