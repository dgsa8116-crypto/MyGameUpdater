Momo original generated voice pack.
These WAV files are procedurally synthesized animal/anime-style cues.
They do not contain sampled third-party audio, TTS output, or cloned character/actor voices.
Generated for this local Chrome extension.
comic uncle cues are original synthesized comedic shout-style effects, not based on any named character voice.

horror-call cues are original creepy phone-ring style effects and do not copy a movie/game ringtone melody.

weather-radio voice cues are locally synthesized announcement-style clips with radio filtering; they are not clones of the provided reference recording.
