const TARGET_URL = 'https://b9a9vnfik.becgame88168.com/index/Home';
let backgroundWindowId = null;

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'CREATE_BACKGROUND_WINDOW') {
        const { url = TARGET_URL, incognito = true } = message;

        const doCreate = () => {
            chrome.alarms.clear('BEC_INTERVAL');
            
            chrome.windows.getCurrent({ populate: false }, (currentWin) => {
                const windowConfig = {
                    url,
                    type: 'normal',
                    state: 'normal',
                    focused: false,
                    incognito,
                    width: 600,
                    height: 600
                };

                chrome.windows.create(windowConfig, (win) => {
                    if (chrome.runtime.lastError || !win) {
                        sendResponse({ success: false, error: chrome.runtime.lastError?.message || 'Failed' });
                        return;
                    }
                    if (incognito && !win.incognito) {
                        chrome.windows.remove(win.id, () => { void chrome.runtime.lastError; });
                        sendResponse({ success: false, error: 'INCOGNITO_DISABLED' });
                        return;
                    }

                    if (currentWin && currentWin.id) {
                        chrome.windows.update(currentWin.id, { focused: true });
                    }

                    backgroundWindowId = win.id;
                    const tabId = win.tabs[0].id;
                    chrome.storage.local.set(
                        { targetTabId: tabId, bgWindowId: win.id },
                        () => {
                            if (win.tabs[0].status === 'complete') {
                                chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] }).catch(()=>{});
                            }
                            sendResponse({ success: true, tabId });
                        }
                    );
                });
            });
        };

        chrome.storage.local.get(['bgWindowId'], (data) => {
            const toClose = backgroundWindowId || data.bgWindowId;
            if (toClose) {
                chrome.windows.remove(toClose, () => {
                    void chrome.runtime.lastError;
                    backgroundWindowId = null;
                    doCreate();
                });
            } else {
                doCreate();
            }
        });
        return true;
    }

    if (message.action === 'CLOSE_BACKGROUND_WINDOW') {
        chrome.alarms.clear('BEC_INTERVAL');
        chrome.storage.local.get(['bgWindowId'], (data) => {
            const wid = backgroundWindowId || data.bgWindowId;
            if (wid) {
                chrome.windows.remove(wid, () => { void chrome.runtime.lastError; });
                backgroundWindowId = null;
                chrome.storage.local.remove(['bgWindowId', 'targetTabId']);
            }
            sendResponse({ success: true });
        });
        return true;
    }

    if (message.action === 'DEBUG_LOG') {
        chrome.storage.local.get(['debugLog'], (data) => {
            const log = data.debugLog || [];
            log.push(`[${new Date().toLocaleTimeString('zh-TW', { hour12: false })}] ${message.text}`);
            if (log.length > 40) log.shift();
            chrome.storage.local.set({ debugLog: log });
        });
        return false;
    }

    if (message.action === 'STOP_TTS') {
        if (chrome.tts) {
            chrome.tts.stop();
        }
        return false;
    }

    if (message.action === 'SHOW_ALERT') {
        // 確保音量設定為系統允許的最大極限 (1.0)
        if (chrome.tts) {
            chrome.tts.speak(message.message, { 
                lang: 'zh-TW', 
                rate: 1.0,
                volume: 1.0, 
                enqueue: true
            });
        }

        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (tabs.length > 0 && tabs[0].url && tabs[0].url.startsWith('http')) {
                chrome.scripting.executeScript({
                    target: { tabId: tabs[0].id },
                    func: (msg, accName) => {
                        const divId = 'bec-alert-' + accName;
                        if (document.getElementById(divId)) return; 

                        const div = document.createElement('div');
                        div.id = divId;
                        div.style.position = 'fixed';
                        div.style.top = '6px'; 
                        div.style.right = '320px'; 
                        div.style.backgroundColor = '#ff4d4f';
                        div.style.color = '#fff';
                        div.style.padding = '6px 14px';
                        div.style.fontSize = '14px';
                        div.style.fontWeight = 'bold';
                        div.style.fontFamily = 'sans-serif';
                        div.style.borderRadius = '4px';
                        div.style.boxShadow = '0 2px 10px rgba(0,0,0,0.5)';
                        div.style.zIndex = '2147483647';
                        div.style.display = 'flex';
                        div.style.alignItems = 'center';
                        div.style.gap = '12px';
                        
                        div.innerHTML = `
                            <span>⚠️ ${msg}</span>
                            <button class="bec-alert-close-btn" style="background:#fff; color:#ff4d4f; border:none; padding:4px 10px; border-radius:4px; cursor:pointer; font-weight:bold; font-size:12px; outline:none;">已確認</button>
                        `;
                        
                        div.querySelector('.bec-alert-close-btn').addEventListener('click', () => {
                            div.remove();
                            chrome.runtime.sendMessage({ action: 'STOP_TTS' });
                        });

                        document.body.appendChild(div);
                    },
                    args: [message.message, message.account]
                }).catch(() => {});
            }
        });

        chrome.notifications.create({
            type: 'basic',
            title: message.title,
            message: message.message,
            priority: 2,
            requireInteraction: true,
            iconUrl: 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAxMDAgMTAwIj48Y2lyY2xlIGN4PSI1MCIgY3k9IjUwIiByPSI0MCIgZmlsbD0iI2ZmMzMzMyIvPjx0ZXh0IHg9IjUwIiB5PSI3NSIgZm9udC1zaXplPSI2NSIgZm9udC1mYW1pbHk9ImFyaWFsIiBmb250LXdlaWdodD0iYm9sZCIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZmlsbD0iI2ZmZmZmZiI+ITwvdGV4dD48L3N2Zz4='
        });
        return false;
    }

    if (message.action === 'START_INTERVAL') {
        chrome.alarms.create('BEC_INTERVAL', { delayInMinutes: message.minutes });
        chrome.storage.local.get(['bgWindowId'], (data) => {
            const wid = backgroundWindowId || data.bgWindowId;
            if (wid) {
                chrome.windows.remove(wid, () => { void chrome.runtime.lastError; });
                backgroundWindowId = null;
                chrome.storage.local.remove(['bgWindowId', 'targetTabId']);
            }
        });
        sendResponse({ success: true });
        return true;
    }
});

chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === 'BEC_INTERVAL') {
        chrome.storage.local.get(['isRunning', 'debugLog'], (data) => {
            if (data.isRunning) {
                const log = data.debugLog || [];
                log.push(`[${new Date().toLocaleTimeString('zh-TW', { hour12: false })}] 啟動背景查詢`);
                if (log.length > 40) log.shift();

                chrome.storage.local.set({ 
                    currentIndex: 0,
                    step: 'SEARCH',
                    isWaiting: false,
                    startUrl: TARGET_URL,
                    debugLog: log,
                    poolStatus: {},
                    currentPeriodKey: '',
                    forceDisableQueue: [],
                    poolForceMembers: {},
                    disabledAccounts: {}
                }, () => {
                    chrome.windows.getCurrent({ populate: false }, (currentWin) => {
                        const windowConfig = { 
                            url: TARGET_URL, 
                            type: 'normal', 
                            state: 'normal',
                            focused: false, 
                            incognito: true,
                            width: 600,
                            height: 600
                        };
                        chrome.windows.create(windowConfig, (win) => {
                            if (!chrome.runtime.lastError && win) {
                                if (currentWin && currentWin.id) {
                                    chrome.windows.update(currentWin.id, { focused: true });
                                }
                                
                                backgroundWindowId = win.id;
                                const tabId = win.tabs[0].id;
                                chrome.storage.local.set({ targetTabId: tabId, bgWindowId: win.id }, () => {
                                    if (win.tabs[0].status === 'complete') {
                                        chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] }).catch(()=>{});
                                    }
                                });
                            }
                        });
                    });
                });
            }
        });
    }
});

chrome.windows.onRemoved.addListener((windowId) => {
    chrome.storage.local.get(['bgWindowId', 'isWaiting'], (data) => {
        if (data.bgWindowId === windowId || backgroundWindowId === windowId) {
            backgroundWindowId = null;
            chrome.storage.local.remove(['bgWindowId', 'targetTabId']);
            if (!data.isWaiting) {
                chrome.storage.local.set({ isRunning: false, isWaiting: false });
                chrome.alarms.clear('BEC_INTERVAL');
            }
        }
    });
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status !== 'complete') return;
    chrome.storage.local.get(['isRunning', 'targetTabId'], (data) => {
        if (!data.isRunning || data.targetTabId !== tabId) return;
        chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] }).catch(() => {});
    });
});