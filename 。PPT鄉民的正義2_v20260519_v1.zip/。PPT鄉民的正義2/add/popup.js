document.addEventListener('DOMContentLoaded', () => {
    const $ = (sel, ctx = document) => ctx.querySelector(sel);
    const $$ = (sel, ctx = document) => [...ctx.querySelectorAll(sel)];

    const todayStr = () => {
        const d = new Date();
        return `${d.getFullYear()}/${String(d.getMonth() + 1).padStart(2, '0')}/${String(d.getDate()).padStart(2, '0')}`;
    };

    function showToast(msg = '已複製到剪貼簿') {
        const t = $('#toast');
        t.textContent = msg;
        t.classList.add('show');
        setTimeout(() => t.classList.remove('show'), 1500);
    }

    async function copyText(text) {
        if (!text || text === '無資料') return;
        await navigator.clipboard.writeText(text.trim());
        showToast();
    }

    function switchTab(targetId) {
        $$('.nav-btn').forEach(b => b.classList.remove('active'));
        $$('.tab-pane').forEach(p => p.classList.remove('active'));
        const btn = $(`.nav-btn[data-target="${targetId}"]`);
        const pane = $(`#${targetId}`);
        if (btn) btn.classList.add('active');
        if (pane) pane.classList.add('active');
        return pane;
    }

    $('.nav-container').addEventListener('click', (e) => {
        const btn = e.target.closest('.nav-btn');
        if (btn) switchTab(btn.dataset.target);
    });

    const fieldVal = (pane, field) => $(`input[data-field="${field}"]`, pane)?.value || '';

    $('.content').addEventListener('click', (e) => {
        const btn = e.target.closest('.js-copy');
        if (!btn) return;

        const pane = btn.closest('.tab-pane');
        const key = btn.dataset.copy;
        let text = '';

        switch (key) {
            case 'deposit-format': {
                let method = fieldVal(pane, 'method');
                if (!method || method === '無資料') method = '入款';
                text = [todayStr(), method, fieldVal(pane, 'no'), fieldVal(pane, 'acc'), fieldVal(pane, 'amt')].join('\t');
                break;
            }
            case 'usdt-deposit-format': {
                text = [todayStr(), '入款', fieldVal(pane, 'no'), fieldVal(pane, 'acc'), fieldVal(pane, 'amt')].join('\t');
                break;
            }
            case 'withdraw-format': {
                text = [todayStr(), '出款', fieldVal(pane, 'no'), fieldVal(pane, 'acc'), '', fieldVal(pane, 'amt')].join('\t');
                break;
            }
            case 'fuding-template': {
                const v = (f) => fieldVal(pane, f);
                text = [
                    '【代付確認提單】',
                    `交易編號 ${v('no')}`,
                    `銀行名稱 ${v('bankName')}`,
                    `銀行代碼 ( ${v('bankCode')} )`,
                    `銀行帳號 ${v('acc')}`,
                    `分行 ${v('branch')}`,
                    `金額 ${v('amt')}`
                ].join('\n');
                break;
            }
            case 'sirius-template': {
                const v = (f) => fieldVal(pane, f);
                text = [
                    `單號：${v('no')}`,
                    `金額：${v('amt')}`,
                    `銀行：${v('bankName')}`,
                    `帳號：${v('acc')}`,
                    `姓名：${v('name')}`
                ].join('\n');
                break;
            }
            case 'time': {
                text = fieldVal(pane, 'time');
                break;
            }
            default: {
                text = key.split(',').map(f => fieldVal(pane, f)).join('\t');
            }
        }
        copyText(text);
    });

    $('.content').addEventListener('click', async (e) => {
        const btn = e.target.closest('.js-fetch');
        if (!btn) return;
        const pane = btn.closest('.tab-pane');
        await fetchAndFill(pane);
    });

    async function fetchAndFill(pane) {
        const { type, usdt } = pane.dataset;
        const isUsdt = usdt === 'true';
        const pill = $('.js-status', pane);

        pill.textContent = '掃描中';
        pill.className = 'pill js-status scanning';

        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            
            if (!tab || !tab.url || !tab.url.startsWith('http')) {
                pill.textContent = '無效頁面';
                pill.className = 'pill js-status error';
                return null;
            }

            const results = await chrome.scripting.executeScript({
                target: { tabId: tab.id, allFrames: true },
                func: grabPageData,
                args: [type, isUsdt]
            });

            const data = {};
            for (const { result } of results) {
                if (!result) continue;
                for (const [k, v] of Object.entries(result)) {
                    if (v && !data[k]) data[k] = v;
                }
            }

            if ((type === 'fuding' || type === 'sirius') && data.amt) {
                data.amt = Number(data.amt.replace(/,/g, '')).toLocaleString();
            }

            $$('input[data-field]', pane).forEach(input => {
                input.value = data[input.dataset.field] || '無資料';
            });

            const ok = !!data.no;
            pill.textContent = ok ? '就緒' : '查無資料';
            pill.className = 'pill js-status ' + (ok ? 'online' : 'error');

            return data;
        } catch (err) {
            pill.textContent = '錯誤';
            pill.className = 'pill js-status error';
            return null;
        }
    }

    async function autoDetect() {
        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            if (!tab || !tab.url || !tab.url.startsWith('http')) return;

            const probeResults = await chrome.scripting.executeScript({
                target: { tabId: tab.id, allFrames: true },
                func: probePageType
            });

            let orderNo = '';
            let bankRaw = '';
            for (const { result } of probeResults) {
                if (!result) continue;
                if (result.orderNo && !orderNo) orderNo = result.orderNo;
                if (result.bankRaw && !bankRaw) bankRaw = result.bankRaw;
            }

            const prefix = orderNo.charAt(0).toUpperCase();
            const bankUpper = bankRaw.toUpperCase();

            let targetTab = 'tab-deposit';

            if (prefix === 'D') {
                if (bankUpper.includes('USDT') || bankUpper.includes('TRC')) targetTab = 'tab-usdt-deposit';
                else targetTab = 'tab-deposit';
            } else if (prefix === 'W') {
                if (bankUpper.includes('USDT') || bankUpper.includes('TRC')) targetTab = 'tab-usdt-withdraw';
                else targetTab = 'tab-withdraw';
            }

            const pane = switchTab(targetTab);
            if (pane) await fetchAndFill(pane);
        } catch (err) {}
    }

    function probePageType() {
        const tds = Array.from(document.querySelectorAll('td'));
        let orderNo = '';
        let bankRaw = '';
        const orderLabels = ['存款單號', '提款單號', '單號'];
        const bankLabels = ['銀行', '收款銀行', '收款方式', '付款方式', '支付方式', '存款方式', '通道名稱'];

        for (const td of tds) {
            const txt = td.innerText.replace(/[\s\u200B-\u200D\uFEFF]+/g, '');
            if (!txt || txt.length > 20) continue; 
            if (!orderNo && orderLabels.some(l => txt === l || txt === l + ':' || txt === l + '：')) {
                const next = td.nextElementSibling;
                if (next?.tagName === 'TD') orderNo = next.innerText.trim();
            }
            if (!bankRaw && bankLabels.some(l => txt === l || txt === l + ':' || txt === l + '：')) {
                const next = td.nextElementSibling;
                if (next?.tagName === 'TD') bankRaw = next.innerText.trim();
            }
            if (orderNo && bankRaw) break;
        }
        return { orderNo, bankRaw };
    }

    function grabPageData(type, isUsdt) {
        const tds = Array.from(document.querySelectorAll('td'));

        const getVal = (labels, isAmount = false) => {
            for (const td of tds) {
                const txt = td.innerText.replace(/[\s\u200B-\u200D\uFEFF]+/g, '');
                if (!txt || txt.length > 20) continue;

                if (!labels.some(l => txt === l || txt === l + ':' || txt === l + '：')) continue;

                const next = td.nextElementSibling;
                if (!next || next.tagName !== 'TD') continue;
                const raw = next.innerText.trim();

                if (!raw) continue;
                if (!isAmount) return raw;

                if (isUsdt) {
                    const m = raw.match(/([\d,.]+)[^\d]*USDT/i);
                    if (m) return m[1].replace(/,/g, '');
                    continue; 
                }

                if (raw.toUpperCase().includes('USDT') && (type !== 'withdraw' && type !== 'fuding' && type !== 'sirius')) continue;
                
                const numMatch = raw.match(/[\d,.]+/);
                return numMatch ? numMatch[0].replace(/,/g, '') : raw;
            }
            return '';
        };

        function detectMethod() {
            const methodRules = [
                [['支付寶', 'ALIPAY'], '支付寶'],
                [['微信', 'WECHAT', 'WXPAY'], '微信'],
                [['超商', '便利商店', 'CVS', 'IBON'], '超商'],
                [['銀聯', 'UNIONPAY', 'CUP'], '銀聯'],
                [['LINEPAY', 'LINE PAY'], 'LinePay'],
                [['JKOPAY', '街口'], '街口支付'],
                [['USDT', 'TRC', 'ERC', '虛擬貨幣'], 'USDT'],
                [['網銀', '銀行轉帳'], '網銀'],
                [['ATM'], 'ATM'],
            ];

            function matchMethod(text) {
                const upper = text.toUpperCase();
                for (const [keywords, label] of methodRules) {
                    if (keywords.some(kw => upper.includes(kw.toUpperCase()))) return label;
                }
                return '';
            }

            const bankLabels = ['銀行', '收款銀行', '收款方式', '付款方式', '支付方式', '存款方式', '通道名稱'];
            for (const td of tds) {
                const txt = td.innerText.replace(/[\s\u200B-\u200D\uFEFF]+/g, '');
                if (!txt || txt.length > 15) continue; 
                
                if (!bankLabels.some(l => txt === l || txt === l + ':' || txt === l + '：')) continue;

                const next = td.nextElementSibling;
                if (!next || next.tagName !== 'TD') continue;
                const val = next.innerText.trim();
                if (!val) continue; 
                
                const m = matchMethod(val);
                if (m) return m;
                return val; 
            }
            return matchMethod(tds.map(td => td.innerText).join(' '));
        }

        const FIELD_MAP = {
            deposit: {
                no:     ['存款單號', '單號'],
                acc:    ['會員帳號', '帳號'],
                amt:    [['金額', '實際金額'], true],
                method: () => detectMethod(),
                time:   () => getVal(['存款時間']) || getVal(['申請日期']) || getVal(['時間'])
            },
            withdraw: {
                no:  ['提款單號', '單號'],
                acc: ['會員帳號', '帳號'],
                amt: [['金額', '實際金額', '實際提領金額'], true]
            },
            fuding: {
                no:     ['提款單號', '單號'],
                acc:    ['帳號'],
                amt:    [['金額', '實際金額', '實際提領金額'], true],
                branch: ['分行'],
                _bank:  ['銀行']
            },
            sirius: {
                no:     ['提款單號', '單號'],
                acc:    ['帳號'],
                name:   ['戶名', '姓名', '收款人', '持卡人', '真實姓名'],
                amt:    [['金額', '實際金額', '實際提領金額'], true],
                _bank:  ['銀行']
            }
        };

        const cfg = FIELD_MAP[type];
        if (!cfg) return null;

        const result = {};
        for (const [key, def] of Object.entries(cfg)) {
            if (key.startsWith('_')) continue;
            if (typeof def === 'function') {
                result[key] = def();
            } else if (Array.isArray(def) && def[1] === true) {
                result[key] = getVal(def[0], true);
            } else {
                result[key] = getVal(def);
            }
        }

        if (type === 'fuding' || type === 'sirius') {
            const rawBank = getVal(cfg._bank);
            const m = rawBank.match(/\(\s*(\d+)\s*\)\s*(.*)/);
            if (type === 'fuding') {
                result.bankCode = m ? m[1] : '';
                result.bankName = m ? m[2].trim() : rawBank;
            } else if (type === 'sirius') {
                result.bankName = m ? `${m[2].trim()} (${m[1]})` : rawBank;
            }
        }

        return result;
    }

    const startBtn = $('#startBtn');
    const stopBtn = $('#stopBtn');
    const logBtn = $('#logBtn');
    const exportBtn = $('#exportBtn');
    const accountList = $('#accountList');
    const accCount = $('#accCount');
    const resultBody = $('#resultBody');
    const statusTextAuto = $('.js-status-auto');
    const autoPane = $('#tab-auto');
    const debugPanel = $('#debugPanel');
    const alertPanel = $('#alertPanel');
    const persistentAlertPanel = $('#persistentAlertPanel');
    const logModal = $('#logModal');
    const closeLogBtn = $('#closeLogBtn');
    const intervalBtns = $$('.int-btn');
    const sharedPoolIdInput = $('#sharedPoolId');
    const sharedLimitWanInput = $('#sharedLimitWan');
    const sharedPoolListInput = $('#sharedPoolList');
    const resetAtInput = $('#resetAtInput');
    const repeatWeeklyInput = $('#repeatWeeklyInput');
    const saveConfigBtn = $('#saveConfigBtn');
    const reloadConfigBtn = $('#reloadConfigBtn');
    const downloadConfigBtn = $('#downloadConfigBtn');
    const quickSoloAccountInput = $('#quickSoloAccountInput');
    const quickSoloLimitWanInput = $('#quickSoloLimitWanInput');
    const addSoloBtn = $('#addSoloBtn');
    const soloListInput = $('#soloListInput');
    const groupAPoolIdInput = $('#groupAPoolId');
    const groupALimitWanInput = $('#groupALimitWan');
    const groupAMembersInput = $('#groupAMembers');
    const groupAResetAtInput = $('#groupAResetAt');
    const groupBPoolIdInput = $('#groupBPoolId');
    const groupBLimitWanInput = $('#groupBLimitWan');
    const groupBMembersInput = $('#groupBMembers');
    const groupBResetAtInput = $('#groupBResetAt');
    const applyGroupKeepBtn = $('#applyGroupKeepBtn');

    let selectedInterval = 0;

    const DEFAULT_AUTO_CONFIG_FILE = '帳號設定區/default-auto-config.json';

    const setAutoStatus = (text, state = '') => {
        if (statusTextAuto) {
            statusTextAuto.textContent = text;
            statusTextAuto.className = `pill js-status-auto${state ? ` ${state}` : ''}`;
        }
        if (autoPane) {
            const active = state === 'scanning' || state === 'online';
            autoPane.classList.toggle('is-loading', active);
            autoPane.classList.toggle('is-waiting', state === 'scanning');
        }
    };
    const storageGet = (keys) => new Promise(resolve => chrome.storage.local.get(keys, resolve));
    const storageSet = (obj) => new Promise(resolve => chrome.storage.local.set(obj, resolve));

    const pad2 = (n) => String(n).padStart(2, '0');
    const toDateSlash = (d) => `${d.getFullYear()}/${pad2(d.getMonth() + 1)}/${pad2(d.getDate())}`;

    const normalizeDateTimeInput = (raw) => {
        let s = String(raw || '').trim();
        if (!s) return '';
        s = s.replace(/\//g, '-').replace(/\s+/g, ' ');
        if (/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/.test(s)) {
            s = s.replace(' ', 'T');
        }
        if (!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(s)) return '';
        return s;
    };

    const parseLocalDateTime = (raw) => {
        const normalized = normalizeDateTimeInput(raw);
        if (!normalized) return null;
        const d = new Date(normalized);
        return Number.isNaN(d.getTime()) ? null : d;
    };

    const normalizePoolId = (raw) => {
        const v = String(raw || '').trim().toUpperCase().replace(/\s+/g, '-');
        return v || 'POOL-A';
    };

    const normalizeOptionalPoolId = (raw) => {
        const v = String(raw || '').trim();
        return v ? normalizePoolId(v) : '';
    };

    const toSafeWan = (v, fallback = 0) => {
        const n = Number(v);
        if (!Number.isFinite(n) || n < 0) return fallback;
        return n;
    };

    const accountKey = (name) => String(name || '').trim().toLowerCase();

    const upsertAccount = (accounts, item) => {
        const key = accountKey(item?.name);
        if (!key) return accounts;

        const idx = accounts.findIndex(a => accountKey(a?.name) === key);
        const normalized = {
            name: String(item.name || '').trim(),
            poolId: item.poolId ? normalizePoolId(item.poolId) : '',
            individualLimitWan: toSafeWan(item.individualLimitWan, 0),
            resetAt: parseLocalDateTime(item.resetAt) ? normalizeDateTimeInput(item.resetAt) : ''
        };

        if (idx >= 0) {
            accounts[idx] = { ...accounts[idx], ...normalized };
        } else {
            accounts.push(normalized);
        }
        return accounts;
    };

    const dedupeAccounts = (accounts) => {
        const out = [];
        (accounts || []).forEach(acc => {
            upsertAccount(out, acc);
        });
        return out;
    };

    const parseAccountLines = (text, defaultPoolId) => {
        const out = [];
        const lines = String(text || '').split('\n').map(v => v.trim()).filter(Boolean);

        for (const line of lines) {
            const cols = line.split(',').map(v => v.trim());
            const name = cols[0];
            if (!name) continue;

            let poolId = defaultPoolId;
            let individualLimitWan = 0;
            let resetAt = '';
            const tail = cols.slice(1).filter(Boolean);
            let hasPool = false;

            for (const tokenRaw of tail) {
                const token = tokenRaw.trim();
                const dt = normalizeDateTimeInput(token);
                if (dt && !resetAt) {
                    resetAt = dt;
                    continue;
                }

                const upper = token.toUpperCase();
                if (['SOLO', 'SINGLE', 'NONE', 'NULL', '-'].includes(upper) || ['單獨', '單帳'].includes(token)) {
                    poolId = '';
                    hasPool = true;
                    continue;
                }

                const n = Number(token);
                if (Number.isFinite(n)) {
                    individualLimitWan = Math.max(0, n);
                    continue;
                }

                if (!hasPool) {
                    poolId = normalizePoolId(token);
                    hasPool = true;
                }
            }

            out.push({ name, poolId, individualLimitWan, resetAt });
        }
        return out;
    };

    const parseSharedPoolLines = (text, fallbackPoolId, fallbackLimit) => {
        const out = [];
        const lines = String(text || '').split('\n').map(v => v.trim()).filter(Boolean);

        for (const line of lines) {
            const cols = line.split(',').map(v => v.trim()).filter(Boolean);
            const idRaw = cols[0] || '';
            if (!idRaw) continue;
            const id = normalizePoolId(idRaw);
            const limitWan = toSafeWan(cols[1], fallbackLimit);
            const name = String(cols[2] || `Pool ${id}`).trim() || `Pool ${id}`;
            if (!id) continue;
            if (out.find(p => p.id === id)) continue;
            out.push({ id, name, limitWan });
        }

        if (!out.length) {
            out.push({ id: fallbackPoolId, name: 'Main Pool', limitWan: fallbackLimit });
        }

        return out;
    };

    const parseGroupMembers = (text) => {
        const out = [];
        const seen = new Set();
        const tokens = String(text || '')
            .split(/[\n,，\s]+/)
            .map(v => String(v || '').trim())
            .filter(Boolean);

        for (const token of tokens) {
            const key = accountKey(token);
            if (!key || seen.has(key)) continue;
            seen.add(key);
            out.push(token);
        }
        return out;
    };

    const parseSoloListLines = (text) => {
        const out = [];
        const lines = String(text || '').split('\n').map(v => v.trim()).filter(Boolean);

        for (const line of lines) {
            const cols = line.split(',').map(v => v.trim()).filter(Boolean);
            const name = cols[0] || '';
            const key = accountKey(name);
            if (!name || !key) continue;

            let limitWan = 0;
            for (const token of cols.slice(1)) {
                const n = Number(token);
                if (Number.isFinite(n)) {
                    limitWan = Math.max(0, n);
                    break;
                }
            }

            const idx = out.findIndex(item => accountKey(item.name) === key);
            const item = { name, individualLimitWan: limitWan };
            if (idx >= 0) out[idx] = item;
            else out.push(item);
        }

        return out;
    };
    const getPoolMemberMap = (config) => {
        const map = new Map();
        (config?.accounts || []).forEach(acc => {
            const pid = normalizeOptionalPoolId(acc?.poolId);
            const name = String(acc?.name || '').trim();
            if (!pid || !name) return;
            if (!map.has(pid)) map.set(pid, []);
            map.get(pid).push(name);
        });
        return map;
    };

    const fillGroupEditorFromConfig = (cfg) => {
        if (!groupAPoolIdInput || !groupALimitWanInput || !groupAMembersInput || !groupBPoolIdInput || !groupBLimitWanInput || !groupBMembersInput) {
            return;
        }

        const config = normalizeAutoConfig(cfg);
        const poolMap = new Map((config.sharedPools || []).map(pool => [normalizePoolId(pool.id), pool]));
        const memberMap = getPoolMemberMap(config);
        const getPoolResetAt = (poolId) => {
            const memberNames = memberMap.get(poolId) || [];
            for (const name of memberNames) {
                const acc = (config.accounts || []).find(item => accountKey(item?.name) === accountKey(name));
                const resetAt = parseLocalDateTime(acc?.resetAt) ? normalizeDateTimeInput(acc.resetAt) : '';
                if (resetAt) return resetAt;
            }
            return '';
        };

        const ranked = (config.sharedPools || [])
            .map(pool => {
                const pid = normalizePoolId(pool.id);
                return {
                    id: pid,
                    limitWan: toSafeWan(pool?.limitWan, 0),
                    count: (memberMap.get(pid) || []).length
                };
            })
            .sort((a, b) => b.count - a.count);

        const poolA = ranked[0] || {
            id: normalizePoolId(sharedPoolIdInput?.value || 'POOL-A'),
            limitWan: toSafeWan(sharedLimitWanInput?.value, 16)
        };

        let poolB = ranked.find(item => item.id !== poolA.id);
        if (!poolB) {
            const fallback = (config.sharedPools || []).find(pool => normalizeOptionalPoolId(pool?.id) !== poolA.id);
            if (fallback) {
                poolB = { id: normalizePoolId(fallback.id), limitWan: toSafeWan(fallback.limitWan, 0) };
            } else {
                poolB = { id: 'POOL-B', limitWan: 0 };
            }
        }

        if (poolB.id === poolA.id) {
            poolB = { id: 'POOL-B', limitWan: poolB.limitWan };
        }

        groupAPoolIdInput.value = poolA.id;
        groupALimitWanInput.value = String(toSafeWan(poolMap.get(poolA.id)?.limitWan ?? poolA.limitWan, 0));
        groupAMembersInput.value = (memberMap.get(poolA.id) || []).join('\n');
        if (groupAResetAtInput) groupAResetAtInput.value = getPoolResetAt(poolA.id);

        groupBPoolIdInput.value = poolB.id;
        groupBLimitWanInput.value = String(toSafeWan(poolMap.get(poolB.id)?.limitWan ?? poolB.limitWan, 0));
        groupBMembersInput.value = (memberMap.get(poolB.id) || []).join('\n');
        if (groupBResetAtInput) groupBResetAtInput.value = getPoolResetAt(poolB.id);
    };

    const normalizeAutoConfig = (raw) => {
        const fallbackPoolId = normalizePoolId(sharedPoolIdInput?.value || 'POOL-A');
        const fallbackLimit = toSafeWan(sharedLimitWanInput?.value, 16);

        const src = (raw && typeof raw === 'object') ? raw : {};
        const resetRuleRaw = src.resetRule || {};
        const anchor = parseLocalDateTime(resetRuleRaw.anchor) ? normalizeDateTimeInput(resetRuleRaw.anchor) : '';
        const repeatWeekly = resetRuleRaw.repeatWeekly !== false;

        const poolsRaw = Array.isArray(src.sharedPools) ? src.sharedPools : [];
        const pools = poolsRaw
            .map(p => ({
                id: normalizePoolId(p?.id || fallbackPoolId),
                name: String(p?.name || 'Pool').trim() || 'Pool',
                limitWan: toSafeWan(p?.limitWan, fallbackLimit)
            }))
            .filter((p, idx, arr) => p.id && arr.findIndex(x => x.id === p.id) === idx);

        if (!pools.length) {
            pools.push({ id: fallbackPoolId, name: 'Main Pool', limitWan: fallbackLimit });
        }

        let accounts = [];
        if (Array.isArray(src.accounts)) {
            accounts = src.accounts
                .map(item => {
                    const name = String(item?.name || item?.account || '').trim();
                    if (!name) return null;
                    const hasPoolField = Object.prototype.hasOwnProperty.call(item || {}, 'poolId');
                    const rawPool = hasPoolField ? String(item?.poolId || '').trim() : pools[0].id;
                    return {
                        name,
                        poolId: rawPool ? normalizePoolId(rawPool) : '',
                        individualLimitWan: toSafeWan(item?.individualLimitWan ?? item?.limitWan ?? item?.limit, 0),
                        resetAt: parseLocalDateTime(item?.resetAt) ? normalizeDateTimeInput(item.resetAt) : ''
                    };
                })
                .filter(Boolean);
        }

        accounts = dedupeAccounts(accounts);

        // Auto add pool definitions referenced by accounts
        const poolIds = new Set(pools.map(p => p.id));
        (accounts || []).forEach(acc => {
            const pid = normalizeOptionalPoolId(acc?.poolId);
            if (!pid) return;
            if (poolIds.has(pid)) return;
            poolIds.add(pid);
            pools.push({ id: pid, name: `Pool ${pid}`, limitWan: fallbackLimit });
        });

        return {
            version: 1,
            updatedAt: src.updatedAt || '',
            resetRule: { anchor, repeatWeekly },
            sharedPools: pools,
            accounts
        };
    };

    const renderAutoConfig = (cfg) => {
        const config = normalizeAutoConfig(cfg);

        const mainPool = config.sharedPools[0];
        if (sharedPoolIdInput) sharedPoolIdInput.value = mainPool.id;
        if (sharedLimitWanInput) sharedLimitWanInput.value = String(mainPool.limitWan);
        if (sharedPoolListInput) {
            sharedPoolListInput.value = (config.sharedPools || [])
                .map(pool => `${pool.id},${pool.limitWan}${pool.name ? `,${pool.name}` : ''}`)
                .join('\n');
        }
        if (resetAtInput) resetAtInput.value = config.resetRule.anchor || '';
        if (repeatWeeklyInput) repeatWeeklyInput.checked = !!config.resetRule.repeatWeekly;

        if (accountList) {
            const lines = config.accounts.map(acc => {
                const limitTxt = acc.individualLimitWan > 0 ? `,${acc.individualLimitWan}` : '';
                const resetTxt = acc.resetAt ? `,${acc.resetAt}` : '';
                if (!acc.poolId) {
                    return `${acc.name},SOLO${limitTxt ? `,${acc.individualLimitWan}` : ''}${resetTxt}`;
                }
                if (acc.poolId === mainPool.id && !limitTxt && !resetTxt) {
                    return `${acc.name}`;
                }
                if (acc.poolId === mainPool.id) {
                    return `${acc.name}${limitTxt}${resetTxt}`;
                }
                return `${acc.name},${acc.poolId}${limitTxt ? `,${acc.individualLimitWan}` : ''}${resetTxt}`;
            });
            accountList.value = lines.join('\n');
        }
        if (soloListInput) {
            const soloLines = (config.accounts || [])
                .filter(acc => !String(acc?.poolId || '').trim())
                .map(acc => {
                    const limitWan = toSafeWan(acc?.individualLimitWan, 0);
                    return limitWan > 0 ? `${acc.name},${limitWan}` : `${acc.name}`;
                });
            soloListInput.value = soloLines.join('\n');
        }
        fillGroupEditorFromConfig(config);
        updateAccCount();
    };

    const collectAutoConfigFromUI = () => {
        const poolId = normalizePoolId(sharedPoolIdInput?.value || 'POOL-A');
        const limitWan = toSafeWan(sharedLimitWanInput?.value, 16);
        const anchorRaw = resetAtInput?.value || '';
        const anchor = parseLocalDateTime(anchorRaw) ? normalizeDateTimeInput(anchorRaw) : '';
        const repeatWeekly = !!repeatWeeklyInput?.checked;
        const accounts = parseAccountLines(accountList?.value || '', poolId);

        const parsedPools = parseSharedPoolLines(sharedPoolListInput?.value || '', poolId, limitWan);
        const mainPool = { id: poolId, name: 'Main Pool', limitWan };

        let sharedPools = parsedPools.filter(p => p.id !== mainPool.id);
        sharedPools.unshift(mainPool);

        const knownPoolIds = new Set(sharedPools.map(p => p.id));
        (accounts || []).forEach(acc => {
            const pid = normalizeOptionalPoolId(acc?.poolId);
            if (!pid || knownPoolIds.has(pid)) return;
            knownPoolIds.add(pid);
            sharedPools.push({ id: pid, name: `Pool ${pid}`, limitWan });
        });

        return normalizeAutoConfig({
            version: 1,
            updatedAt: new Date().toISOString(),
            resetRule: { anchor, repeatWeekly },
            sharedPools,
            accounts
        });
    };

    const applyGroupPoolsFromUI = async ({ showMsg = true } = {}) => {
        const cfg = collectAutoConfigFromUI();
        const poolAId = normalizePoolId(groupAPoolIdInput?.value || sharedPoolIdInput?.value || 'POOL-A');
        const poolBId = normalizePoolId(groupBPoolIdInput?.value || 'POOL-B');
        const poolALimitWan = toSafeWan(groupALimitWanInput?.value, toSafeWan(sharedLimitWanInput?.value, 16));
        const poolBLimitWan = toSafeWan(groupBLimitWanInput?.value, poolALimitWan);
        const poolAResetAt = parseLocalDateTime(groupAResetAtInput?.value) ? normalizeDateTimeInput(groupAResetAtInput.value) : '';
        const poolBResetAt = parseLocalDateTime(groupBResetAtInput?.value) ? normalizeDateTimeInput(groupBResetAtInput.value) : '';

        const membersA = parseGroupMembers(groupAMembersInput?.value || '');
        const rawMembersB = parseGroupMembers(groupBMembersInput?.value || '');
        const soloRows = parseSoloListLines(soloListInput?.value || '');
        const aKeySet = new Set(membersA.map(name => accountKey(name)));
        const membersB = rawMembersB.filter(name => !aKeySet.has(accountKey(name)));
        const duplicateCount = rawMembersB.length - membersB.length;

        if (membersA.length && membersB.length && poolAId === poolBId) {
            showToast('A池與B池不能使用同一個 Pool ID');
            return null;
        }

        if (!membersA.length && !membersB.length && !soloRows.length) {
            showToast('請先輸入 A池、B池或 SOLO 名單');
            return null;
        }

        const accounts = [];
        const sharedKeys = new Set();

        (soloRows || []).forEach((row) => {
            const name = String(row?.name || '').trim();
            const key = accountKey(name);
            if (!name || !key) return;
            upsertAccount(accounts, {
                name,
                poolId: '',
                individualLimitWan: toSafeWan(row.individualLimitWan, 0),
                resetAt: ''
            });
        });

        const assignMembers = (members, poolId, poolResetAt) => {
            members.forEach((nameRaw) => {
                const name = String(nameRaw || '').trim();
                const key = accountKey(name);
                if (!name || !key) return;

                upsertAccount(accounts, {
                    name,
                    poolId,
                    individualLimitWan: 0,
                    resetAt: poolResetAt
                });
                sharedKeys.add(key);
            });
        };

        assignMembers(membersA, poolAId, poolAResetAt);
        assignMembers(membersB, poolBId, poolBResetAt);

        const poolMap = new Map(
            (cfg.sharedPools || [])
                .map(pool => {
                    const id = normalizeOptionalPoolId(pool?.id);
                    if (!id) return null;
                    const oldName = String(pool?.name || '').trim();
                    return [id, { id, name: oldName || `Pool ${id}`, limitWan: toSafeWan(pool?.limitWan, 0) }];
                })
                .filter(Boolean)
        );

        if (membersA.length) {
            const oldA = poolMap.get(poolAId);
            poolMap.set(poolAId, { id: poolAId, name: oldA?.name || `Pool ${poolAId}`, limitWan: poolALimitWan });
        }
        if (membersB.length) {
            const oldB = poolMap.get(poolBId);
            poolMap.set(poolBId, { id: poolBId, name: oldB?.name || `Pool ${poolBId}`, limitWan: poolBLimitWan });
        }

        const usedPoolIds = new Set(
            accounts
                .map(acc => normalizeOptionalPoolId(acc?.poolId))
                .filter(Boolean)
        );
        let sharedPools = Array.from(poolMap.values()).filter(pool => usedPoolIds.has(normalizePoolId(pool.id)));
        sharedPools.sort((a, b) => {
            if (a.id === poolAId) return -1;
            if (b.id === poolAId) return 1;
            if (a.id === poolBId) return -1;
            if (b.id === poolBId) return 1;
            return a.id.localeCompare(b.id);
        });

        cfg.accounts = dedupeAccounts(accounts);
        cfg.sharedPools = sharedPools;
        cfg.updatedAt = new Date().toISOString();

        if (sharedPoolIdInput) sharedPoolIdInput.value = poolAId;
        if (sharedLimitWanInput) sharedLimitWanInput.value = String(poolALimitWan);

        const normalized = normalizeAutoConfig(cfg);
        await storageSet({ autoConfig: normalized });
        renderAutoConfig(normalized);

        if (showMsg) {
            const suffix = duplicateCount > 0 ? `，${duplicateCount} 筆重複帳號保留在A池` : '';
            showToast(`已套用全部名單：A池 ${membersA.length}、B池 ${membersB.length}、SOLO ${soloRows.length}${suffix}`);
        }
        return normalized;
    };
    const loadDefaultAutoConfigFromFile = async () => {
        try {
            const url = chrome.runtime.getURL(DEFAULT_AUTO_CONFIG_FILE);
            const resp = await fetch(url, { cache: 'no-store' });
            if (!resp.ok) return null;
            return await resp.json();
        } catch (err) {
            return null;
        }
    };

    const saveAutoConfig = async (showMsg = false) => {
        const cfg = collectAutoConfigFromUI();
        await storageSet({ autoConfig: cfg });
        if (showMsg) showToast('設定已儲存');
        return cfg;
    };

    const ensureAutoConfig = async () => {
        const storeData = await storageGet(['autoConfig', 'accounts']);
        let cfg = storeData.autoConfig;

        const fromFileRaw = await loadDefaultAutoConfigFromFile();
        const fromFile = fromFileRaw ? normalizeAutoConfig(fromFileRaw) : null;

        const toMs = (iso) => {
            const d = new Date(String(iso || ''));
            return Number.isNaN(d.getTime()) ? 0 : d.getTime();
        };

        if (!cfg) {
            cfg = normalizeAutoConfig(fromFile || {});

            if ((!cfg.accounts || !cfg.accounts.length) && Array.isArray(storeData.accounts) && storeData.accounts.length) {
                const mainPoolId = cfg.sharedPools[0].id;
                cfg.accounts = storeData.accounts
                    .map(a => {
                        const name = String(a?.name || '').trim();
                        if (!name) return null;
                        const limitWan = Number.isFinite(a?.limit) && a.limit > 0 ? a.limit / 10000 : 0;
                        return { name, poolId: mainPoolId, individualLimitWan: limitWan };
                    })
                    .filter(Boolean);
            }
            await storageSet({ autoConfig: cfg });
        } else {
            cfg = normalizeAutoConfig(cfg);

            // 若帳號設定區/default-auto-config.json 比目前 storage 新，則自動套用檔案版本
            if (fromFile && toMs(fromFile.updatedAt) > toMs(cfg.updatedAt)) {
                cfg = fromFile;
            }
            await storageSet({ autoConfig: cfg });
        }

        renderAutoConfig(cfg);
        return cfg;
    };
    const buildRuntimeAccounts = (cfg) => {
        const poolMap = new Map((cfg.sharedPools || []).map(pool => [pool.id, pool]));
        const globalResetAt = parseLocalDateTime(cfg.resetRule?.anchor) ? normalizeDateTimeInput(cfg.resetRule.anchor) : '';

        return (cfg.accounts || []).map((acc) => {
            const pool = acc.poolId ? (poolMap.get(acc.poolId) || null) : null;
            const poolLimit = Number.isFinite(pool?.limitWan) && pool.limitWan > 0 ? pool.limitWan * 10000 : null;
            const individualLimit = Number.isFinite(acc.individualLimitWan) && acc.individualLimitWan > 0 ? acc.individualLimitWan * 10000 : null;
            const accountResetAt = parseLocalDateTime(acc.resetAt) ? normalizeDateTimeInput(acc.resetAt) : '';
            const finalResetAt = accountResetAt || (acc.poolId ? globalResetAt : '');
            const finalDate = finalResetAt ? toDateSlash(new Date(finalResetAt)) : '0';

            return {
                name: acc.name,
                poolId: acc.poolId,
                poolLimit,
                limit: individualLimit,
                date: finalDate,
                resetAt: finalResetAt,
                repeatWeekly: !!cfg.resetRule?.repeatWeekly
            };
        });
    };

    if (persistentAlertPanel) {
        persistentAlertPanel.addEventListener('click', (e) => {
            if (e.target.classList.contains('dismiss-alert-btn')) {
                const idxToRemove = parseInt(e.target.dataset.idx, 10);
                chrome.storage.local.get(['persistentAlerts'], (d) => {
                    let currentAlerts = d.persistentAlerts || [];
                    currentAlerts.splice(idxToRemove, 1);
                    chrome.storage.local.set({ persistentAlerts: currentAlerts }, updateUIAuto);
                });
            }
        });
    }
    
    const updateAccCount = () => {
        if (!accountList || !accCount) return;
        const lines = accountList.value.split('\n').filter(line => line.trim() !== '');
        accCount.textContent = `(${lines.length})`;
    };

    let accountListSaveTimer = null;
    if (accountList) accountList.addEventListener('input', () => {
        updateAccCount();
        clearTimeout(accountListSaveTimer);
        accountListSaveTimer = setTimeout(() => {
            void saveAutoConfig(false);
        }, 500);
    });

    if (addSoloBtn) addSoloBtn.addEventListener('click', async () => {
        const name = String(quickSoloAccountInput?.value || '').trim();
        if (!name) {
            showToast('請輸入SOLO帳號');
            return;
        }

        const rows = parseSoloListLines(soloListInput?.value || '');
        const key = accountKey(name);
        const oldRow = rows.find(row => accountKey(row?.name) === key);
        const hasLimitInput = String(quickSoloLimitWanInput?.value || '').trim() !== '';
        const limitWan = hasLimitInput
            ? toSafeWan(quickSoloLimitWanInput.value, 0)
            : toSafeWan(oldRow?.individualLimitWan, 0);
        const nextRow = { name: oldRow?.name || name, individualLimitWan: limitWan };
        const idx = rows.findIndex(row => accountKey(row?.name) === key);
        if (idx >= 0) rows[idx] = nextRow;
        else rows.push(nextRow);

        if (soloListInput) {
            soloListInput.value = rows
                .map(row => toSafeWan(row.individualLimitWan, 0) > 0 ? `${row.name},${row.individualLimitWan}` : `${row.name}`)
                .join('\n');
        }

        const saved = await applyGroupPoolsFromUI({ showMsg: false });
        if (!saved) return;

        if (quickSoloAccountInput) quickSoloAccountInput.value = '';
        if (quickSoloLimitWanInput) quickSoloLimitWanInput.value = '';
        showToast('SOLO帳號已加入名單');
    });
    if (applyGroupKeepBtn) applyGroupKeepBtn.addEventListener('click', async () => {
        await applyGroupPoolsFromUI({ showMsg: true });
    });

    if (intervalBtns) intervalBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            intervalBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            selectedInterval = parseInt(btn.dataset.val, 10);
        });
    });

    if (saveConfigBtn) saveConfigBtn.addEventListener('click', async () => {
        const saved = await applyGroupPoolsFromUI({ showMsg: false });
        if (saved) showToast('設定已儲存');
    });

    if (reloadConfigBtn) reloadConfigBtn.addEventListener('click', async () => {
        await ensureAutoConfig();
        showToast('設定已重讀');
    });

    if (downloadConfigBtn) downloadConfigBtn.addEventListener('click', async () => {
        const cfg = await applyGroupPoolsFromUI({ showMsg: false });
        if (!cfg) return;
        const json = JSON.stringify(cfg, null, 2);
        const blob = new Blob([json], { type: 'application/json;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'default-auto-config.json';
        a.click();
        URL.revokeObjectURL(url);
        showToast('已匯出 default-auto-config.json');
    });

    const onQuickSave = async () => {
        await applyGroupPoolsFromUI({ showMsg: false });
    };
    [sharedPoolIdInput, sharedLimitWanInput, sharedPoolListInput, resetAtInput, repeatWeeklyInput].forEach(el => {
        if (!el) return;
        el.addEventListener('change', onQuickSave);
    });

    if (logBtn) logBtn.addEventListener('click', () => { logModal.style.display = 'flex'; });
    if (closeLogBtn) closeLogBtn.addEventListener('click', () => { logModal.style.display = 'none'; });

    if (exportBtn) exportBtn.addEventListener('click', () => {
        chrome.storage.local.get(['results'], (data) => {
            const res = data.results || [];
            if (res.length === 0) {
                showToast('無資料可匯出');
                return;
            }

            const getRawPayoutText = (valStr) => {
                if (!valStr || valStr === 'Not Found' || valStr === '—' || valStr === '查無資料' || valStr === 'No Data') return '—';
                const num = parseFloat(valStr.replace(/,/g, ''));
                if (isNaN(num) || num === 0) return '0';
                const fmt = Math.abs(num).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
                return num > 0 ? `贏${fmt}` : `輸${fmt}`;
            };

            const dateStr = todayStr(); 
            let content = '\ufeff'; 
            
            res.forEach(r => {
                const payText = getRawPayoutText(r.payout);
                const timeText = r.time || '-';
                const line = `帳號:${r.account} 錢包餘額:${r.balance} 輸贏:${payText} 更新時間:${dateStr} ${timeText}`;
                content += `"${line}"\n`;
            });
            
            const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `BEC_DATA_${dateStr.replace(/\//g, '')}.csv`;
            a.click();
            URL.revokeObjectURL(url);
            showToast('已匯出單行報表');
        });
    });


    const formatPayout = (valStr) => {
        if (!valStr || valStr === 'Not Found' || valStr === '—' || valStr === '查無資料' || valStr === 'No Data')
            return `<span style="color:var(--text-3)">${valStr || '—'}</span>`;
        const num = parseFloat(valStr.replace(/,/g, ''));
        if (isNaN(num) || num === 0) return `<span style="color:var(--text-2)">0</span>`;
        const fmt = Math.abs(num).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        return num > 0
            ? `<span style="color:var(--border-blue); font-weight:bold;">贏 ${fmt}</span>`
            : `<span style="color:var(--text-red); font-weight:bold;">輸 ${fmt}</span>`;
    };

    const updateUIAuto = () => {
        if (!resultBody) return;
        chrome.storage.local.get(['results', 'isRunning', 'isWaiting', 'currentIndex', 'accounts', 'debugLog', 'persistentAlerts'], (data) => {
            
            if (persistentAlertPanel) {
                const pAlerts = data.persistentAlerts || [];
                if (pAlerts.length > 0) {
                    let pHTML = '';
                    pAlerts.forEach((msg, idx) => {
                        pHTML += `<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px; padding-bottom:4px; border-bottom:1px dashed var(--color-danger);">
                            <span style="font-weight: bold;">⚠️ ${msg}</span>
                            <button class="act-btn dismiss-alert-btn" data-idx="${idx}" style="flex:none; width:auto; padding:4px 8px; font-size:0.75rem; border-color:var(--color-danger); color:var(--color-danger); background: rgba(255, 8, 68, 0.2);">已確認</button>
                        </div>`;
                    });
                    persistentAlertPanel.innerHTML = pHTML;
                    persistentAlertPanel.style.display = 'block';
                } else {
                    persistentAlertPanel.style.display = 'none';
                    persistentAlertPanel.innerHTML = '';
                }
            }

            resultBody.innerHTML = '';
            let alertsHTML = '';
            
            (data.results || []).forEach(res => {
                const tr = document.createElement('tr');
                if (res.exceeded) tr.style.backgroundColor = 'rgba(243, 156, 18, 0.15)';
                
                const balColor = res.balance?.startsWith('Error') || res.balance?.startsWith('錯誤') ? 'color:var(--text-red)' : 'color:var(--text-2)';
                tr.innerHTML = `
                    <td style="padding:4px; color:var(--text-1);">${res.account}</td>
                    <td style="padding:4px; ${balColor}">${res.balance}</td>
                    <td style="padding:4px; text-align:right;">${formatPayout(res.payout)}</td>`;
                resultBody.appendChild(tr);

                if (res.exceeded) {
                    alertsHTML += `<div style="margin-bottom:4px;">! 單筆查單警告: ${res.account} [${res.payout}]</div>`;
                }
            });

            if (alertPanel) {
                if (alertsHTML) {
                    alertPanel.innerHTML = alertsHTML;
                    alertPanel.style.display = 'block';
                } else {
                    alertPanel.style.display = 'none';
                    alertPanel.innerHTML = '';
                }
            }

            if (debugPanel) {
                debugPanel.innerHTML = '';
                (data.debugLog || []).forEach(line => {
                    const div = document.createElement('div');
                    const isErr  = line.toLowerCase().includes('error') || line.includes('錯誤') || line.includes('失敗');
                    const isWarn = line.toLowerCase().includes('warning') || line.includes('警告') || line.includes('alert') || line.includes('略過');
                    div.style.color = isErr ? 'var(--text-red)' : isWarn ? 'var(--border-hot)' : 'var(--border-base)';
                    div.textContent = line;
                    debugPanel.appendChild(div);
                });
                debugPanel.scrollTop = debugPanel.scrollHeight;
            }

            if (data.isRunning) {
                if (statusTextAuto) {
                    if (data.isWaiting) {
                        setAutoStatus('等待中', 'scanning');
                    } else {
                        setAutoStatus(`讀取中 ${(data.currentIndex || 0) + 1}/${data.accounts?.length || 0}`, 'online');
                    }
                }
                if (startBtn) startBtn.disabled  = true;
                if (stopBtn) stopBtn.disabled = false;
            } else {
                if (statusTextAuto) {
                    setAutoStatus('待命中');
                }
                if (startBtn) startBtn.disabled  = false;
                if (stopBtn) stopBtn.disabled = true;
            }
        });
    };

    void ensureAutoConfig();

    if (resultBody) {
        updateUIAuto();
        setInterval(updateUIAuto, 800);
    }

    const TARGET_URL = 'https://b9a9vnfik.becgame88168.com/index/Home';

    if (startBtn) startBtn.addEventListener('click', async () => {
        const cfg = await applyGroupPoolsFromUI({ showMsg: false });
        if (!cfg) return;
        const accounts = buildRuntimeAccounts(cfg);
        if (!accounts.length) {
            showToast('請先輸入至少一個帳號');
            return;
        }

        startBtn.disabled = true;
        setAutoStatus('讀取中...', 'scanning');

        chrome.storage.local.set({
            autoConfig: cfg,
            accounts,
            currentIndex: 0,
            adaptiveDelay: 800,
            intervalMin: selectedInterval,
            isRunning: true,
            isWaiting: false,
            step: 'SEARCH',
            startUrl: TARGET_URL,
            results: [],
            debugLog: [],
            poolStatus: {},
            currentPeriodKey: '',
            forceDisableQueue: [],
            poolForceMembers: {},
            disabledAccounts: {}
        }, () => {
            chrome.runtime.sendMessage({ action: 'CREATE_BACKGROUND_WINDOW', url: TARGET_URL, incognito: true }, (resp) => {
                if (resp?.success) {
                    updateUIAuto();
                } else {
                    chrome.storage.local.set({ isRunning: false, isWaiting: false });
                    setAutoStatus('錯誤', 'error');
                    startBtn.disabled = false;
                    stopBtn.disabled = true;

                    if (resp?.error === 'INCOGNITO_DISABLED') {
                        showToast('請至擴充管理開啟「允許在無痕模式中執行」');
                    } else {
                        showToast('啟動失敗: ' + (resp?.error || '未知錯誤'));
                    }
                }
            });
        });
    });

    if (stopBtn) stopBtn.addEventListener('click', () => {
        chrome.storage.local.set({ isRunning: false, isWaiting: false }, () => {
            chrome.runtime.sendMessage({ action: 'CLOSE_BACKGROUND_WINDOW' }, updateUIAuto);
        });
    });
    const keepAutoHome = !!autoPane?.classList.contains('active');
    if (!keepAutoHome) {
        autoDetect();
    }
});























