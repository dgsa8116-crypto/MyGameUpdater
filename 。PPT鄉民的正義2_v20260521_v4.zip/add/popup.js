document.addEventListener('DOMContentLoaded', () => {
    const $ = (sel, ctx = document) => ctx.querySelector(sel);
    const $$ = (sel, ctx = document) => [...ctx.querySelectorAll(sel)];

    const todayStr = () => {
        const d = new Date();
        return `${d.getFullYear()}/${String(d.getMonth() + 1).padStart(2, '0')}/${String(d.getDate()).padStart(2, '0')}`;
    };

    function showToast(msg = '已複製到剪貼簿') {
        const t = $('#toast');
        t.textContent = msg;
        t.classList.add('show');
        setTimeout(() => t.classList.remove('show'), 1500);
    }

    async function copyText(text) {
        if (!text || text === '無資料') return;
        await navigator.clipboard.writeText(text.trim());
        showToast();
    }

    function switchTab(targetId) {
        $$('.nav-btn').forEach(b => b.classList.remove('active'));
        $$('.tab-pane').forEach(p => p.classList.remove('active'));
        const btn = $(`.nav-btn[data-target="${targetId}"]`);
        const pane = $(`#${targetId}`);
        if (btn) btn.classList.add('active');
        if (pane) pane.classList.add('active');
        return pane;
    }

    $('.nav-container').addEventListener('click', (e) => {
        const btn = e.target.closest('.nav-btn');
        if (btn) switchTab(btn.dataset.target);
    });

    const fieldVal = (pane, field) => $(`input[data-field="${field}"]`, pane)?.value || '';

    $('.content').addEventListener('click', (e) => {
        const btn = e.target.closest('.js-copy');
        if (!btn) return;

        const pane = btn.closest('.tab-pane');
        const key = btn.dataset.copy;
        let text = '';

        switch (key) {
            case 'deposit-format': {
                let method = fieldVal(pane, 'method');
                if (!method || method === '無資料') method = '入款';
                text = [todayStr(), method, fieldVal(pane, 'no'), fieldVal(pane, 'acc'), fieldVal(pane, 'amt')].join('\t');
                break;
            }
            case 'usdt-deposit-format': {
                text = [todayStr(), '入款', fieldVal(pane, 'no'), fieldVal(pane, 'acc'), fieldVal(pane, 'amt')].join('\t');
                break;
            }
            case 'withdraw-format': {
                text = [todayStr(), '出款', fieldVal(pane, 'no'), fieldVal(pane, 'acc'), '', fieldVal(pane, 'amt')].join('\t');
                break;
            }
            case 'fuding-template': {
                const v = (f) => fieldVal(pane, f);
                text = [
                    '【代付確認提單】',
                    `交易編號 ${v('no')}`,
                    `銀行名稱 ${v('bankName')}`,
                    `銀行代碼 ( ${v('bankCode')} )`,
                    `銀行帳號 ${v('acc')}`,
                    `分行 ${v('branch')}`,
                    `金額 ${v('amt')}`
                ].join('\n');
                break;
            }
            case 'sirius-template': {
                const v = (f) => fieldVal(pane, f);
                text = [
                    `單號：${v('no')}`,
                    `金額：${v('amt')}`,
                    `銀行：${v('bankName')}`,
                    `帳號：${v('acc')}`,
                    `姓名：${v('name')}`
                ].join('\n');
                break;
            }
            case 'time': {
                text = fieldVal(pane, 'time');
                break;
            }
            default: {
                text = key.split(',').map(f => fieldVal(pane, f)).join('\t');
            }
        }
        copyText(text);
    });

    $('.content').addEventListener('click', (e) => {
        const accountBtn = e.target.closest('.copy-account-btn');
        if (!accountBtn) return;
        e.preventDefault();
        copyText(accountBtn.dataset.account || accountBtn.textContent || '');
    });

    $('.content').addEventListener('click', async (e) => {
        const btn = e.target.closest('.js-fetch');
        if (!btn) return;
        const pane = btn.closest('.tab-pane');
        await fetchAndFill(pane);
    });

    async function fetchAndFill(pane) {
        const { type, usdt } = pane.dataset;
        const isUsdt = usdt === 'true';
        const pill = $('.js-status', pane);

        pill.textContent = '掃描中';
        pill.className = 'pill js-status scanning';

        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            
            if (!tab || !tab.url || !tab.url.startsWith('http')) {
                pill.textContent = '無效頁面';
                pill.className = 'pill js-status error';
                return null;
            }

            const results = await chrome.scripting.executeScript({
                target: { tabId: tab.id, allFrames: true },
                func: grabPageData,
                args: [type, isUsdt]
            });

            const data = {};
            for (const { result } of results) {
                if (!result) continue;
                for (const [k, v] of Object.entries(result)) {
                    if (v && !data[k]) data[k] = v;
                }
            }

            if ((type === 'fuding' || type === 'sirius') && data.amt) {
                data.amt = Number(data.amt.replace(/,/g, '')).toLocaleString();
            }

            $$('input[data-field]', pane).forEach(input => {
                input.value = data[input.dataset.field] || '無資料';
            });

            const ok = !!data.no;
            pill.textContent = ok ? '就緒' : '查無資料';
            pill.className = 'pill js-status ' + (ok ? 'online' : 'error');

            return data;
        } catch (err) {
            pill.textContent = '錯誤';
            pill.className = 'pill js-status error';
            return null;
        }
    }

    async function autoDetect() {
        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            if (!tab || !tab.url || !tab.url.startsWith('http')) return;

            const probeResults = await chrome.scripting.executeScript({
                target: { tabId: tab.id, allFrames: true },
                func: probePageType
            });

            let orderNo = '';
            let bankRaw = '';
            let pageIsUsdt = false;
            for (const { result } of probeResults) {
                if (!result) continue;
                if (result.orderNo && !orderNo) orderNo = result.orderNo;
                if (result.bankRaw && !bankRaw) bankRaw = result.bankRaw;
                if (result.isUsdt) pageIsUsdt = true;
            }

            const prefix = orderNo.charAt(0).toUpperCase();
            const bankUpper = bankRaw.toUpperCase();
            const isUsdtPage = pageIsUsdt || /USDT|TRC|ERC|TRON|虛擬貨幣|虚拟货币|泰達|泰达/i.test(bankUpper);

            let targetTab = '';

            if (prefix === 'D') {
                if (isUsdtPage) targetTab = 'tab-usdt-deposit';
                else targetTab = 'tab-deposit';
            } else if (prefix === 'W') {
                if (isUsdtPage) targetTab = 'tab-usdt-withdraw';
                else targetTab = 'tab-withdraw';
            }

            if (!targetTab) return;

            const pane = switchTab(targetTab);
            if (pane) await fetchAndFill(pane);
        } catch (err) {}
    }

    function probePageType() {
        const tds = Array.from(document.querySelectorAll('td'));
        const bodyText = document.body?.innerText || '';
        let orderNo = '';
        let bankRaw = '';
        let usdtHintRaw = '';
        const orderLabels = ['存款單號', '存款单号', '提款單號', '提款单号', '單號', '单号', '訂單號', '订单号', '交易單號', '交易单号', '交易編號', '交易编号', '編號', '编号'];
        const bankLabels = ['銀行', '银行', '收款銀行', '收款银行', '收款方式', '付款方式', '支付方式', '存款方式', '提款方式', '通道名稱', '通道名称', '渠道名稱', '渠道名称', '支付通道'];
        const usdtHintLabels = ['幣別', '币别', '幣種', '币种', '鏈類型', '链类型', '鏈別', '链别', '協議', '协议', '充值方式', '提款方式', '提領方式', '提领方式'];
        const clean = (text) => String(text || '').replace(/[\s\u200B-\u200D\uFEFF]+/g, '');
        const sameLabel = (text, labels) => labels.some(label => text === clean(label) || text === clean(label) + ':' || text === clean(label) + '：');

        for (const td of tds) {
            const txt = clean(td.innerText);
            if (!txt || txt.length > 24) continue;
            const next = td.nextElementSibling;
            const val = next?.tagName === 'TD' ? next.innerText.trim() : '';

            if (!orderNo && sameLabel(txt, orderLabels) && val) orderNo = val;
            if (!bankRaw && sameLabel(txt, bankLabels) && val) bankRaw = val;
            if (!usdtHintRaw && sameLabel(txt, usdtHintLabels) && val) usdtHintRaw = val;
            if (orderNo && bankRaw && usdtHintRaw) break;
        }

        if (!orderNo) {
            const m = bodyText.match(/\b([DW][A-Z0-9][A-Z0-9-]{4,})\b/i);
            if (m) orderNo = m[1].trim();
        }

        const isUsdt = /USDT|TRC20?|ERC20?|TRON|虛擬貨幣|虚拟货币|泰達|泰达/i.test(`${bankRaw} ${usdtHintRaw}`);
        return { orderNo, bankRaw, isUsdt };
    }
    function grabPageData(type, isUsdt) {
        const tds = Array.from(document.querySelectorAll('td'));

        const normalizeCellText = (text) => String(text || '').replace(/[\s\u200B-\u200D\uFEFF]+/g, '');
        const labelMatches = (text, labels) => {
            const cleanLabels = labels.map(normalizeCellText);
            return cleanLabels.some(label => text === label || text === label + ':' || text === label + '：');
        };
        const parseAmount = (raw) => {
            const text = String(raw || '').trim();
            const patterns = [
                /(?:USDT|U)\s*[:：]?\s*([\d,]+(?:\.\d+)?)/i,
                /([\d,]+(?:\.\d+)?)\s*(?:USDT|U)\b/i,
                /([\d,]+(?:\.\d+)?)/
            ];
            for (const pattern of patterns) {
                const m = text.match(pattern);
                if (m) return m[1].replace(/,/g, '');
            }
            return '';
        };
        const usdtAmountScore = ({ label, raw }) => {
            const text = `${label} ${raw}`.toUpperCase();
            if (/USDT|TRC|ERC|TRON|\bU\b/.test(text)) return 100;
            if (/提領數量|提领数量|充值數量|充值数量|數量|数量|U數量|U数量/.test(label)) return 90;
            if (/實際提領金額|实际提领金额|實際出款金額|实际出款金额/.test(label)) return 80;
            if (/實際金額|实际金额/.test(label)) return 60;
            if (/金額|金额/.test(label)) return 10;
            return 0;
        };

        const getVal = (labels, isAmount = false) => {
            const matches = [];
            for (const td of tds) {
                const txt = normalizeCellText(td.innerText);
                if (!txt || txt.length > 24) continue;
                if (!labelMatches(txt, labels)) continue;

                const next = td.nextElementSibling;
                if (!next || next.tagName !== 'TD') continue;
                const raw = next.innerText.trim();
                if (raw) matches.push({ label: txt, raw });
            }

            if (!matches.length) return '';
            if (!isAmount) return matches[0].raw;

            if (isUsdt) {
                const candidates = matches
                    .map(row => ({ ...row, amount: parseAmount(row.raw), score: usdtAmountScore(row) }))
                    .filter(row => row.amount);
                candidates.sort((a, b) => b.score - a.score);
                return candidates[0]?.amount || '';
            }

            for (const { raw } of matches) {
                if (raw.toUpperCase().includes('USDT') && (type !== 'withdraw' && type !== 'fuding' && type !== 'sirius')) continue;
                const numMatch = raw.match(/[\d,.]+/);
                return numMatch ? numMatch[0].replace(/,/g, '') : raw;
            }
            return '';
        };
        function detectMethod() {
            const methodRules = [
                [['支付寶', 'ALIPAY'], '支付寶'],
                [['微信', 'WECHAT', 'WXPAY'], '微信'],
                [['超商', '便利商店', 'CVS', 'IBON'], '超商'],
                [['銀聯', 'UNIONPAY', 'CUP'], '銀聯'],
                [['LINEPAY', 'LINE PAY'], 'LinePay'],
                [['JKOPAY', '街口'], '街口支付'],
                [['USDT', 'TRC', 'ERC', '虛擬貨幣'], 'USDT'],
                [['網銀', '銀行轉帳'], '網銀'],
                [['ATM'], 'ATM'],
            ];

            function matchMethod(text) {
                const upper = text.toUpperCase();
                for (const [keywords, label] of methodRules) {
                    if (keywords.some(kw => upper.includes(kw.toUpperCase()))) return label;
                }
                return '';
            }

            const bankLabels = ['銀行', '收款銀行', '收款方式', '付款方式', '支付方式', '存款方式', '通道名稱', '渠道名稱', '支付通道'];
            for (const td of tds) {
                const txt = td.innerText.replace(/[\s\u200B-\u200D\uFEFF]+/g, '');
                if (!txt || txt.length > 15) continue; 
                
                if (!bankLabels.some(l => txt === l || txt === l + ':' || txt === l + '：')) continue;

                const next = td.nextElementSibling;
                if (!next || next.tagName !== 'TD') continue;
                const val = next.innerText.trim();
                if (!val) continue; 
                
                const m = matchMethod(val);
                if (m) return m;
                return val; 
            }
            return matchMethod(tds.map(td => td.innerText).join(' '));
        }

        const standardDepositAmountLabels = ['金額', '金额', '實際金額', '实际金额'];
        const standardWithdrawAmountLabels = ['金額', '金额', '實際金額', '实际金额', '實際提領金額', '实际提领金额'];
        const usdtDepositAmountLabels = ['USDT數量', 'USDT 数量', 'USDT数量', 'USDT金額', 'USDT 金額', 'USDT金额', 'U數量', 'U数量', '充值數量', '充值数量', '數量', '数量', '實際金額', '实际金额', '金額', '金额'];
        const usdtWithdrawAmountLabels = ['USDT數量', 'USDT 数量', 'USDT数量', 'USDT金額', 'USDT 金額', 'USDT金额', 'U數量', 'U数量', '提領數量', '提领数量', '提領USDT', '提领USDT', '實際提領金額', '实际提领金额', '實際出款金額', '实际出款金额', '數量', '数量', '實際金額', '实际金额', '金額', '金额'];
        const FIELD_MAP = {
            deposit: {
                no:     ['存款單號', '存款单号', '單號', '单号', '訂單號', '订单号', '交易單號', '交易单号', '交易編號', '交易编号', '編號', '编号'],
                acc:    ['會員帳號', '会员帐号', '會員账号', '会员账号', '帳號', '账号'],
                amt:    [isUsdt ? usdtDepositAmountLabels : standardDepositAmountLabels, true],
                method: () => detectMethod(),
                time:   () => getVal(['存款時間', '存款时间']) || getVal(['申請日期', '申请日期']) || getVal(['時間', '时间'])
            },
            withdraw: {
                no:  ['提款單號', '提款单号', '單號', '单号', '訂單號', '订单号', '交易單號', '交易单号', '交易編號', '交易编号', '編號', '编号'],
                acc: ['會員帳號', '会员帐号', '會員账号', '会员账号', '帳號', '账号'],
                amt: [isUsdt ? usdtWithdrawAmountLabels : standardWithdrawAmountLabels, true]
            },
            fuding: {
                no:     ['提款單號', '單號'],
                acc:    ['帳號'],
                amt:    [['金額', '實際金額', '實際提領金額'], true],
                branch: ['分行'],
                _bank:  ['銀行']
            },
            sirius: {
                no:     ['提款單號', '單號'],
                acc:    ['帳號'],
                name:   ['戶名', '姓名', '收款人', '持卡人', '真實姓名'],
                amt:    [['金額', '實際金額', '實際提領金額'], true],
                _bank:  ['銀行']
            }
        };

        const cfg = FIELD_MAP[type];
        if (!cfg) return null;

        const result = {};
        for (const [key, def] of Object.entries(cfg)) {
            if (key.startsWith('_')) continue;
            if (typeof def === 'function') {
                result[key] = def();
            } else if (Array.isArray(def) && def[1] === true) {
                result[key] = getVal(def[0], true);
            } else {
                result[key] = getVal(def);
            }
        }

        if (type === 'fuding' || type === 'sirius') {
            const rawBank = getVal(cfg._bank);
            const m = rawBank.match(/\(\s*(\d+)\s*\)\s*(.*)/);
            if (type === 'fuding') {
                result.bankCode = m ? m[1] : '';
                result.bankName = m ? m[2].trim() : rawBank;
            } else if (type === 'sirius') {
                result.bankName = m ? `${m[2].trim()} (${m[1]})` : rawBank;
            }
        }

        return result;
    }

    const startBtn = $('#startBtn');
    const stopBtn = $('#stopBtn');
    const logBtn = $('#logBtn');
    const exportBtn = $('#exportBtn');
    const accountList = $('#accountList');
    const accCount = $('#accCount');
    const resultBody = $('#resultBody');
    const disabledListBox = $('#disabledListBox');
    const disabledBody = $('#disabledBody');
    const statusTextAuto = $('.js-status-auto');
    const autoPane = $('#tab-auto');
    const debugPanel = $('#debugPanel');
    const logModal = $('#logModal');
    const closeLogBtn = $('#closeLogBtn');
    const intervalBtns = $$('.int-btn');
    const sharedPoolIdInput = $('#sharedPoolId');
    const sharedLimitWanInput = $('#sharedLimitWan');
    const sharedPoolListInput = $('#sharedPoolList');
    const resetAtInput = $('#resetAtInput');
    const repeatWeeklyInput = $('#repeatWeeklyInput');
    const sharedOnlyInput = $('#sharedOnlyInput');
    const saveConfigBtn = $('#saveConfigBtn');
    const reloadConfigBtn = $('#reloadConfigBtn');
    const downloadConfigBtn = $('#downloadConfigBtn');
    const quickSoloAccountInput = $('#quickSoloAccountInput');
    const quickSoloLimitWanInput = $('#quickSoloLimitWanInput');
    const quickSoloWinLimitWanInput = $('#quickSoloWinLimitWanInput') || quickSoloLimitWanInput;
    const quickSoloLossLimitWanInput = $('#quickSoloLossLimitWanInput') || quickSoloLimitWanInput;
    const quickSoloResetAtInput = $('#quickSoloResetAtInput');
    const addSoloBtn = $('#addSoloBtn');
    const soloListInput = $('#soloListInput');
    const groupAPoolIdInput = $('#groupAPoolId');
    const groupALimitWanInput = $('#groupALimitWan');
    const groupAWinLimitWanInput = $('#groupAWinLimitWan') || groupALimitWanInput;
    const groupALossLimitWanInput = $('#groupALossLimitWan') || groupALimitWanInput;
    const groupAMembersInput = $('#groupAMembers');
    const groupALiveTotal = $('#groupALiveTotal');
    const groupAResetAtInput = $('#groupAResetAt');
    const groupAPoolModeInput = $('#groupAPoolMode');
    const groupBPoolIdInput = $('#groupBPoolId');
    const groupBLimitWanInput = $('#groupBLimitWan');
    const groupBWinLimitWanInput = $('#groupBWinLimitWan') || groupBLimitWanInput;
    const groupBLossLimitWanInput = $('#groupBLossLimitWan') || groupBLimitWanInput;
    const groupBMembersInput = $('#groupBMembers');
    const groupBLiveTotal = $('#groupBLiveTotal');
    const groupBResetAtInput = $('#groupBResetAt');
    const groupBPoolModeInput = $('#groupBPoolMode');
    const applyGroupKeepBtn = $('#applyGroupKeepBtn');

    let selectedInterval = 0;

    const DEFAULT_AUTO_CONFIG_FILE = '帳號設定區/default-auto-config.json';

    const setAutoStatus = (text, state = '') => {
        if (statusTextAuto) {
            statusTextAuto.textContent = text;
            statusTextAuto.className = `pill js-status-auto${state ? ` ${state}` : ''}`;
        }
        if (autoPane) {
            const active = state === 'scanning' || state === 'online';
            autoPane.classList.toggle('is-loading', active);
            autoPane.classList.toggle('is-waiting', state === 'scanning');
        }
    };
    const storageGet = (keys) => new Promise(resolve => chrome.storage.local.get(keys, resolve));
    const storageSet = (obj) => new Promise(resolve => chrome.storage.local.set(obj, resolve));

    const pad2 = (n) => String(n).padStart(2, '0');
    const toDateSlash = (d) => `${d.getFullYear()}/${pad2(d.getMonth() + 1)}/${pad2(d.getDate())}`;

    const normalizeDateTimeInput = (raw) => {
        let s = String(raw || '').trim();
        if (!s) return '';
        s = s.replace(/\//g, '-').replace(/\s+/g, ' ');
        if (/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/.test(s)) {
            s = s.replace(' ', 'T');
        }
        if (!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(s)) return '';
        return s;
    };

    const parseLocalDateTime = (raw) => {
        const normalized = normalizeDateTimeInput(raw);
        if (!normalized) return null;
        const d = new Date(normalized);
        return Number.isNaN(d.getTime()) ? null : d;
    };

    const normalizePoolId = (raw) => {
        const v = String(raw || '').trim().toUpperCase().replace(/\s+/g, '-');
        return v || 'POOL-A';
    };

    const normalizeOptionalPoolId = (raw) => {
        const v = String(raw || '').trim();
        return v ? normalizePoolId(v) : '';
    };

    const normalizePoolMode = (raw) => {
        const v = String(raw || '').trim().toLowerCase();
        return ['hybrid', 'mode1', 'single', '單帳先鎖', '方式1'].includes(v) ? 'hybrid' : 'total';
    };

    const toSafeWan = (v, fallback = 0) => {
        const n = Number(v);
        if (!Number.isFinite(n) || n < 0) return fallback;
        return n;
    };

    const isBlank = (v) => v === undefined || v === null || String(v).trim() === '';
    const normalizeWanPair = (winRaw, lossRaw, legacyRaw = 0) => {
        const legacy = toSafeWan(legacyRaw, 0);
        const win = isBlank(winRaw) ? legacy : toSafeWan(winRaw, legacy);
        const loss = isBlank(lossRaw) ? win : toSafeWan(lossRaw, win);
        return { winLimitWan: win, lossLimitWan: loss, limitWan: win === loss ? win : Math.max(win, loss) };
    };
    const getPoolLimitPair = (pool, fallback = 0) => normalizeWanPair(pool?.winLimitWan, pool?.lossLimitWan, pool?.limitWan ?? fallback);
    const getAccountLimitPair = (acc, fallback = 0) => normalizeWanPair(
        acc?.individualWinLimitWan ?? acc?.winLimitWan,
        acc?.individualLossLimitWan ?? acc?.lossLimitWan,
        acc?.individualLimitWan ?? acc?.limitWan ?? acc?.limit ?? fallback
    );
    const readInputLimitPair = (winInput, lossInput, legacyInput, fallback = 0) => normalizeWanPair(
        winInput?.value,
        lossInput?.value,
        !isBlank(legacyInput?.value) ? legacyInput.value : fallback
    );
    const formatLimitParts = (win, loss) => {
        const w = toSafeWan(win, 0);
        const l = toSafeWan(loss, w);
        return w === l ? [String(w)] : [String(w), String(l)];
    };
    const formatSoloLine = (acc) => {
        const pair = getAccountLimitPair(acc, 0);
        const resetAt = parseLocalDateTime(acc?.resetAt) ? normalizeDateTimeInput(acc.resetAt) : '';
        const parts = [String(acc?.name || '').trim()];
        if (pair.winLimitWan > 0 || pair.lossLimitWan > 0 || resetAt) {
            parts.push(...formatLimitParts(pair.winLimitWan, pair.lossLimitWan));
        }
        if (resetAt) parts.push(resetAt);
        return parts.filter(v => v !== '').join(',');
    };

    const accountKey = (name) => String(name || '').trim().toLowerCase();

    const upsertAccount = (accounts, item) => {
        const key = accountKey(item?.name);
        if (!key) return accounts;

        const idx = accounts.findIndex(a => accountKey(a?.name) === key);
        const pair = getAccountLimitPair(item, 0);
        const normalized = {
            name: String(item.name || '').trim(),
            poolId: item.poolId ? normalizePoolId(item.poolId) : '',
            individualLimitWan: pair.limitWan,
            individualWinLimitWan: pair.winLimitWan,
            individualLossLimitWan: pair.lossLimitWan,
            resetAt: parseLocalDateTime(item.resetAt) ? normalizeDateTimeInput(item.resetAt) : ''
        };

        if (idx >= 0) {
            accounts[idx] = { ...accounts[idx], ...normalized };
        } else {
            accounts.push(normalized);
        }
        return accounts;
    };
    const dedupeAccounts = (accounts) => {
        const out = [];
        (accounts || []).forEach(acc => {
            upsertAccount(out, acc);
        });
        return out;
    };

    const parseAccountLines = (text, defaultPoolId) => {
        const out = [];
        const lines = String(text || '').split('\n').map(v => v.trim()).filter(Boolean);

        for (const line of lines) {
            const cols = line.split(',').map(v => v.trim()).filter(Boolean);
            const name = cols[0];
            if (!name) continue;

            let poolId = defaultPoolId;
            let resetAt = '';
            let hasPool = false;
            const nums = [];

            for (const token of cols.slice(1)) {
                const dt = normalizeDateTimeInput(token);
                if (dt && !resetAt) {
                    resetAt = dt;
                    continue;
                }

                const upper = token.toUpperCase();
                if (['SOLO', 'SINGLE', 'NONE', 'NULL', '-'].includes(upper) || ['單獨', '單帳'].includes(token)) {
                    poolId = '';
                    hasPool = true;
                    continue;
                }

                const n = Number(token);
                if (Number.isFinite(n)) {
                    nums.push(Math.max(0, n));
                    continue;
                }

                if (!hasPool) {
                    poolId = normalizePoolId(token);
                    hasPool = true;
                }
            }

            const pair = normalizeWanPair(nums[0], nums[1], nums[0] ?? 0);
            out.push({ name, poolId, individualLimitWan: pair.limitWan, individualWinLimitWan: pair.winLimitWan, individualLossLimitWan: pair.lossLimitWan, resetAt });
        }
        return out;
    };
    const parseSharedPoolLines = (text, fallbackPoolId, fallbackLimit) => {
        const out = [];
        const lines = String(text || '').split('\n').map(v => v.trim()).filter(Boolean);
        const modeTokens = ['total', 'hybrid', 'mode1', 'single', '方式1', '方式2', '單帳先鎖'];

        for (const line of lines) {
            const cols = line.split(',').map(v => v.trim()).filter(Boolean);
            const idRaw = cols[0] || '';
            if (!idRaw) continue;
            const id = normalizePoolId(idRaw);
            const nums = [];
            let mode = 'total';
            let name = '';

            for (const token of cols.slice(1)) {
                const lower = token.toLowerCase();
                const n = Number(token);
                if (Number.isFinite(n)) {
                    nums.push(Math.max(0, n));
                    continue;
                }
                if (modeTokens.includes(lower) || modeTokens.includes(token)) {
                    mode = normalizePoolMode(token);
                    continue;
                }
                if (!name) name = token;
            }

            const pair = normalizeWanPair(nums[0], nums[1], nums[0] ?? fallbackLimit);
            if (!id) continue;
            if (out.find(p => p.id === id)) continue;
            out.push({ id, name: name || `Pool ${id}`, limitWan: pair.limitWan, winLimitWan: pair.winLimitWan, lossLimitWan: pair.lossLimitWan, mode });
        }

        if (!out.length) {
            const pair = normalizeWanPair(fallbackLimit, fallbackLimit, fallbackLimit);
            out.push({ id: fallbackPoolId, name: 'Main Pool', limitWan: pair.limitWan, winLimitWan: pair.winLimitWan, lossLimitWan: pair.lossLimitWan, mode: 'total' });
        }

        return out;
    };
    const parseGroupMembers = (text) => {
        const out = [];
        const seen = new Set();
        const tokens = String(text || '')
            .split(/[\n,，\s]+/)
            .map(v => String(v || '').trim())
            .filter(Boolean);

        for (const token of tokens) {
            const key = accountKey(token);
            if (!key || seen.has(key)) continue;
            seen.add(key);
            out.push(token);
        }
        return out;
    };

    const parseSoloListLines = (text) => {
        const out = [];
        const lines = String(text || '').split('\n').map(v => v.trim()).filter(Boolean);

        for (const line of lines) {
            const cols = line.split(',').map(v => v.trim()).filter(Boolean);
            const name = cols[0] || '';
            const key = accountKey(name);
            if (!name || !key) continue;

            const nums = [];
            let resetAt = '';
            for (const token of cols.slice(1)) {
                const dt = normalizeDateTimeInput(token);
                if (dt && !resetAt) {
                    resetAt = dt;
                    continue;
                }
                const n = Number(token);
                if (Number.isFinite(n)) nums.push(Math.max(0, n));
            }

            const pair = normalizeWanPair(nums[0], nums[1], nums[0] ?? 0);
            const idx = out.findIndex(item => accountKey(item.name) === key);
            const item = { name, individualLimitWan: pair.limitWan, individualWinLimitWan: pair.winLimitWan, individualLossLimitWan: pair.lossLimitWan, resetAt };
            if (idx >= 0) out[idx] = item;
            else out.push(item);
        }

        return out;
    };
    const getPoolMemberMap = (config) => {
        const map = new Map();
        (config?.accounts || []).forEach(acc => {
            const pid = normalizeOptionalPoolId(acc?.poolId);
            const name = String(acc?.name || '').trim();
            if (!pid || !name) return;
            if (!map.has(pid)) map.set(pid, []);
            map.get(pid).push(name);
        });
        return map;
    };

    const fillGroupEditorFromConfig = (cfg) => {
        if (!groupAPoolIdInput || !groupAMembersInput || !groupBPoolIdInput || !groupBMembersInput) {
            return;
        }

        const config = normalizeAutoConfig(cfg);
        const poolMap = new Map((config.sharedPools || []).map(pool => [normalizePoolId(pool.id), pool]));
        const memberMap = getPoolMemberMap(config);
        const getPoolResetAt = (poolId) => {
            const memberNames = memberMap.get(poolId) || [];
            for (const name of memberNames) {
                const acc = (config.accounts || []).find(item => accountKey(item?.name) === accountKey(name));
                const resetAt = parseLocalDateTime(acc?.resetAt) ? normalizeDateTimeInput(acc.resetAt) : '';
                if (resetAt) return resetAt;
            }
            return '';
        };

        const ranked = (config.sharedPools || [])
            .map(pool => {
                const pid = normalizePoolId(pool.id);
                const pair = getPoolLimitPair(pool, 0);
                return {
                    id: pid,
                    limitWan: pair.limitWan,
                    winLimitWan: pair.winLimitWan,
                    lossLimitWan: pair.lossLimitWan,
                    mode: normalizePoolMode(pool?.mode),
                    count: (memberMap.get(pid) || []).length
                };
            })
            .sort((a, b) => b.count - a.count);

        const poolA = ranked[0] || {
            id: normalizePoolId(sharedPoolIdInput?.value || 'POOL-A'),
            ...readInputLimitPair(groupAWinLimitWanInput, groupALossLimitWanInput, sharedLimitWanInput, 16),
            mode: 'total'
        };

        let poolB = ranked.find(item => item.id !== poolA.id);
        if (!poolB) {
            const fallback = (config.sharedPools || []).find(pool => normalizeOptionalPoolId(pool?.id) !== poolA.id);
            if (fallback) {
                const pair = getPoolLimitPair(fallback, 0);
                poolB = { id: normalizePoolId(fallback.id), limitWan: pair.limitWan, winLimitWan: pair.winLimitWan, lossLimitWan: pair.lossLimitWan, mode: normalizePoolMode(fallback.mode) };
            } else {
                poolB = { id: 'POOL-B', limitWan: 0, winLimitWan: 0, lossLimitWan: 0, mode: 'total' };
            }
        }

        if (poolB.id === poolA.id) {
            poolB = { id: 'POOL-B', limitWan: poolB.limitWan, winLimitWan: poolB.winLimitWan, lossLimitWan: poolB.lossLimitWan, mode: normalizePoolMode(poolB.mode) };
        }

        const poolAStored = poolMap.get(poolA.id) || poolA;
        const poolBStored = poolMap.get(poolB.id) || poolB;
        const pairA = getPoolLimitPair(poolAStored, 0);
        const pairB = getPoolLimitPair(poolBStored, 0);

        groupAPoolIdInput.value = poolA.id;
        if (groupALimitWanInput) groupALimitWanInput.value = String(pairA.limitWan);
        if (groupAWinLimitWanInput) groupAWinLimitWanInput.value = String(pairA.winLimitWan);
        if (groupALossLimitWanInput) groupALossLimitWanInput.value = String(pairA.lossLimitWan);
        groupAMembersInput.value = (memberMap.get(poolA.id) || []).join('\n');
        if (groupAResetAtInput) groupAResetAtInput.value = getPoolResetAt(poolA.id);
        if (groupAPoolModeInput) groupAPoolModeInput.value = normalizePoolMode(poolAStored.mode ?? poolA.mode);

        groupBPoolIdInput.value = poolB.id;
        if (groupBLimitWanInput) groupBLimitWanInput.value = String(pairB.limitWan);
        if (groupBWinLimitWanInput) groupBWinLimitWanInput.value = String(pairB.winLimitWan);
        if (groupBLossLimitWanInput) groupBLossLimitWanInput.value = String(pairB.lossLimitWan);
        groupBMembersInput.value = (memberMap.get(poolB.id) || []).join('\n');
        if (groupBResetAtInput) groupBResetAtInput.value = getPoolResetAt(poolB.id);
        if (groupBPoolModeInput) groupBPoolModeInput.value = normalizePoolMode(poolBStored.mode ?? poolB.mode);
    };
    const normalizeAutoConfig = (raw) => {
        const fallbackPoolId = normalizePoolId(sharedPoolIdInput?.value || 'POOL-A');
        const fallbackLimit = toSafeWan(sharedLimitWanInput?.value, 16);

        const src = (raw && typeof raw === 'object') ? raw : {};
        const resetRuleRaw = src.resetRule || {};
        const anchor = parseLocalDateTime(resetRuleRaw.anchor) ? normalizeDateTimeInput(resetRuleRaw.anchor) : '';
        const repeatWeekly = resetRuleRaw.repeatWeekly !== false;

        const poolsRaw = Array.isArray(src.sharedPools) ? src.sharedPools : [];
        const pools = poolsRaw
            .map(p => {
                const pair = getPoolLimitPair(p, fallbackLimit);
                return {
                    id: normalizePoolId(p?.id || fallbackPoolId),
                    name: String(p?.name || 'Pool').trim() || 'Pool',
                    limitWan: pair.limitWan,
                    winLimitWan: pair.winLimitWan,
                    lossLimitWan: pair.lossLimitWan,
                    mode: normalizePoolMode(p?.mode)
                };
            })
            .filter((p, idx, arr) => p.id && arr.findIndex(x => x.id === p.id) === idx);

        if (!pools.length) {
            const pair = normalizeWanPair(fallbackLimit, fallbackLimit, fallbackLimit);
            pools.push({ id: fallbackPoolId, name: 'Main Pool', limitWan: pair.limitWan, winLimitWan: pair.winLimitWan, lossLimitWan: pair.lossLimitWan, mode: 'total' });
        }

        let accounts = [];
        if (Array.isArray(src.accounts)) {
            accounts = src.accounts
                .map(item => {
                    const name = String(item?.name || item?.account || '').trim();
                    if (!name) return null;
                    const hasPoolField = Object.prototype.hasOwnProperty.call(item || {}, 'poolId');
                    const rawPool = hasPoolField ? String(item?.poolId || '').trim() : pools[0].id;
                    const pair = getAccountLimitPair(item, 0);
                    return {
                        name,
                        poolId: rawPool ? normalizePoolId(rawPool) : '',
                        individualLimitWan: pair.limitWan,
                        individualWinLimitWan: pair.winLimitWan,
                        individualLossLimitWan: pair.lossLimitWan,
                        resetAt: parseLocalDateTime(item?.resetAt) ? normalizeDateTimeInput(item.resetAt) : ''
                    };
                })
                .filter(Boolean);
        }

        accounts = dedupeAccounts(accounts);

        const poolIds = new Set(pools.map(p => p.id));
        (accounts || []).forEach(acc => {
            const pid = normalizeOptionalPoolId(acc?.poolId);
            if (!pid) return;
            if (poolIds.has(pid)) return;
            poolIds.add(pid);
            const pair = normalizeWanPair(fallbackLimit, fallbackLimit, fallbackLimit);
            pools.push({ id: pid, name: `Pool ${pid}`, limitWan: pair.limitWan, winLimitWan: pair.winLimitWan, lossLimitWan: pair.lossLimitWan, mode: 'total' });
        });

        return {
            version: 2,
            updatedAt: src.updatedAt || new Date().toISOString(),
            resetRule: { anchor, repeatWeekly },
            sharedPools: pools,
            accounts
        };
    };
    const renderAutoConfig = (cfg) => {
        const config = normalizeAutoConfig(cfg);

        const mainPool = config.sharedPools[0];
        const mainPair = getPoolLimitPair(mainPool, 0);
        if (sharedPoolIdInput) sharedPoolIdInput.value = mainPool.id;
        if (sharedLimitWanInput) sharedLimitWanInput.value = String(mainPair.limitWan);
        if (sharedPoolListInput) {
            sharedPoolListInput.value = (config.sharedPools || [])
                .map(pool => {
                    const pair = getPoolLimitPair(pool, 0);
                    return `${pool.id},${pair.winLimitWan},${pair.lossLimitWan},${normalizePoolMode(pool.mode)}${pool.name ? `,${pool.name}` : ''}`;
                })
                .join('\n');
        }
        if (resetAtInput) resetAtInput.value = config.resetRule.anchor || '';
        if (repeatWeeklyInput) repeatWeeklyInput.checked = !!config.resetRule.repeatWeekly;

        if (accountList) {
            const lines = config.accounts.map(acc => {
                const resetTxt = acc.resetAt ? `,${acc.resetAt}` : '';
                const pairParts = formatLimitParts(acc.individualWinLimitWan, acc.individualLossLimitWan);
                const hasLimit = acc.individualWinLimitWan > 0 || acc.individualLossLimitWan > 0;
                const limitTxt = hasLimit ? `,${pairParts.join(',')}` : '';
                if (!acc.poolId) return `${acc.name},SOLO${limitTxt}${resetTxt}`;
                if (acc.poolId === mainPool.id && !limitTxt && !resetTxt) return acc.name;
                if (acc.poolId === mainPool.id) return `${acc.name}${limitTxt}${resetTxt}`;
                return `${acc.name},${acc.poolId}${limitTxt}${resetTxt}`;
            });
            accountList.value = lines.join('\n');
            updateAccCount();
        }

        if (soloListInput) {
            const soloLines = (config.accounts || [])
                .filter(acc => !String(acc?.poolId || '').trim())
                .map(formatSoloLine);
            soloListInput.value = soloLines.join('\n');
        }

        fillGroupEditorFromConfig(config);
    };
    const collectAutoConfigFromUI = () => {
        const poolId = normalizePoolId(sharedPoolIdInput?.value || 'POOL-A');
        const fallbackPair = readInputLimitPair(groupAWinLimitWanInput, groupALossLimitWanInput, sharedLimitWanInput, 16);
        const limitWan = fallbackPair.limitWan;
        const anchorRaw = resetAtInput?.value || '';
        const anchor = parseLocalDateTime(anchorRaw) ? normalizeDateTimeInput(anchorRaw) : '';
        const repeatWeekly = repeatWeeklyInput ? !!repeatWeeklyInput.checked : true;
        const accounts = parseAccountLines(accountList?.value || '', poolId);
        const parsedPools = parseSharedPoolLines(sharedPoolListInput?.value || '', poolId, limitWan);
        const mainPool = { id: poolId, name: 'Main Pool', limitWan: fallbackPair.limitWan, winLimitWan: fallbackPair.winLimitWan, lossLimitWan: fallbackPair.lossLimitWan, mode: normalizePoolMode(groupAPoolModeInput?.value) };

        let sharedPools = parsedPools.filter(p => p.id !== mainPool.id);
        sharedPools.unshift(mainPool);

        const knownPoolIds = new Set(sharedPools.map(p => p.id));
        (accounts || []).forEach(acc => {
            const pid = normalizeOptionalPoolId(acc?.poolId);
            if (!pid || knownPoolIds.has(pid)) return;
            knownPoolIds.add(pid);
            sharedPools.push({ id: pid, name: `Pool ${pid}`, limitWan: fallbackPair.limitWan, winLimitWan: fallbackPair.winLimitWan, lossLimitWan: fallbackPair.lossLimitWan, mode: 'total' });
        });

        return normalizeAutoConfig({
            version: 2,
            updatedAt: new Date().toISOString(),
            resetRule: { anchor, repeatWeekly },
            sharedPools,
            accounts
        });
    };
    const applyGroupPoolsFromUI = async ({ showMsg = true } = {}) => {
        const cfg = collectAutoConfigFromUI();
        const poolAId = normalizePoolId(groupAPoolIdInput?.value || sharedPoolIdInput?.value || 'POOL-A');
        const poolBId = normalizePoolId(groupBPoolIdInput?.value || 'POOL-B');
        const poolAPair = readInputLimitPair(groupAWinLimitWanInput, groupALossLimitWanInput, groupALimitWanInput || sharedLimitWanInput, 16);
        const poolBPair = readInputLimitPair(groupBWinLimitWanInput, groupBLossLimitWanInput, groupBLimitWanInput, poolAPair.limitWan);
        const poolAResetAt = parseLocalDateTime(groupAResetAtInput?.value) ? normalizeDateTimeInput(groupAResetAtInput.value) : '';
        const poolBResetAt = parseLocalDateTime(groupBResetAtInput?.value) ? normalizeDateTimeInput(groupBResetAtInput.value) : '';
        const poolAMode = normalizePoolMode(groupAPoolModeInput?.value);
        const poolBMode = normalizePoolMode(groupBPoolModeInput?.value);

        const membersA = parseGroupMembers(groupAMembersInput?.value || '');
        const rawMembersB = parseGroupMembers(groupBMembersInput?.value || '');
        const soloRows = parseSoloListLines(soloListInput?.value || '');
        const aKeySet = new Set(membersA.map(name => accountKey(name)));
        const membersB = rawMembersB.filter(name => !aKeySet.has(accountKey(name)));
        const duplicateCount = rawMembersB.length - membersB.length;

        if (membersA.length && membersB.length && poolAId === poolBId) {
            showToast('A池與B池不能使用同一個 Pool ID');
            return null;
        }

        if (!membersA.length && !membersB.length && !soloRows.length) {
            showToast('請先輸入 A池、B池或 SOLO 名單');
            return null;
        }

        const accounts = [];
        const sharedKeys = new Set();

        (soloRows || []).forEach((row) => {
            const name = String(row?.name || '').trim();
            const key = accountKey(name);
            if (!name || !key) return;
            upsertAccount(accounts, {
                name,
                poolId: '',
                individualWinLimitWan: toSafeWan(row.individualWinLimitWan, 0),
                individualLossLimitWan: toSafeWan(row.individualLossLimitWan, row.individualWinLimitWan || 0),
                individualLimitWan: toSafeWan(row.individualLimitWan, Math.max(row.individualWinLimitWan || 0, row.individualLossLimitWan || 0)),
                resetAt: row.resetAt || ''
            });
        });

        const assignMembers = (members, poolId, poolResetAt) => {
            members.forEach((nameRaw) => {
                const name = String(nameRaw || '').trim();
                const key = accountKey(name);
                if (!name || !key) return;

                upsertAccount(accounts, {
                    name,
                    poolId,
                    individualLimitWan: 0,
                    individualWinLimitWan: 0,
                    individualLossLimitWan: 0,
                    resetAt: poolResetAt
                });
                sharedKeys.add(key);
            });
        };

        assignMembers(membersA, poolAId, poolAResetAt);
        assignMembers(membersB, poolBId, poolBResetAt);

        const poolMap = new Map(
            (cfg.sharedPools || [])
                .map(pool => {
                    const id = normalizeOptionalPoolId(pool?.id);
                    if (!id) return null;
                    const oldName = String(pool?.name || '').trim();
                    const pair = getPoolLimitPair(pool, 0);
                    return [id, { id, name: oldName || `Pool ${id}`, limitWan: pair.limitWan, winLimitWan: pair.winLimitWan, lossLimitWan: pair.lossLimitWan, mode: normalizePoolMode(pool?.mode) }];
                })
                .filter(Boolean)
        );

        if (membersA.length) {
            const oldA = poolMap.get(poolAId);
            poolMap.set(poolAId, { id: poolAId, name: oldA?.name || `Pool ${poolAId}`, limitWan: poolAPair.limitWan, winLimitWan: poolAPair.winLimitWan, lossLimitWan: poolAPair.lossLimitWan, mode: poolAMode });
        }
        if (membersB.length) {
            const oldB = poolMap.get(poolBId);
            poolMap.set(poolBId, { id: poolBId, name: oldB?.name || `Pool ${poolBId}`, limitWan: poolBPair.limitWan, winLimitWan: poolBPair.winLimitWan, lossLimitWan: poolBPair.lossLimitWan, mode: poolBMode });
        }

        const usedPoolIds = new Set(accounts.map(acc => normalizeOptionalPoolId(acc?.poolId)).filter(Boolean));
        let sharedPools = Array.from(poolMap.values()).filter(pool => usedPoolIds.has(normalizePoolId(pool.id)));
        sharedPools.sort((a, b) => {
            if (a.id === poolAId) return -1;
            if (b.id === poolAId) return 1;
            if (a.id === poolBId) return -1;
            if (b.id === poolBId) return 1;
            return a.id.localeCompare(b.id);
        });

        cfg.accounts = dedupeAccounts(accounts);
        cfg.sharedPools = sharedPools;
        cfg.updatedAt = new Date().toISOString();
        cfg.version = 2;

        if (sharedPoolIdInput) sharedPoolIdInput.value = poolAId;
        if (sharedLimitWanInput) sharedLimitWanInput.value = String(poolAPair.limitWan);

        const normalized = normalizeAutoConfig(cfg);
        await storageSet({ autoConfig: normalized });
        renderAutoConfig(normalized);

        if (showMsg) {
            const suffix = duplicateCount > 0 ? `，${duplicateCount} 筆重複帳號保留在A池` : '';
            showToast(`已套用全部名單：A池 ${membersA.length}、B池 ${membersB.length}、SOLO ${soloRows.length}${suffix}`);
        }
        return normalized;
    };
    const loadDefaultAutoConfigFromFile = async () => {
        try {
            const url = chrome.runtime.getURL(DEFAULT_AUTO_CONFIG_FILE);
            const resp = await fetch(url, { cache: 'no-store' });
            if (!resp.ok) return null;
            return await resp.json();
        } catch (err) {
            return null;
        }
    };

    const saveAutoConfig = async (showMsg = false) => {
        const cfg = collectAutoConfigFromUI();
        await storageSet({ autoConfig: cfg });
        if (showMsg) showToast('設定已儲存');
        return cfg;
    };

    const ensureAutoConfig = async () => {
        const storeData = await storageGet(['autoConfig', 'accounts']);
        let cfg = storeData.autoConfig;

        const fromFileRaw = await loadDefaultAutoConfigFromFile();
        const fromFile = fromFileRaw ? normalizeAutoConfig(fromFileRaw) : null;

        const toMs = (iso) => {
            const d = new Date(String(iso || ''));
            return Number.isNaN(d.getTime()) ? 0 : d.getTime();
        };

        if (!cfg) {
            cfg = normalizeAutoConfig(fromFile || {});

            if ((!cfg.accounts || !cfg.accounts.length) && Array.isArray(storeData.accounts) && storeData.accounts.length) {
                const mainPoolId = cfg.sharedPools[0].id;
                cfg.accounts = storeData.accounts
                    .map(a => {
                        const name = String(a?.name || '').trim();
                        if (!name) return null;
                        const limitWan = Number.isFinite(a?.limit) && a.limit > 0 ? a.limit / 10000 : 0;
                        return { name, poolId: mainPoolId, individualLimitWan: limitWan };
                    })
                    .filter(Boolean);
            }
            await storageSet({ autoConfig: cfg });
        } else {
            cfg = normalizeAutoConfig(cfg);

            // 若帳號設定區/default-auto-config.json 比目前 storage 新，則自動套用檔案版本
            if (fromFile && toMs(fromFile.updatedAt) > toMs(cfg.updatedAt)) {
                cfg = fromFile;
            }
            await storageSet({ autoConfig: cfg });
        }

        renderAutoConfig(cfg);
        return cfg;
    };
    const buildRuntimeAccounts = (cfg) => {
        const poolMap = new Map((cfg.sharedPools || []).map(pool => [pool.id, pool]));
        const globalResetAt = parseLocalDateTime(cfg.resetRule?.anchor) ? normalizeDateTimeInput(cfg.resetRule.anchor) : '';

        return (cfg.accounts || []).map((acc) => {
            const pool = acc.poolId ? (poolMap.get(acc.poolId) || null) : null;
            const poolPair = getPoolLimitPair(pool || {}, 0);
            const accountPair = getAccountLimitPair(acc, 0);
            const poolMode = normalizePoolMode(pool?.mode);
            const accountResetAt = parseLocalDateTime(acc.resetAt) ? normalizeDateTimeInput(acc.resetAt) : '';
            const finalResetAt = accountResetAt || (acc.poolId ? globalResetAt : '');
            const finalDate = finalResetAt ? toDateSlash(new Date(finalResetAt)) : '0';

            return {
                name: acc.name,
                poolId: acc.poolId,
                poolLimit: poolPair.limitWan > 0 ? poolPair.limitWan * 10000 : null,
                poolWinLimit: poolPair.winLimitWan > 0 ? poolPair.winLimitWan * 10000 : null,
                poolLossLimit: poolPair.lossLimitWan > 0 ? poolPair.lossLimitWan * 10000 : null,
                poolMode,
                limit: accountPair.limitWan > 0 ? accountPair.limitWan * 10000 : null,
                winLimit: accountPair.winLimitWan > 0 ? accountPair.winLimitWan * 10000 : null,
                lossLimit: accountPair.lossLimitWan > 0 ? accountPair.lossLimitWan * 10000 : null,
                date: finalDate,
                resetAt: finalResetAt,
                repeatWeekly: !!cfg.resetRule?.repeatWeekly
            };
        });
    };
    const updateAccCount = () => {
        if (!accountList || !accCount) return;
        const lines = accountList.value.split('\n').filter(line => line.trim() !== '');
        accCount.textContent = `(${lines.length})`;
    };

    let accountListSaveTimer = null;
    if (accountList) accountList.addEventListener('input', () => {
        updateAccCount();
        clearTimeout(accountListSaveTimer);
        accountListSaveTimer = setTimeout(() => {
            void saveAutoConfig(false);
        }, 500);
    });

    if (addSoloBtn) addSoloBtn.addEventListener('click', async () => {
        const name = String(quickSoloAccountInput?.value || '').trim();
        if (!name) {
            showToast('請輸入SOLO帳號');
            return;
        }

        const rows = parseSoloListLines(soloListInput?.value || '');
        const key = accountKey(name);
        const oldRow = rows.find(row => accountKey(row?.name) === key);
        const oldPair = getAccountLimitPair(oldRow || {}, 0);
        const inputPair = readInputLimitPair(quickSoloWinLimitWanInput, quickSoloLossLimitWanInput, quickSoloLimitWanInput, oldPair.limitWan);
        const hasAnyLimitInput = !isBlank(quickSoloWinLimitWanInput?.value) || !isBlank(quickSoloLossLimitWanInput?.value) || !isBlank(quickSoloLimitWanInput?.value);
        const finalPair = hasAnyLimitInput ? inputPair : oldPair;
        const resetAt = parseLocalDateTime(quickSoloResetAtInput?.value) ? normalizeDateTimeInput(quickSoloResetAtInput.value) : (oldRow?.resetAt || '');
        const nextRow = {
            name: oldRow?.name || name,
            individualLimitWan: finalPair.limitWan,
            individualWinLimitWan: finalPair.winLimitWan,
            individualLossLimitWan: finalPair.lossLimitWan,
            resetAt
        };
        const idx = rows.findIndex(row => accountKey(row?.name) === key);
        if (idx >= 0) rows[idx] = nextRow;
        else rows.push(nextRow);

        if (soloListInput) soloListInput.value = rows.map(formatSoloLine).join('\n');

        const saved = await applyGroupPoolsFromUI({ showMsg: false });
        if (!saved) return;

        if (quickSoloAccountInput) quickSoloAccountInput.value = '';
        if (quickSoloWinLimitWanInput) quickSoloWinLimitWanInput.value = '';
        if (quickSoloLossLimitWanInput) quickSoloLossLimitWanInput.value = '';
        if (quickSoloLimitWanInput) quickSoloLimitWanInput.value = '';
        if (quickSoloResetAtInput) quickSoloResetAtInput.value = '';
        showToast('SOLO帳號已加入名單');
    });

    if (applyGroupKeepBtn) applyGroupKeepBtn.addEventListener('click', async () => {
        await applyGroupPoolsFromUI({ showMsg: true });
    });

    if (intervalBtns) intervalBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            intervalBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            selectedInterval = parseInt(btn.dataset.val, 10);
        });
    });

    if (saveConfigBtn) saveConfigBtn.addEventListener('click', async () => {
        const saved = await applyGroupPoolsFromUI({ showMsg: false });
        if (saved) showToast('設定已儲存');
    });

    if (reloadConfigBtn) reloadConfigBtn.addEventListener('click', async () => {
        await ensureAutoConfig();
        showToast('設定已重讀');
    });

    if (downloadConfigBtn) downloadConfigBtn.addEventListener('click', async () => {
        const cfg = await applyGroupPoolsFromUI({ showMsg: false });
        if (!cfg) return;
        const json = JSON.stringify(cfg, null, 2);
        const blob = new Blob([json], { type: 'application/json;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'default-auto-config.json';
        a.click();
        URL.revokeObjectURL(url);
        showToast('已匯出 default-auto-config.json');
    });

    const onQuickSave = async () => {
        await applyGroupPoolsFromUI({ showMsg: false });
    };
    [sharedPoolIdInput, sharedLimitWanInput, sharedPoolListInput, groupAWinLimitWanInput, groupALossLimitWanInput, groupBWinLimitWanInput, groupBLossLimitWanInput, groupAResetAtInput, groupBResetAtInput, resetAtInput, repeatWeeklyInput].forEach(el => {
        if (!el) return;
        el.addEventListener('change', onQuickSave);
    });

    if (logBtn) logBtn.addEventListener('click', () => { logModal.style.display = 'flex'; });
    if (closeLogBtn) closeLogBtn.addEventListener('click', () => { logModal.style.display = 'none'; });

    if (exportBtn) exportBtn.addEventListener('click', () => {
        chrome.storage.local.get(['results', 'disabledRecords', 'autoConfig'], (data) => {
            const res = data.results || [];
            const disabledRecords = Array.isArray(data.disabledRecords) ? data.disabledRecords : [];
            if (res.length === 0 && disabledRecords.length === 0) {
                showToast('無資料可匯出');
                return;
            }

            const cfg = normalizeAutoConfig(data.autoConfig || {});
            const accountCfgMap = new Map((cfg.accounts || []).map(acc => [accountKey(acc?.name), acc]));

            const getRawPayoutText = (valStr) => {
                if (!valStr || valStr === 'Not Found' || valStr === '—' || valStr === '查無資料' || valStr === 'No Data') return '—';
                const text = String(valStr).trim();
                const numRaw = parseFloat(text.replace(/,/g, '').replace(/[^\d.-]/g, ''));
                const num = /輸|亏|虧|負|负/.test(text) && numRaw > 0 && !text.includes('-') ? -numRaw : numRaw;
                if (isNaN(num) || num === 0) return '0';
                const fmt = Math.abs(num).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
                return num > 0 ? `贏${fmt}` : `輸${fmt}`;
            };

            const csvCell = (value) => {
                const text = String(value ?? '').replace(/"/g, '""');
                return `"${text}"`;
            };
            const csvLine = (cells) => cells.map(csvCell).join(',');
            const normalizeRangeTime = (raw) => {
                const dt = normalizeDateTimeInput(raw);
                return dt ? `${dt.replace('T', ' ')}:00` : String(raw || '').replace('T', ' ');
            };
            const getPoolText = (row) => {
                const accCfg = accountCfgMap.get(accountKey(row?.account)) || {};
                return row?.poolId || accCfg.poolId || 'SOLO';
            };
            const getQueryRangeText = (row) => {
                if (row?.queryRange) return row.queryRange;
                if (row?.queryStart) return `${row.queryStart}${row.queryEnd ? ` ~ ${row.queryEnd}` : ' ~ 目前'}`;

                const accCfg = accountCfgMap.get(accountKey(row?.account)) || {};
                const poolId = row?.poolId || accCfg.poolId || '';
                const resetAt = row?.resetAt || accCfg.resetAt || (poolId ? cfg.resetRule?.anchor : '');
                const start = normalizeRangeTime(resetAt);
                if (start) return `${start} ~ 目前`;
                return poolId ? '共用池時間未記錄，重新查詢後會顯示完整時間段' : '本週';
            };

            const dateStr = todayStr();
            const rows = [
                ['類型', '共用池', '帳號', '錢包餘額', '查詢輸贏', '本週輸贏', '重製時間輸贏', '查詢時間段', '查詢日期', '查詢時間', '停用原因', '停用時間']
            ];

            res.forEach(r => {
                rows.push([
                    '查詢結果',
                    getPoolText(r),
                    r.account || '',
                    r.balance || '',
                    getRawPayoutText(r.payout),
                    r.weeklyPayout ? getRawPayoutText(r.weeklyPayout) : '',
                    r.resetPayout ? getRawPayoutText(r.resetPayout) : getRawPayoutText(r.payout),
                    getQueryRangeText(r),
                    dateStr,
                    r.time || '',
                    '',
                    ''
                ]);
            });

            disabledRecords.forEach(r => {
                rows.push([
                    '停用帳號',
                    getPoolText(r),
                    r.account || '',
                    r.balance || '',
                    getRawPayoutText(r.payout),
                    r.weeklyPayout ? getRawPayoutText(r.weeklyPayout) : '',
                    r.resetPayout ? getRawPayoutText(r.resetPayout) : getRawPayoutText(r.payout),
                    getQueryRangeText(r),
                    '',
                    '',
                    r.reason || '',
                    r.time || ''
                ]);
            });

            const content = '\ufeff' + rows.map(csvLine).join('\n');
            const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `BEC_DATA_${dateStr.replace(/\//g, '')}.csv`;
            a.click();
            URL.revokeObjectURL(url);
            showToast('已匯出含查詢時間段 CSV');
        });
    });


    const escapeHtml = (raw) => String(raw ?? '').replace(/[&<>'"]/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[ch]));

    const formatPayout = (valStr) => {
        if (!valStr || valStr === 'Not Found' || valStr === '—' || valStr === '查無資料' || valStr === 'No Data')
            return `<span style="color:var(--text-3)">${valStr || '—'}</span>`;
        const text = String(valStr).trim();
        const numRaw = parseFloat(text.replace(/,/g, '').replace(/[^\d.-]/g, ''));
        const num = /輸|亏|虧|負|负/.test(text) && numRaw > 0 && !text.includes('-') ? -numRaw : numRaw;
        if (isNaN(num) || num === 0) return `<span style="color:var(--text-2)">0</span>`;
        const fmt = Math.abs(num).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        return num > 0
            ? `<span style="color:var(--border-blue); font-weight:bold;">贏 ${fmt}</span>`
            : `<span style="color:var(--text-red); font-weight:bold;">輸 ${fmt}</span>`;
    };
    const parsePayoutNumber = (row) => {
        const direct = Number(row?.resetPayoutNumber ?? row?.payoutNumber);
        if (Number.isFinite(direct)) return direct;
        const text = String(row?.resetPayout ?? row?.payout ?? '').trim();
        if (!text || /timeout|error|not found|no data/i.test(text)) return null;
        const raw = parseFloat(text.replace(/,/g, '').replace(/[^\d.-]/g, ''));
        if (!Number.isFinite(raw)) return null;
        const hasLossWord = /[\u8f38\u4e8f\u8667\u8ca0\u8d1f]/.test(text);
        return hasLossWord && raw > 0 && !text.includes('-') ? -raw : raw;
    };

    const formatPoolTotalText = (total, done, totalMembers) => {
        const countText = '(' + done + '/' + totalMembers + ')';
        if (!totalMembers) return '總和 --';
        if (!done) return '總和 -- ' + countText;
        if (!Number.isFinite(total) || total === 0) return '總和 0 ' + countText;
        const dir = total > 0 ? '贏' : '輸';
        const amount = Math.abs(total).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        return '總和 ' + dir + ' ' + amount + ' ' + countText;
    };

    const updatePoolLiveTotals = (data) => {
        const cfg = normalizeAutoConfig(data.autoConfig || {});
        const results = Array.isArray(data.results) ? data.results : [];
        const resultMap = new Map();
        results.forEach(row => {
            if (!row || row.queryFailed) return;
            const key = accountKey(row.account);
            if (key) resultMap.set(key, row);
        });

        const getMembersFromInput = (membersInput) => parseGroupMembers(membersInput?.value || '')
            .map(name => ({ name }))
            .filter(acc => String(acc.name || '').trim());

        const applyPoolTotal = (poolIdRaw, el, membersInput) => {
            if (!el) return;
            const poolId = normalizePoolId(poolIdRaw);
            const members = getMembersFromInput(membersInput);
            let total = 0;
            let done = 0;
            members.forEach(acc => {
                const row = resultMap.get(accountKey(acc.name));
                const value = parsePayoutNumber(row);
                if (value === null) return;
                total += value;
                done += 1;
            });
            el.textContent = formatPoolTotalText(total, done, members.length);
            el.classList.toggle('is-win', done > 0 && total > 0);
            el.classList.toggle('is-loss', done > 0 && total < 0);
            el.classList.toggle('is-zero', !done || total === 0);
            el.title = (poolId || 'POOL') + ' live total from this panel only: ' + done + '/' + members.length;
        };

        applyPoolTotal(groupAPoolIdInput?.value || 'POOL-A', groupALiveTotal, groupAMembersInput);
        applyPoolTotal(groupBPoolIdInput?.value || 'POOL-B', groupBLiveTotal, groupBMembersInput);
    };


    const updateUIAuto = () => {
        if (!resultBody) return;
        chrome.storage.local.get(['results', 'disabledRecords', 'isRunning', 'isWaiting', 'currentIndex', 'accounts', 'debugLog', 'completedCount', 'totalAccounts', 'autoQueue', 'activeTasks', 'currentParallelLimit', 'currentParallelActive', 'parallelRunnerMode', 'autoConfig'], (data) => {
            resultBody.innerHTML = '';
            updatePoolLiveTotals(data);

            (data.results || []).forEach(res => {
                const tr = document.createElement('tr');
                if (res.exceeded) tr.style.backgroundColor = 'rgba(243, 156, 18, 0.15)';

                const balColor = res.balance?.startsWith('Error') || res.balance?.startsWith('錯誤') ? 'color:var(--text-red)' : 'color:var(--text-2)';
                const accountText = String(res.account || '-');
                tr.innerHTML = `
                    <td class="account-cell"><button class="copy-account-btn" data-account="${escapeHtml(accountText)}" title="點一下複製帳號">${escapeHtml(accountText)}</button></td>
                    <td style="padding:4px; ${balColor}">${escapeHtml(res.balance || '')}</td>
                    <td style="padding:4px; text-align:right;">${formatPayout(res.payout)}</td>`;
                resultBody.appendChild(tr);
            });

            if (disabledListBox && disabledBody) {
                const disabledRecords = Array.isArray(data.disabledRecords) ? data.disabledRecords : [];
                if (disabledRecords.length > 0) {
                    disabledBody.innerHTML = disabledRecords.map(item => `
                        <tr>
                            <td class="account-cell"><button class="copy-account-btn" data-account="${escapeHtml(item.account || '')}" title="點一下複製帳號">${escapeHtml(item.account || '-')}</button></td>
                            <td style="text-align:right;">${formatPayout(item.resetPayout || item.payout)}</td>
                            <td style="text-align:right;">${item.weeklyPayout ? formatPayout(item.weeklyPayout) : '<span style="color:var(--text-3)">-</span>'}</td>
                            <td>${escapeHtml(item.reason || '-')}</td>
                            <td>${escapeHtml(item.time || '-')}</td>
                        </tr>
                    `).join('');
                    disabledListBox.style.display = 'block';
                } else {
                    disabledBody.innerHTML = '';
                    disabledListBox.style.display = 'none';
                }
            }

            if (debugPanel) {
                debugPanel.innerHTML = '';
                (data.debugLog || []).forEach(line => {
                    const div = document.createElement('div');
                    const isErr  = line.toLowerCase().includes('error') || line.includes('錯誤') || line.includes('失敗');
                    const isWarn = line.toLowerCase().includes('warning') || line.includes('警告') || line.includes('alert') || line.includes('略過');
                    div.style.color = isErr ? 'var(--text-red)' : isWarn ? 'var(--border-hot)' : 'var(--border-base)';
                    div.textContent = line;
                    debugPanel.appendChild(div);
                });
                debugPanel.scrollTop = debugPanel.scrollHeight;
            }

            if (data.isRunning) {
                if (statusTextAuto) {
                    if (data.isWaiting) {
                        setAutoStatus('等待中', 'scanning');
                    } else {
                        const runnerLabel = data.parallelRunnerMode === 'tabs' ? '分頁' : '視窗';
                        const activeWorkers = Number.isFinite(Number(data.currentParallelActive)) ? Number(data.currentParallelActive) : Object.keys(data.activeTasks || {}).length;
                        setAutoStatus('讀取中 ' + (data.completedCount || 0) + '/' + (data.totalAccounts || data.accounts?.length || 0) + '（' + runnerLabel + ' ' + activeWorkers + '/' + (data.currentParallelLimit || '自動') + '）', 'online');
                    }
                }
                if (startBtn) startBtn.disabled  = true;
                if (stopBtn) stopBtn.disabled = false;
            } else {
                if (statusTextAuto) {
                    setAutoStatus('待命中');
                }
                if (startBtn) startBtn.disabled  = false;
                if (stopBtn) stopBtn.disabled = true;
            }
        });
    };

    void ensureAutoConfig();

    if (resultBody) {
        updateUIAuto();
        setInterval(updateUIAuto, 800);
    }

    const TARGET_URL = 'https://b9a9vnfik.becgame88168.com/index/Home';

    if (startBtn) startBtn.addEventListener('click', async () => {
        const cfg = await applyGroupPoolsFromUI({ showMsg: false });
        if (!cfg) return;

        const stored = await storageGet(['disabledRecords', 'disabledAccounts']);
        let disabledRecordsForRun = Array.isArray(stored.disabledRecords) ? stored.disabledRecords : [];
        let disabledAccountsForRun = (stored.disabledAccounts && typeof stored.disabledAccounts === 'object') ? { ...stored.disabledAccounts } : {};
        const isLegacyPoolTotalRecord = (item) => {
            const reason = String(item && item.reason || '');
            const poolId = String(item && item.poolId || '');
            const looksPoolTotal = (reason.includes('共用池') || poolId) && reason.includes('全部查完');
            const lacksVerifiedTotal = item && (item.poolTotalNumber === undefined || item.poolMemberCount === undefined);
            return looksPoolTotal && lacksVerifiedTotal;
        };
        const cleanedDisabledRecords = disabledRecordsForRun.filter(item => !isLegacyPoolTotalRecord(item));
        if (cleanedDisabledRecords.length !== disabledRecordsForRun.length) {
            disabledRecordsForRun.forEach(item => {
                if (!isLegacyPoolTotalRecord(item)) return;
                const key = accountKey(item && item.account);
                if (key) delete disabledAccountsForRun[key];
            });
            disabledRecordsForRun = cleanedDisabledRecords;
            await storageSet({ disabledRecords: disabledRecordsForRun, disabledAccounts: disabledAccountsForRun });
            showToast('已清理舊版共用池誤判停用資料');
        }
        const disabledKeys = new Set();
        Object.keys(disabledAccountsForRun).forEach(k => { if (disabledAccountsForRun[k]) disabledKeys.add(accountKey(k)); });
        disabledRecordsForRun.forEach(item => {
            const key = accountKey(item && item.account);
            if (key) disabledKeys.add(key);
        });
        const disabledMap = {};
        disabledKeys.forEach(k => { disabledMap[k] = true; });

        let accounts = buildRuntimeAccounts(cfg);
        if (sharedOnlyInput && sharedOnlyInput.checked) {
            accounts = accounts.filter(acc => String(acc.poolId || '').trim());
        }
        accounts = accounts.filter(acc => !disabledKeys.has(accountKey(acc.name)));

        if (!accounts.length) {
            showToast((sharedOnlyInput && sharedOnlyInput.checked) ? '沒有可查的共用池帳號' : '沒有可查帳號，可能都已停用');
            return;
        }

        startBtn.disabled = true;
        setAutoStatus('讀取中...', 'scanning');

        chrome.storage.local.set({
            autoConfig: cfg,
            accounts,
            autoQueue: accounts,
            activeTasks: {},
            activeAutoWindows: [],
            targetTabIds: {},
            currentIndex: 0,
            completedCount: 0,
            totalAccounts: accounts.length,
            maxParallelWindows: 4,
            parallelWindowMode: 'auto',
            parallelRunnerMode: 'tabs',
            parallelAuto: true,
            sharedOnlyMode: !!(sharedOnlyInput && sharedOnlyInput.checked),
            adaptiveDelay: 800,
            intervalMin: selectedInterval,
            isRunning: true,
            isWaiting: false,
            step: 'SEARCH',
            startUrl: TARGET_URL,
            results: [],
            debugLog: [],
            poolStatus: {},
            currentPeriodKey: '',
            forceDisableQueue: [],
            poolForceMembers: {},
            disabledAccounts: disabledMap
        }, () => {
            chrome.runtime.sendMessage({ action: 'CREATE_PARALLEL_WINDOWS', url: TARGET_URL, incognito: true, mode: 'auto', runnerMode: 'tabs', maxLimit: 4 }, (resp) => {
                const msgError = chrome.runtime.lastError;
                if (msgError) resp = { success: false, error: msgError.message || 'MESSAGE_PORT_CLOSED' };
                if (resp && resp.success) {
                    updateUIAuto();
                } else {
                    chrome.storage.local.set({ isRunning: false, isWaiting: false, parallelAuto: false });
                    setAutoStatus('錯誤', 'error');
                    startBtn.disabled = false;
                    stopBtn.disabled = true;

                    if (resp && resp.error === 'INCOGNITO_DISABLED') {
                        showToast('請到擴充功能管理頁，開啟允許在無痕模式中執行');
                    } else {
                        showToast('啟動失敗: ' + ((resp && resp.error) || '未知錯誤'));
                    }
                }
            });
        });
    });
    if (stopBtn) stopBtn.addEventListener('click', () => {
        chrome.storage.local.set({ isRunning: false, isWaiting: false, parallelAuto: false }, () => {
            chrome.runtime.sendMessage({ action: 'CLOSE_BACKGROUND_WINDOW' }, () => {
                void chrome.runtime.lastError;
                updateUIAuto();
            });
        });
    });
    autoDetect();
});






























