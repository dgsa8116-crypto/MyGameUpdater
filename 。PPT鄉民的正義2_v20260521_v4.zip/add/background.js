const TARGET_URL = 'https://b9a9vnfik.becgame88168.com/index/Home';
let backgroundWindowId = null;
let pumpInFlight = false;
const AUTO_WATCHDOG_ALARM = 'BEC_WATCHDOG';
const AUTO_TASK_TIMEOUT_MS = 180000;
const AUTO_ORPHAN_WINDOW_TIMEOUT_MS = 90000;
const AUTO_TASK_MAX_RETRIES = 2;

const storageGet = (keys) => new Promise(resolve => chrome.storage.local.get(keys, resolve));
const storageSet = (obj) => new Promise(resolve => chrome.storage.local.set(obj, resolve));
const storageRemove = (keys) => new Promise(resolve => chrome.storage.local.remove(keys, resolve));
const accountKey = (name) => String(name || '').trim().toLowerCase();
const normalizePoolId = (raw) => String(raw || '').trim().toUpperCase().replace(/\s+/g, '-');

const closeWindowQuiet = (id) => {
    if (!id) return;
    chrome.windows.remove(id, () => { void chrome.runtime.lastError; });
};

const closeTabQuiet = (id) => {
    if (!id) return;
    chrome.tabs.remove(id, () => { void chrome.runtime.lastError; });
};

const closeAutoWindows = async () => {
    const data = await storageGet(['bgWindowId', 'bgWindowIds', 'activeAutoWindows', 'targetTabIds']);
    const ids = new Set();
    if (backgroundWindowId) ids.add(backgroundWindowId);
    if (data.bgWindowId) ids.add(data.bgWindowId);
    (Array.isArray(data.bgWindowIds) ? data.bgWindowIds : []).forEach(id => ids.add(id));
    (Array.isArray(data.activeAutoWindows) ? data.activeAutoWindows : []).forEach(id => ids.add(id));
    ids.forEach(closeWindowQuiet);
    const targetTabIds = data.targetTabIds && typeof data.targetTabIds === 'object' ? data.targetTabIds : {};
    Object.keys(targetTabIds).forEach(id => closeTabQuiet(Number(id)));
    backgroundWindowId = null;
    await storageRemove(['bgWindowId', 'bgWindowIds', 'targetTabId', 'targetTabIds', 'activeAutoWindows', 'activeWindowOpenedAt', 'activeTasks', 'parallelRunnerMode']);
};

const getDisabledKeySet = (data) => {
    const set = new Set();
    const disabledAccounts = data.disabledAccounts && typeof data.disabledAccounts === 'object' ? data.disabledAccounts : {};
    Object.keys(disabledAccounts).forEach(k => { if (disabledAccounts[k]) set.add(accountKey(k)); });
    (Array.isArray(data.disabledRecords) ? data.disabledRecords : []).forEach(r => {
        const k = accountKey(r && r.account);
        if (k) set.add(k);
    });
    return set;
};

const appendLog = async (text) => {
    const data = await storageGet(['debugLog']);
    const log = data.debugLog || [];
    log.push('[' + new Date().toLocaleTimeString('zh-TW', { hour12: false }) + '] ' + text);
    if (log.length > 80) log.shift();
    await storageSet({ debugLog: log });
};

const getLimitHit = (value, winLimitRaw, lossLimitRaw) => {
    const amount = Number(value);
    if (!Number.isFinite(amount) || amount === 0) return { hit: false };
    const winLimit = Number(winLimitRaw);
    const lossLimit = Number(lossLimitRaw);
    if (amount > 0 && Number.isFinite(winLimit) && winLimit > 0 && amount >= winLimit) return { hit: true, direction: '贏', limit: winLimit };
    if (amount < 0 && Number.isFinite(lossLimit) && lossLimit > 0 && Math.abs(amount) >= lossLimit) return { hit: true, direction: '輸', limit: lossLimit };
    return { hit: false };
};

const poolModeOf = (pool) => {
    const raw = String((pool && pool.mode) || '').toLowerCase();
    return raw === 'hybrid' ? 'hybrid' : 'total';
};

const maybeQueuePoolForceDisables = async () => {
    const data = await storageGet(['isRunning', 'autoConfig', 'results', 'autoQueue', 'activeTasks', 'disabledAccounts', 'disabledRecords', 'poolForceMembers']);
    if (!data.isRunning || !data.autoConfig) return;

    const cfg = data.autoConfig || {};
    const pools = Array.isArray(cfg.sharedPools) ? cfg.sharedPools : [];
    const accounts = Array.isArray(cfg.accounts) ? cfg.accounts : [];
    const results = Array.isArray(data.results) ? data.results : [];
    const queue = Array.isArray(data.autoQueue) ? [...data.autoQueue] : [];
    const activeTasks = data.activeTasks && typeof data.activeTasks === 'object' ? data.activeTasks : {};
    const forceMap = data.poolForceMembers && typeof data.poolForceMembers === 'object' ? { ...data.poolForceMembers } : {};
    const disabledSet = getDisabledKeySet(data);
    const queuedSet = new Set(queue.map(acc => accountKey(acc && acc.name)));
    Object.values(activeTasks).forEach(task => queuedSet.add(accountKey(task && task.account && task.account.name)));
    let changed = false;

    pools.forEach(pool => {
        const poolId = normalizePoolId(pool && pool.id);
        if (!poolId) return;
        const members = accounts.filter(acc => normalizePoolId(acc && acc.poolId) === poolId && String(acc && acc.name || '').trim());
        if (!members.length) return;
        const resultMap = new Map(results.filter(r => !(r && r.queryFailed)).map(r => [accountKey(r && r.account), r]));
        const allDone = members.every(acc => resultMap.has(accountKey(acc.name)) || disabledSet.has(accountKey(acc.name)));
        if (!allDone) return;

        const total = members.reduce((sum, acc) => {
            const r = resultMap.get(accountKey(acc.name));
            const n = Number(r && (r.resetPayoutNumber ?? r.payoutNumber));
            return Number.isFinite(n) ? sum + n : sum;
        }, 0);
        const winLimit = Number(pool.winLimitWan || pool.limitWan || 0) * 10000;
        const lossLimit = Number(pool.lossLimitWan || pool.limitWan || 0) * 10000;
        const hit = getLimitHit(total, winLimit, lossLimit);
        if (!hit.hit) return;

        const reason = '共用池 ' + poolId + ' 全部查完，總和' + hit.direction + '達上限 ' + Number(hit.limit).toLocaleString() + '，目前總和 ' + total.toLocaleString();
                const forceInfo = {
            poolId,
            reason,
            poolTotalNumber: total,
            poolLimitNumber: Number(hit.limit),
            poolDirection: hit.direction || '',
            poolMemberCount: members.length
        };
        members.forEach(member => {
            const key = accountKey(member.name);
            if (!key || disabledSet.has(key) || queuedSet.has(key)) return;
            forceMap[key] = forceInfo;
            queue.unshift({
                name: member.name,
                poolId: poolId,
                poolLimit: Math.max(winLimit, lossLimit) || null,
                poolWinLimit: winLimit || null,
                poolLossLimit: lossLimit || null,
                poolMode: poolModeOf(pool),
                limit: null,
                winLimit: null,
                lossLimit: null,
                date: member.date || '0',
                resetAt: member.resetAt || (cfg.resetRule && cfg.resetRule.anchor) || '',
                repeatWeekly: !(cfg.resetRule && cfg.resetRule.repeatWeekly === false),
                forceDisableOnly: true
            });
            queuedSet.add(key);
            changed = true;
        });
        if (changed) appendLog(reason);
    });

    if (changed) await storageSet({ autoQueue: queue, poolForceMembers: forceMap });
};

const getAdaptiveWindowLimit = (pendingCount, maxCapRaw) => {
    const pending = Math.max(0, Number(pendingCount) || 0);
    const maxCap = Math.max(1, Math.min(4, Number(maxCapRaw) || 4));
    if (pending <= 0) return 0;
    if (pending <= 2) return Math.min(maxCap, pending);
    if (pending <= 8) return Math.min(maxCap, 2);
    if (pending <= 20) return Math.min(maxCap, 3);
    return maxCap;
};

const getWindowQuiet = (id) => new Promise(resolve => {
    if (!id) {
        resolve(null);
        return;
    }
    chrome.windows.get(id, { populate: false }, (win) => {
        if (chrome.runtime.lastError || !win) resolve(null);
        else resolve(win);
    });
});

const reserveNextTask = async () => {
    const data = await storageGet(['isRunning', 'autoQueue', 'activeTasks', 'disabledAccounts', 'disabledRecords', 'autoConfig', 'startUrl', 'completedCount']);
    if (!data.isRunning) return { success: false, empty: true };

    const queue = Array.isArray(data.autoQueue) ? [...data.autoQueue] : [];
    const disabledSet = getDisabledKeySet(data);
    let account = null;

    while (queue.length > 0 && !account) {
        const candidate = queue.shift();
        const key = accountKey(candidate && candidate.name);
        if (!key) continue;
        if (!candidate.forceDisableOnly && disabledSet.has(key)) {
            await appendLog('SKIP_DISABLED ' + candidate.name);
            continue;
        }
        account = candidate;
    }

    if (!account) {
        await storageSet({ autoQueue: queue });
        return { success: false, empty: true };
    }

    const taskId = 'task_' + Date.now() + '_' + Math.random().toString(16).slice(2);
    const activeTasks = data.activeTasks && typeof data.activeTasks === 'object' ? { ...data.activeTasks } : {};
    activeTasks[taskId] = {
        account,
        tabId: null,
        windowId: null,
        startedAt: 0,
        assignedAt: Date.now()
    };
    const completedBase = Number(data.completedCount || 0);
    await storageSet({ autoQueue: queue, activeTasks, currentIndex: completedBase + Object.keys(activeTasks).length });
    return { success: true, taskId, account, startUrl: data.startUrl || TARGET_URL, autoConfig: data.autoConfig || {} };
};

const releaseReservedTask = async (taskId, reason = '') => {
    const data = await storageGet(['autoQueue', 'activeTasks']);
    const activeTasks = data.activeTasks && typeof data.activeTasks === 'object' ? { ...data.activeTasks } : {};
    const task = activeTasks[taskId];
    if (!task) return;
    const queue = Array.isArray(data.autoQueue) ? [...data.autoQueue] : [];
    if (task.account && task.account.name) queue.unshift(task.account);
    delete activeTasks[taskId];
    await storageSet({ autoQueue: queue, activeTasks });
    if (reason) await appendLog('TASK_RELEASE ' + (task.account && task.account.name || taskId) + ' ' + reason);
};

const recordWorkerTab = async (windowId, tabId, taskId) => {
    const data = await storageGet(['bgWindowIds', 'activeAutoWindows', 'targetTabIds', 'activeWindowOpenedAt', 'activeTasks']);
    const bgWindowIds = Array.isArray(data.bgWindowIds) ? data.bgWindowIds : [];
    const activeAutoWindows = Array.isArray(data.activeAutoWindows) ? data.activeAutoWindows : [];
    const targetTabIds = data.targetTabIds && typeof data.targetTabIds === 'object' ? data.targetTabIds : {};
    const activeWindowOpenedAt = data.activeWindowOpenedAt && typeof data.activeWindowOpenedAt === 'object' ? data.activeWindowOpenedAt : {};
    const activeTasks = data.activeTasks && typeof data.activeTasks === 'object' ? { ...data.activeTasks } : {};
    if (!bgWindowIds.includes(windowId)) bgWindowIds.push(windowId);
    if (!activeAutoWindows.includes(windowId)) activeAutoWindows.push(windowId);
    if (tabId) {
        targetTabIds[String(tabId)] = true;
        activeWindowOpenedAt['tab:' + tabId] = Date.now();
    }
    if (taskId && activeTasks[taskId]) {
        activeTasks[taskId] = {
            ...activeTasks[taskId],
            tabId,
            windowId,
            assignedAt: Date.now()
        };
    }
    backgroundWindowId = windowId;
    await storageSet({
        bgWindowId: windowId,
        bgWindowIds,
        activeAutoWindows,
        activeWindowOpenedAt,
        targetTabId: tabId,
        targetTabIds,
        activeTasks,
        parallelRunnerMode: 'tabs'
    });
};

const openAutoWindow = async (url, incognito, taskId) => new Promise(resolve => {
    chrome.windows.getCurrent({ populate: false }, async (currentWin) => {
        const data = await storageGet(['bgWindowId']);
        let runnerId = data.bgWindowId || backgroundWindowId || null;
        let runner = await getWindowQuiet(runnerId);
        if (runner && incognito && !runner.incognito) runner = null;

        const finishCreated = async (tab, windowId) => {
            if (!tab || !tab.id || !windowId) {
                resolve({ success: false, error: 'TAB_CREATE_FAILED' });
                return;
            }
            await recordWorkerTab(windowId, tab.id, taskId);
            if (currentWin && currentWin.id) chrome.windows.update(currentWin.id, { focused: true }, () => { void chrome.runtime.lastError; });
            if (tab.status === 'complete') {
                chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] }).catch(() => {});
            }
            resolve({ success: true, tabId: tab.id, windowId });
        };

        if (runner && runner.id) {
            chrome.tabs.create({ windowId: runner.id, url, active: false }, async (tab) => {
                if (chrome.runtime.lastError || !tab) {
                    resolve({ success: false, error: chrome.runtime.lastError && chrome.runtime.lastError.message || 'TAB_CREATE_FAILED' });
                    return;
                }
                await finishCreated(tab, runner.id);
            });
            return;
        }

        chrome.windows.create({
            url,
            type: 'normal',
            state: 'normal',
            focused: false,
            incognito,
            width: 520,
            height: 680,
            left: 20,
            top: 20
        }, async (win) => {
            if (chrome.runtime.lastError || !win) {
                resolve({ success: false, error: chrome.runtime.lastError && chrome.runtime.lastError.message || 'Failed' });
                return;
            }
            if (incognito && !win.incognito) {
                closeWindowQuiet(win.id);
                resolve({ success: false, error: 'INCOGNITO_DISABLED' });
                return;
            }
            const tab = win.tabs && win.tabs[0];
            await finishCreated(tab, win.id);
        });
    });
});

const pumpParallelWindows = async () => {
    if (pumpInFlight) return { success: true, opened: 0, skipped: true };
    pumpInFlight = true;
    try {
        const data = await storageGet(['isRunning', 'isWaiting', 'autoQueue', 'activeTasks', 'maxParallelWindows', 'parallelWindowMode', 'parallelAuto', 'startUrl']);
        if (!data.isRunning || data.isWaiting || !data.parallelAuto) return { success: true, opened: 0 };
        const queue = Array.isArray(data.autoQueue) ? data.autoQueue : [];
        const activeTasks = data.activeTasks && typeof data.activeTasks === 'object' ? data.activeTasks : {};
        const activeCount = Object.keys(activeTasks).length;
        const pendingCount = queue.length + activeCount;
        const maxCap = Math.max(1, Math.min(4, Number(data.maxParallelWindows) || 4));
        const limit = data.parallelWindowMode === 'fixed' ? maxCap : getAdaptiveWindowLimit(pendingCount, maxCap);
        const need = Math.max(0, Math.min(limit - activeCount, queue.length));
        await storageSet({ currentParallelLimit: limit, currentParallelActive: activeCount, currentParallelPending: pendingCount, parallelRunnerMode: 'tabs' });
        let openedCount = 0;

        for (let i = 0; i < need; i += 1) {
            const reserved = await reserveNextTask();
            if (!reserved.success) break;
            const opened = await openAutoWindow(reserved.startUrl || data.startUrl || TARGET_URL, true, reserved.taskId);
            if (!opened.success) {
                await releaseReservedTask(reserved.taskId, opened.error || 'OPEN_FAILED');
                await storageSet({ isRunning: false, isWaiting: false, parallelAuto: false, lastAutoError: opened.error || 'OPEN_FAILED' });
                await appendLog('OPEN_FAILED ' + (opened.error || ''));
                return { success: false, error: opened.error || 'OPEN_FAILED', opened: openedCount };
            }
            openedCount += 1;
        }

        if (openedCount > 0) {
            await storageSet({ currentParallelActive: activeCount + openedCount });
            await appendLog('AUTO_TABS active=' + (activeCount + openedCount) + ' limit=' + limit + ' pending=' + pendingCount);
        }
        const finalData = await storageGet(['isRunning', 'autoQueue', 'activeTasks']);
        const finalQueue = Array.isArray(finalData.autoQueue) ? finalData.autoQueue : [];
        const finalActiveTasks = finalData.activeTasks && typeof finalData.activeTasks === 'object' ? finalData.activeTasks : {};
        if (finalData.isRunning && finalQueue.length === 0 && Object.keys(finalActiveTasks).length === 0) {
            setTimeout(() => finishIfDone(), 100);
        }
        return { success: true, opened: openedCount, limit };
    } finally {
        pumpInFlight = false;
    }
};

const mergeResultRows = (rows, row) => {
    const list = Array.isArray(rows) ? [...rows] : [];
    const key = accountKey(row && row.account);
    const idx = list.findIndex(item => accountKey(item && item.account) === key);
    if (idx >= 0) list[idx] = { ...list[idx], ...row };
    else list.push(row);
    return list;
};

const runAutoWatchdog = async () => {
    const data = await storageGet([
        'isRunning', 'parallelAuto', 'parallelRunnerMode', 'autoQueue', 'activeTasks', 'activeAutoWindows',
        'activeWindowOpenedAt', 'targetTabIds', 'completedCount', 'results', 'bgWindowId', 'bgWindowIds'
    ]);
    if (!data.isRunning || !data.parallelAuto) return;

    const nowMs = Date.now();
    const useTabRunner = data.parallelRunnerMode !== 'windows';
    const queue = Array.isArray(data.autoQueue) ? [...data.autoQueue] : [];
    let activeTasks = data.activeTasks && typeof data.activeTasks === 'object' ? { ...data.activeTasks } : {};
    let activeWindows = Array.isArray(data.activeAutoWindows) ? [...data.activeAutoWindows] : [];
    let bgWindowIds = Array.isArray(data.bgWindowIds) ? [...data.bgWindowIds] : [];
    const openedAt = data.activeWindowOpenedAt && typeof data.activeWindowOpenedAt === 'object' ? { ...data.activeWindowOpenedAt } : {};
    const targetTabIds = data.targetTabIds && typeof data.targetTabIds === 'object' ? { ...data.targetTabIds } : {};
    let completedCount = Number(data.completedCount || 0);
    let results = Array.isArray(data.results) ? [...data.results] : [];
    let changed = false;

    const clearTabTrack = (tabId) => {
        if (!tabId) return;
        delete targetTabIds[String(tabId)];
        delete openedAt[String(tabId)];
        delete openedAt['tab:' + tabId];
    };

    const markTaskTimeout = async (task, reason) => {
        const account = task && task.account ? { ...task.account } : null;
        const accountName = String(account && account.name || '').trim();
        const retryCount = Number(account && account.__retryCount || 0);
        if (!account || !accountName) return;

        if (retryCount < AUTO_TASK_MAX_RETRIES) {
            account.__retryCount = retryCount + 1;
            queue.unshift(account);
            await appendLog(reason + '_RETRY ' + accountName + ' ' + account.__retryCount + '/' + AUTO_TASK_MAX_RETRIES);
        } else {
            completedCount += 1;
            results = mergeResultRows(results, {
                account: accountName,
                balance: 'Timeout',
                payout: 'Error',
                payoutNumber: null,
                resetPayout: 'Error',
                resetPayoutNumber: null,
                time: new Date().toLocaleTimeString('zh-TW', { hour12: false }),
                exceeded: false,
                queryFailed: true,
                error: reason
            });
            await appendLog(reason + '_FAIL ' + accountName + ' timeout');
        }
    };

    const timedOutTaskIds = [];
    for (const [taskId, task] of Object.entries(activeTasks)) {
        const claimedAt = Number(task && task.startedAt || 0);
        const assignedAt = Number(task && task.assignedAt || 0);
        const startedAt = claimedAt || assignedAt;
        const timeoutMs = claimedAt ? AUTO_TASK_TIMEOUT_MS : AUTO_ORPHAN_WINDOW_TIMEOUT_MS;
        if (!startedAt || nowMs - startedAt < timeoutMs) continue;

        if (useTabRunner) {
            timedOutTaskIds.push(taskId);
            continue;
        }

        delete activeTasks[taskId];
        if (task && task.tabId) clearTabTrack(task.tabId);
        if (task && task.windowId) {
            activeWindows = activeWindows.filter(id => id !== task.windowId);
            delete openedAt[String(task.windowId)];
            closeWindowQuiet(task.windowId);
        }
        await markTaskTimeout(task, 'WATCHDOG');
        changed = true;
    }

    if (useTabRunner) {
        const taskTabIds = new Set(Object.values(activeTasks).map(task => String(task && task.tabId || '')).filter(Boolean));
        const staleOrphanTabs = Object.keys(targetTabIds).filter((tabIdRaw) => {
            if (taskTabIds.has(tabIdRaw)) return false;
            const ts = Number(openedAt['tab:' + tabIdRaw] || openedAt[tabIdRaw] || 0);
            return !!ts && nowMs - ts >= AUTO_ORPHAN_WINDOW_TIMEOUT_MS;
        });

        if (timedOutTaskIds.length > 0 || staleOrphanTabs.length > 0) {
            const restartWindowIds = new Set();
            if (data.bgWindowId) restartWindowIds.add(data.bgWindowId);
            if (backgroundWindowId) restartWindowIds.add(backgroundWindowId);
            activeWindows.forEach(id => restartWindowIds.add(id));
            bgWindowIds.forEach(id => restartWindowIds.add(id));

            for (const [taskId, task] of Object.entries(activeTasks)) {
                if (task && task.tabId) clearTabTrack(task.tabId);
                delete activeTasks[taskId];
                if (timedOutTaskIds.includes(taskId)) {
                    await markTaskTimeout(task, 'WINDOW_STUCK');
                } else {
                    const account = task && task.account ? { ...task.account } : null;
                    const accountName = String(account && account.name || '').trim();
                    if (accountName) {
                        queue.unshift(account);
                        await appendLog('WINDOW_RESTART_REQUEUE ' + accountName);
                    }
                }
            }

            Object.keys(targetTabIds).forEach((tabIdRaw) => {
                delete targetTabIds[tabIdRaw];
                delete openedAt[tabIdRaw];
                delete openedAt['tab:' + tabIdRaw];
            });
            activeWindows = [];
            bgWindowIds = [];
            backgroundWindowId = null;

            await storageSet({
                autoQueue: queue,
                activeTasks,
                activeAutoWindows: [],
                activeWindowOpenedAt: {},
                targetTabIds: {},
                targetTabId: null,
                bgWindowId: null,
                bgWindowIds: [],
                completedCount,
                currentIndex: completedCount,
                results,
                watchdogAt: nowMs,
                parallelRunnerMode: 'tabs'
            });
            restartWindowIds.forEach(id => closeWindowQuiet(id));
            await appendLog('WATCHDOG_RESTART_WINDOW tasks=' + timedOutTaskIds.length + ' orphanTabs=' + staleOrphanTabs.length);
            setTimeout(() => pumpParallelWindows(), 800);
            setTimeout(() => finishIfDone(), 1200);
            return;
        }
    } else {
        const taskWindowIds = new Set(Object.values(activeTasks).map(task => task && task.windowId).filter(Boolean));
        for (const windowId of [...activeWindows]) {
            if (taskWindowIds.has(windowId)) continue;
            const ts = Number(openedAt[String(windowId)] || 0);
            if (!ts || nowMs - ts < AUTO_ORPHAN_WINDOW_TIMEOUT_MS) continue;
            activeWindows = activeWindows.filter(id => id !== windowId);
            delete openedAt[String(windowId)];
            closeWindowQuiet(windowId);
            await appendLog('WATCHDOG_CLOSE_ORPHAN_WINDOW ' + windowId);
            changed = true;
        }
    }

    if (changed) {
        await storageSet({
            autoQueue: queue,
            activeTasks,
            activeAutoWindows: activeWindows,
            activeWindowOpenedAt: openedAt,
            targetTabIds,
            completedCount,
            currentIndex: completedCount + Object.keys(activeTasks).length,
            results,
            watchdogAt: nowMs
        });
        await pumpParallelWindows();
        await finishIfDone();
    }
};
const finishIfDone = async () => {
    await maybeQueuePoolForceDisables();
    const data = await storageGet(['isRunning', 'parallelAuto', 'autoQueue', 'activeAutoWindows', 'targetTabIds', 'activeTasks', 'intervalMin', 'isWaiting', 'parallelRunnerMode']);
    if (!data.isRunning || !data.parallelAuto) return;
    const queue = Array.isArray(data.autoQueue) ? data.autoQueue : [];
    const activeWindows = Array.isArray(data.activeAutoWindows) ? data.activeAutoWindows : [];
    const targetTabIds = data.targetTabIds && typeof data.targetTabIds === 'object' ? data.targetTabIds : {};
    const activeWorkerCount = data.parallelRunnerMode !== 'windows'
        ? Object.keys(targetTabIds).filter(id => targetTabIds[id]).length
        : activeWindows.length;
    const activeTasks = data.activeTasks && typeof data.activeTasks === 'object' ? data.activeTasks : {};
    if (queue.length === 0 && activeWorkerCount === 0 && Object.keys(activeTasks).length === 0) {
        await closeAutoWindows();
        if (data.intervalMin > 0 && !data.isWaiting) {
            await appendLog('WAIT_' + data.intervalMin);
            await storageSet({ isWaiting: true });
            chrome.alarms.clear(AUTO_WATCHDOG_ALARM);
            chrome.alarms.create('BEC_INTERVAL', { delayInMinutes: data.intervalMin });
        } else if (!data.intervalMin && !data.isWaiting) {
            await storageSet({ isRunning: false, isWaiting: false, parallelAuto: false, parallelRunnerMode: 'tabs' });
            chrome.alarms.clear(AUTO_WATCHDOG_ALARM);
            await appendLog('FINISH');
        }
    }
};

const closeSenderWorker = async (sender) => {
    const tabId = sender && sender.tab && sender.tab.id;
    const winId = sender && sender.tab && sender.tab.windowId;
    const data = await storageGet(['parallelRunnerMode', 'targetTabIds', 'activeWindowOpenedAt']);
    const targetTabIds = data.targetTabIds && typeof data.targetTabIds === 'object' ? { ...data.targetTabIds } : {};
    const openedAt = data.activeWindowOpenedAt && typeof data.activeWindowOpenedAt === 'object' ? { ...data.activeWindowOpenedAt } : {};
    if (tabId) {
        delete targetTabIds[String(tabId)];
        delete openedAt[String(tabId)];
        delete openedAt['tab:' + tabId];
    }
    await storageSet({ targetTabIds, activeWindowOpenedAt: openedAt });
    if (data.parallelRunnerMode !== 'windows') {
        if (tabId) setTimeout(() => closeTabQuiet(tabId), 250);
    } else if (winId) {
        setTimeout(() => closeWindowQuiet(winId), 250);
    }
};

const claimTask = async (sender, sendResponse) => {
    const tabId = sender && sender.tab && sender.tab.id;
    const data = await storageGet(['isRunning', 'activeTasks', 'targetTabIds', 'autoConfig', 'startUrl']);
    if (!data.isRunning) {
        sendResponse({ success: false, done: true });
        await closeSenderWorker(sender);
        return;
    }

    const activeTasks = data.activeTasks && typeof data.activeTasks === 'object' ? { ...data.activeTasks } : {};
    const assignedEntry = Object.entries(activeTasks).find(([, task]) => String(task && task.tabId || '') === String(tabId));
    if (!assignedEntry) {
        sendResponse({ success: false, done: true, error: 'NO_ASSIGNED_TASK' });
        await appendLog('NO_ASSIGNED_TASK tab=' + (tabId || 'unknown'));
        await closeSenderWorker(sender);
        setTimeout(() => pumpParallelWindows(), 500);
        return;
    }

    const [taskId, task] = assignedEntry;
    if (!task || !task.account || !task.account.name) {
        delete activeTasks[taskId];
        await storageSet({ activeTasks });
        sendResponse({ success: false, done: true, error: 'BAD_ASSIGNED_TASK' });
        await closeSenderWorker(sender);
        setTimeout(() => pumpParallelWindows(), 500);
        return;
    }

    activeTasks[taskId] = {
        ...task,
        startedAt: Date.now()
    };
    await storageSet({ activeTasks });
    sendResponse({ success: true, taskId, account: task.account, startUrl: data.startUrl || TARGET_URL, autoConfig: data.autoConfig || {} });
};

const taskDone = async (message, sender, sendResponse) => {
    const data = await storageGet(['activeTasks', 'completedCount', 'activeAutoWindows', 'targetTabIds', 'activeWindowOpenedAt', 'parallelRunnerMode']);
    const activeTasks = data.activeTasks && typeof data.activeTasks === 'object' ? { ...data.activeTasks } : {};
    const hadTask = !!(message.taskId && activeTasks[message.taskId]);
    if (hadTask) delete activeTasks[message.taskId];
    const completedCount = Number(data.completedCount || 0) + (hadTask ? 1 : 0);
    const tabId = sender && sender.tab && sender.tab.id;
    const windowId = sender && sender.tab && sender.tab.windowId;
    const targetTabIds = data.targetTabIds && typeof data.targetTabIds === 'object' ? { ...data.targetTabIds } : {};
    const openedAt = data.activeWindowOpenedAt && typeof data.activeWindowOpenedAt === 'object' ? { ...data.activeWindowOpenedAt } : {};
    if (tabId) {
        delete targetTabIds[String(tabId)];
        delete openedAt[String(tabId)];
        delete openedAt['tab:' + tabId];
    }
    await storageSet({ activeTasks, completedCount, currentIndex: completedCount, targetTabIds, activeWindowOpenedAt: openedAt });
    if (!hadTask) await appendLog('TASK_DONE_IGNORED ' + (message.account || message.taskId || 'unknown'));
    sendResponse({ success: true, ignored: !hadTask });
    setTimeout(async () => {
        await pumpParallelWindows();
        if (data.parallelRunnerMode !== 'windows') {
            if (tabId) closeTabQuiet(tabId);
        } else if (windowId) {
            closeWindowQuiet(windowId);
        }
        await finishIfDone();
    }, 300);
};
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'CREATE_PARALLEL_WINDOWS') {
        sendResponse({ success: true });
        (async () => {
            chrome.alarms.clear('BEC_INTERVAL');
            chrome.alarms.clear(AUTO_WATCHDOG_ALARM);
            await closeAutoWindows();
            chrome.alarms.create(AUTO_WATCHDOG_ALARM, { periodInMinutes: 1 });
            await storageSet({ parallelAuto: true, parallelRunnerMode: 'tabs', parallelWindowMode: message.mode === 'fixed' ? 'fixed' : 'auto', maxParallelWindows: Math.max(1, Math.min(4, Number(message.maxLimit || message.limit || 4))) });
            const pumped = await pumpParallelWindows();
            if (pumped && pumped.success === false) await appendLog('PARALLEL_START_FAILED ' + (pumped.error || ''));
        })().catch(err => appendLog('PARALLEL_START_ERR ' + (err && err.message || String(err))));
        return false;
    }

    if (message.action === 'CLAIM_AUTO_TASK') {
        claimTask(sender, sendResponse).catch(err => sendResponse({ success: false, error: err && err.message || String(err) }));
        return true;
    }

    if (message.action === 'AUTO_TASK_DONE') {
        taskDone(message, sender, sendResponse).catch(err => sendResponse({ success: false, error: err && err.message || String(err) }));
        return true;
    }

    if (message.action === 'CREATE_BACKGROUND_WINDOW') {
        (async () => {
            chrome.alarms.clear('BEC_INTERVAL');
            await closeAutoWindows();
            await storageSet({ parallelAuto: false, parallelRunnerMode: 'tabs' });
            const opened = await openAutoWindow(message.url || TARGET_URL, message.incognito !== false);
            sendResponse(opened);
        })().catch(err => sendResponse({ success: false, error: err && err.message || String(err) }));
        return true;
    }

    if (message.action === 'CLOSE_BACKGROUND_WINDOW') {
        (async () => {
            chrome.alarms.clear('BEC_INTERVAL');
            chrome.alarms.clear(AUTO_WATCHDOG_ALARM);
            await storageSet({ isRunning: false, isWaiting: false, parallelAuto: false, parallelRunnerMode: 'tabs' });
            await closeAutoWindows();
            sendResponse({ success: true });
        })().catch(err => sendResponse({ success: false, error: err && err.message || String(err) }));
        return true;
    }

    if (message.action === 'DEBUG_LOG') {
        appendLog(message.text || '');
        return false;
    }

    if (message.action === 'STOP_TTS') {
        if (chrome.tts) chrome.tts.stop();
        return false;
    }

    if (message.action === 'SHOW_ALERT') {
        if (chrome.tts) {
            chrome.tts.speak(message.message, { lang: 'zh-TW', rate: 1.0, volume: 1.0, enqueue: true });
        }
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (tabs.length > 0 && tabs[0].url && tabs[0].url.startsWith('http')) {
                chrome.scripting.executeScript({
                    target: { tabId: tabs[0].id },
                    func: (msg, accName) => {
                        const divId = 'bec-alert-' + accName;
                        if (document.getElementById(divId)) return;
                        const div = document.createElement('div');
                        div.id = divId;
                        div.style.position = 'fixed';
                        div.style.top = '6px';
                        div.style.right = '320px';
                        div.style.backgroundColor = '#ff4d4f';
                        div.style.color = '#fff';
                        div.style.padding = '6px 14px';
                        div.style.fontSize = '14px';
                        div.style.fontWeight = 'bold';
                        div.style.fontFamily = 'sans-serif';
                        div.style.borderRadius = '4px';
                        div.style.boxShadow = '0 2px 10px rgba(0,0,0,0.5)';
                        div.style.zIndex = '2147483647';
                        div.style.display = 'flex';
                        div.style.alignItems = 'center';
                        div.style.gap = '12px';
                        div.innerHTML = '<span>警告 ' + msg + '</span><button class="bec-alert-close-btn" style="background:#fff; color:#ff4d4f; border:none; padding:4px 10px; border-radius:4px; cursor:pointer; font-weight:bold; font-size:12px; outline:none;">已確認</button>';
                        div.querySelector('.bec-alert-close-btn').addEventListener('click', () => {
                            div.remove();
                            chrome.runtime.sendMessage({ action: 'STOP_TTS' });
                        });
                        document.body.appendChild(div);
                    },
                    args: [message.message, message.account]
                }).catch(() => {});
            }
        });
        chrome.notifications.create({
            type: 'basic',
            title: message.title || 'BEC LITE',
            message: message.message || '',
            priority: 2,
            requireInteraction: true,
            iconUrl: chrome.runtime.getURL('icon128.png')
        }, () => { if (chrome.runtime.lastError) console.warn('Notification failed:', chrome.runtime.lastError.message); });
        return false;
    }

    if (message.action === 'START_INTERVAL') {
        chrome.alarms.create('BEC_INTERVAL', { delayInMinutes: message.minutes });
        chrome.alarms.clear(AUTO_WATCHDOG_ALARM);
        closeAutoWindows();
        sendResponse({ success: true });
        return true;
    }
});

chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === AUTO_WATCHDOG_ALARM) {
        runAutoWatchdog().catch(err => appendLog('WATCHDOG_ERR ' + (err && err.message || String(err))));
        return;
    }
    if (alarm.name !== 'BEC_INTERVAL') return;
    chrome.storage.local.get(['isRunning', 'accounts'], async (data) => {
        if (!data.isRunning) return;
        await appendLog('啟動背景查詢');
        chrome.alarms.create(AUTO_WATCHDOG_ALARM, { periodInMinutes: 1 });
        await storageSet({
            autoQueue: Array.isArray(data.accounts) ? data.accounts : [],
            activeTasks: {},
            activeAutoWindows: [],
            activeWindowOpenedAt: {},
            targetTabIds: {},
            parallelRunnerMode: 'tabs',
            completedCount: 0,
            currentIndex: 0,
            step: 'SEARCH',
            isWaiting: false,
            startUrl: TARGET_URL,
            poolStatus: {},
            currentPeriodKey: '',
            forceDisableQueue: [],
            poolForceMembers: {}
        });
        await pumpParallelWindows();
    });
});
chrome.windows.onRemoved.addListener((windowId) => {
    (async () => {
        const data = await storageGet(['activeAutoWindows', 'bgWindowIds', 'bgWindowId', 'targetTabIds', 'activeWindowOpenedAt', 'isWaiting', 'isRunning', 'parallelAuto', 'parallelRunnerMode', 'activeTasks', 'autoQueue', 'completedCount']);
        const activeAutoWindows = (Array.isArray(data.activeAutoWindows) ? data.activeAutoWindows : []).filter(id => id !== windowId);
        const bgWindowIds = (Array.isArray(data.bgWindowIds) ? data.bgWindowIds : []).filter(id => id !== windowId);
        const activeWindowOpenedAt = data.activeWindowOpenedAt && typeof data.activeWindowOpenedAt === 'object' ? { ...data.activeWindowOpenedAt } : {};
        delete activeWindowOpenedAt[String(windowId)];
        const patch = { activeAutoWindows, bgWindowIds, activeWindowOpenedAt };
        const isRunnerWindow = data.bgWindowId === windowId || backgroundWindowId === windowId;
        if (isRunnerWindow) {
            backgroundWindowId = null;
            patch.bgWindowId = bgWindowIds[0] || null;
            if (data.parallelRunnerMode !== 'windows') {
                patch.targetTabIds = {};
                patch.activeWindowOpenedAt = {};
                if (data.parallelAuto && data.isRunning !== false) {
                    const activeTasks = data.activeTasks && typeof data.activeTasks === 'object' ? { ...data.activeTasks } : {};
                    const queue = Array.isArray(data.autoQueue) ? [...data.autoQueue] : [];
                    let requeued = 0;
                    Object.entries(activeTasks).forEach(([, task]) => {
                        const account = task && task.account ? { ...task.account } : null;
                        const accountName = String(account && account.name || '').trim();
                        if (accountName) {
                            queue.unshift(account);
                            requeued += 1;
                        }
                    });
                    patch.autoQueue = queue;
                    patch.activeTasks = {};
                    patch.currentIndex = Number(data.completedCount || 0);
                    if (requeued > 0) await appendLog('RUNNER_WINDOW_CLOSED_REQUEUE ' + requeued);
                }
            }
        }
        await storageSet(patch);
        if (data.parallelAuto && data.isRunning !== false) {
            await pumpParallelWindows();
            await finishIfDone();
        } else if (isRunnerWindow && !data.isWaiting) {
            await storageSet({ isRunning: false, isWaiting: false, parallelAuto: false, parallelRunnerMode: 'tabs' });
            chrome.alarms.clear('BEC_INTERVAL');
        }
    })();
});

chrome.tabs.onRemoved.addListener((tabId) => {
    (async () => {
        const data = await storageGet(['isRunning', 'parallelAuto', 'parallelRunnerMode', 'targetTabIds', 'activeWindowOpenedAt', 'activeTasks', 'autoQueue', 'completedCount', 'results']);
        if (!data.parallelAuto || data.parallelRunnerMode === 'windows') return;
        const targetTabIds = data.targetTabIds && typeof data.targetTabIds === 'object' ? { ...data.targetTabIds } : {};
        const openedAt = data.activeWindowOpenedAt && typeof data.activeWindowOpenedAt === 'object' ? { ...data.activeWindowOpenedAt } : {};
        const activeTasks = data.activeTasks && typeof data.activeTasks === 'object' ? { ...data.activeTasks } : {};
        const queue = Array.isArray(data.autoQueue) ? [...data.autoQueue] : [];
        let completedCount = Number(data.completedCount || 0);
        let results = Array.isArray(data.results) ? [...data.results] : [];
        let changed = false;

        if (targetTabIds[String(tabId)]) {
            delete targetTabIds[String(tabId)];
            changed = true;
        }
        delete openedAt[String(tabId)];
        delete openedAt['tab:' + tabId];

        const taskEntry = Object.entries(activeTasks).find(([, task]) => String(task && task.tabId || '') === String(tabId));
        if (taskEntry) {
            const [taskId, task] = taskEntry;
            delete activeTasks[taskId];
            const account = task && task.account ? { ...task.account } : null;
            const accountName = String(account && account.name || '').trim();
            const retryCount = Number(account && account.__retryCount || 0);
            if (account && retryCount < AUTO_TASK_MAX_RETRIES) {
                account.__retryCount = retryCount + 1;
                queue.unshift(account);
                await appendLog('TAB_CLOSED_RETRY ' + accountName + ' ' + account.__retryCount + '/' + AUTO_TASK_MAX_RETRIES);
            } else if (account) {
                completedCount += 1;
                results = mergeResultRows(results, {
                    account: accountName,
                    balance: 'Closed',
                    payout: 'Error',
                    payoutNumber: null,
                    resetPayout: 'Error',
                    resetPayoutNumber: null,
                    time: new Date().toLocaleTimeString('zh-TW', { hour12: false }),
                    exceeded: false,
                    queryFailed: true,
                    error: 'TAB_CLOSED'
                });
                await appendLog('TAB_CLOSED_FAIL ' + accountName);
            }
            changed = true;
        }

        if (changed) {
            await storageSet({
                autoQueue: queue,
                activeTasks,
                activeWindowOpenedAt: openedAt,
                targetTabIds,
                completedCount,
                currentIndex: completedCount + Object.keys(activeTasks).length,
                results
            });
            if (data.isRunning !== false) await pumpParallelWindows();
            await finishIfDone();
        }
    })();
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
    if (changeInfo.status !== 'complete') return;
    chrome.storage.local.get(['isRunning', 'targetTabId', 'targetTabIds'], (data) => {
        const targetTabIds = data.targetTabIds && typeof data.targetTabIds === 'object' ? data.targetTabIds : {};
        if (!data.isRunning || (data.targetTabId !== tabId && !targetTabIds[String(tabId)])) return;
        chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] }).catch(() => {});
    });
});