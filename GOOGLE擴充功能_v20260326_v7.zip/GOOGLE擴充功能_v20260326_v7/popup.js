
document.addEventListener('DOMContentLoaded', () => {

    const $ = (sel, ctx = document) => ctx.querySelector(sel);
    const $$ = (sel, ctx = document) => [...ctx.querySelectorAll(sel)];

    const todayStr = () => {
        const d = new Date();
        return `${d.getFullYear()}/${String(d.getMonth() + 1).padStart(2, '0')}/${String(d.getDate()).padStart(2, '0')}`;
    };

    function showToast(msg = '已複製到剪貼簿') {
        const t = $('#toast');
        t.textContent = msg;
        t.classList.add('show');
        setTimeout(() => t.classList.remove('show'), 1500);
    }

    async function copyText(text) {
        if (!text || text === '無資料') return;
        await navigator.clipboard.writeText(text.trim());
        showToast();
    }

    // ─── Tab 切換 ───
    function switchTab(targetId) {
        $$('.nav-btn').forEach(b => b.classList.remove('active'));
        $$('.tab-pane').forEach(p => p.classList.remove('active'));
        const btn = $(`.nav-btn[data-target="${targetId}"]`);
        const pane = $(`#${targetId}`);
        if (btn) btn.classList.add('active');
        if (pane) pane.classList.add('active');
        return pane;
    }

    $('.nav-container').addEventListener('click', (e) => {
        const btn = e.target.closest('.nav-btn');
        if (btn) switchTab(btn.dataset.target);
    });

    const fieldVal = (pane, field) => $(`input[data-field="${field}"]`, pane)?.value || '';

    // ─── 複製 ───
    $('.content').addEventListener('click', (e) => {
        const btn = e.target.closest('.js-copy');
        if (!btn) return;

        const pane = btn.closest('.tab-pane');
        const key = btn.dataset.copy;
        let text = '';

        switch (key) {
            case 'deposit-format': {
                let method = fieldVal(pane, 'method');
                if (!method || method === '無資料') method = '入款';
                text = [todayStr(), method, fieldVal(pane, 'no'), fieldVal(pane, 'acc'), fieldVal(pane, 'amt')].join('\t');
                break;
            }
            case 'usdt-deposit-format': {
                text = [todayStr(), '入款', fieldVal(pane, 'no'), fieldVal(pane, 'acc'), fieldVal(pane, 'amt')].join('\t');
                break;
            }
            case 'withdraw-format': {
                text = [todayStr(), '出款', fieldVal(pane, 'no'), fieldVal(pane, 'acc'), '', fieldVal(pane, 'amt')].join('\t');
                break;
            }
            case 'fuding-template': {
                const v = (f) => fieldVal(pane, f);
                text = [
                    '【代付確認提單】',
                    `交易編號 ${v('no')}`,
                    `銀行名稱 ${v('bankName')}`,
                    `銀行代碼 ( ${v('bankCode')} )`,
                    `銀行帳號 ${v('acc')}`,
                    `分行 ${v('branch')}`,
                    `金額 ${v('amt')}`
                ].join('\n');
                break;
            }
            case 'time': {
                text = fieldVal(pane, 'time');
                break;
            }
            default: {
                text = key.split(',').map(f => fieldVal(pane, f)).join('\t');
            }
        }
        copyText(text);
    });

    // ─── 手動重新讀取 ───
    $('.content').addEventListener('click', async (e) => {
        const btn = e.target.closest('.js-fetch');
        if (!btn) return;
        const pane = btn.closest('.tab-pane');
        await fetchAndFill(pane);
    });

    // ════════════════════════════════════════
    //  fetchAndFill
    // ════════════════════════════════════════

    async function fetchAndFill(pane) {
        const { type, usdt } = pane.dataset;
        const isUsdt = usdt === 'true';
        const pill = $('.js-status', pane);

        pill.textContent = 'SCANNING';
        pill.className = 'pill js-status scanning';

        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            const results = await chrome.scripting.executeScript({
                target: { tabId: tab.id, allFrames: true },
                func: grabPageData,
                args: [type, isUsdt]
            });

            const data = {};
            for (const { result } of results) {
                if (!result) continue;
                for (const [k, v] of Object.entries(result)) {
                    if (v && !data[k]) data[k] = v;
                }
            }

            if (type === 'fuding' && data.amt) {
                data.amt = Number(data.amt).toLocaleString();
            }

            $$('input[data-field]', pane).forEach(input => {
                input.value = data[input.dataset.field] || '無資料';
            });

            const ok = !!data.no;
            pill.textContent = ok ? 'ONLINE' : 'NO DATA';
            pill.className = 'pill js-status ' + (ok ? 'online' : 'error');

            return data;
        } catch (err) {
            console.error('[BEC] Fetch error:', err);
            pill.textContent = 'ERROR';
            pill.className = 'pill js-status error';
            return null;
        }
    }

    // ════════════════════════════════════════
    //  autoDetect — 開啟即偵測
    // ════════════════════════════════════════

    async function autoDetect() {
        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

            const probeResults = await chrome.scripting.executeScript({
                target: { tabId: tab.id, allFrames: true },
                func: probePageType
            });

            let orderNo = '';
            let bankRaw = '';
            for (const { result } of probeResults) {
                if (!result) continue;
                if (result.orderNo && !orderNo) orderNo = result.orderNo;
                if (result.bankRaw && !bankRaw) bankRaw = result.bankRaw;
            }

            const prefix = orderNo.charAt(0).toUpperCase();
            const bankUpper = bankRaw.toUpperCase();

            let targetTab = 'tab-deposit';

            if (prefix === 'D') {
                if (bankUpper.includes('USDT') || bankUpper.includes('TRC')) {
                    targetTab = 'tab-usdt-deposit';
                } else {
                    targetTab = 'tab-deposit';
                }
            } else if (prefix === 'W') {
                if (bankUpper.includes('USDT') || bankUpper.includes('TRC')) {
                    targetTab = 'tab-usdt-withdraw';
                } else {
                    targetTab = 'tab-withdraw';
                }
            }

            const pane = switchTab(targetTab);
            if (pane) await fetchAndFill(pane);

        } catch (err) {
            console.error('[BEC] Auto-detect error:', err);
        }
    }

    // ════════════════════════════════════════════════════════════
    //  probePageType — 偵測腳本（注入頁面）
    // ════════════════════════════════════════════════════════════

    function probePageType() {
        const tds = Array.from(document.querySelectorAll('td'));
        let orderNo = '';
        let bankRaw = '';

        const orderLabels = ['存款單號', '提款單號', '單號'];
        const bankLabels = ['銀行', '收款銀行', '收款方式', '付款方式', '支付方式', '存款方式', '通道名稱'];

        for (const td of tds) {
            const txt = td.innerText.replace(/\s+/g, '');
            if (txt.length > 20) continue; 

            // 找單號
            if (!orderNo) {
                for (const l of orderLabels) {
                    if (txt.includes(l)) {
                        const next = td.nextElementSibling;
                        if (next?.tagName === 'TD') {
                            const val = next.innerText.trim();
                            if (val) { orderNo = val; break; }
                        }
                    }
                }
            }

            // 找收款銀行
            if (!bankRaw) {
                // 【核心修正】嚴格排除「銀行卡」與「匯款銀行」，避免抓到客戶個人銀行資訊
                if (txt.includes('銀行卡') || txt.includes('匯款銀行')) {
                    continue; 
                }
                
                for (const l of bankLabels) {
                    if (txt.includes(l)) {
                        const next = td.nextElementSibling;
                        if (next?.tagName === 'TD') {
                            const val = next.innerText.trim();
                            if (val) { bankRaw = val; break; }
                        }
                    }
                }
            }

            if (orderNo && bankRaw) break;
        }

        return { orderNo, bankRaw };
    }

    // ════════════════════════════════════════════════════════════
    //  grabPageData — 完整抓取腳本（注入頁面）
    // ════════════════════════════════════════════════════════════

    function grabPageData(type, isUsdt) {
        const tds = Array.from(document.querySelectorAll('td'));

        const getVal = (labels, isAmount = false) => {
            for (const td of tds) {
                const txt = td.innerText.replace(/\s+/g, '');
                if (txt.length > 20) continue;

                // 【核心修正】防止 getVal 抓到會員個人銀行卡資訊
                if ((txt.includes('銀行卡') || txt.includes('匯款銀行')) && 
                    !labels.some(l => l.includes('銀行卡') || l.includes('匯款銀行'))) {
                    continue;
                }

                const matched = labels.some(l => txt.includes(l));
                if (!matched) continue;

                const next = td.nextElementSibling;
                if (!next || next.tagName !== 'TD') continue;
                const raw = next.innerText.trim();

                if (!raw) continue;

                if (!isAmount) return raw;

                if (isUsdt) {
                    const m = raw.match(/([\d,.]+)[^\d]*USDT/i);
                    if (m) return m[1].replace(/,/g, '');
                    continue;
                }

                if (raw.toUpperCase().includes('USDT')) {
                    if (type === 'withdraw' || type === 'fuding') continue;
                }
                const numMatch = raw.match(/[\d,.]+/);
                return numMatch ? numMatch[0].replace(/,/g, '') : raw;
            }
            return '';
        };

        // ─── 收款方式偵測 ───
        function detectMethod() {
            const methodRules = [
                [['支付寶', 'ALIPAY'],                  '支付寶'],
                [['微信', 'WECHAT', 'WXPAY'],           '微信'],
                [['超商', '便利商店', 'CVS', 'IBON'],   '超商'],
                [['銀聯', 'UNIONPAY', 'CUP'],           '銀聯'],
                [['LINEPAY', 'LINE PAY'],               'LinePay'],
                [['JKOPAY', '街口'],                    '街口支付'],
                [['USDT', 'TRC', 'ERC', '虛擬貨幣'],    'USDT'],
                [['網銀', '銀行轉帳'],                   '網銀'],
                [['ATM'],                               'ATM'],
            ];

            function matchMethod(text) {
                const upper = text.toUpperCase();
                for (const [keywords, label] of methodRules) {
                    if (keywords.some(kw => upper.includes(kw.toUpperCase()))) return label;
                }
                return '';
            }

            const bankLabels = ['銀行', '收款銀行', '收款方式', '付款方式', '支付方式', '存款方式', '通道名稱'];
            for (const td of tds) {
                const txt = td.innerText.replace(/\s+/g, '');
                if (txt.length > 10) continue; 
                
                // 【核心修正】避開會員資料的銀行卡
                if (txt.includes('銀行卡') || txt.includes('匯款銀行')) continue;

                const hit = bankLabels.some(l => txt.includes(l));
                if (!hit) continue;
                const next = td.nextElementSibling;
                if (!next || next.tagName !== 'TD') continue;
                const val = next.innerText.trim();
                if (!val) continue; 
                const m = matchMethod(val);
                if (m) return m;
                return val; 
            }

            const allText = tds.map(td => td.innerText).join(' ');
            return matchMethod(allText);
        }

        const FIELD_MAP = {
            deposit: {
                no:     ['存款單號', '單號'],
                acc:    ['會員帳號', '帳號'],
                amt:    [['金額', '實際金額'], true],
                method: () => detectMethod(),
                time:   () => getVal(['存款時間']) || getVal(['申請日期']) || getVal(['時間'])
            },
            withdraw: {
                no:  ['提款單號', '單號'],
                acc: ['會員帳號', '帳號'],
                amt: [['金額', '實際金額', '實際提領金額'], true]
            },
            fuding: {
                no:     ['提款單號', '單號'],
                acc:    ['帳號'],
                amt:    [['金額', '實際金額', '實際提領金額'], true],
                branch: ['分行'],
                _bank:  ['銀行']
            }
        };

        const cfg = FIELD_MAP[type];
        if (!cfg) return null;

        const result = {};
        for (const [key, def] of Object.entries(cfg)) {
            if (key.startsWith('_')) continue;
            if (typeof def === 'function') {
                result[key] = def();
            } else if (Array.isArray(def) && def[1] === true) {
                result[key] = getVal(def[0], true);
            } else {
                result[key] = getVal(def);
            }
        }

        if (type === 'fuding') {
            const rawBank = getVal(cfg._bank);
            const m = rawBank.match(/\(\s*(\d+)\s*\)\s*(.*)/);
            result.bankCode = m ? m[1] : '';
            result.bankName = m ? m[2].trim() : rawBank;
        }

        return result;
    }

    // ══ 啟動 ══
    autoDetect();
});