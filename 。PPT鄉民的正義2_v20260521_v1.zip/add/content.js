(async function() {
    if (window.hasRun) return;
    window.hasRun = true;

    const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

    const waitFor = async (findFn, timeout = 12000) => {
        const start = Date.now();
        let stateObj = await chrome.storage.local.get(['adaptiveDelay']);
        let currentDelay = stateObj.adaptiveDelay || 800;

        while (Date.now() - start < timeout) {
            const el = findFn();
            if (el) {
                const elapsed = Date.now() - start;
                let newDelay = Math.floor(currentDelay * 0.7 + Math.min(elapsed, 2500) * 0.3);
                newDelay = Math.max(300, Math.min(2500, newDelay));
                
                if (Math.abs(newDelay - currentDelay) > 50) {
                    chrome.storage.local.set({ adaptiveDelay: newDelay });
                }
                return el;
            }
            await sleep(200);
        }
        return null;
    };

    const triggerNativeEvent = (el, type) => {
        el.dispatchEvent(new Event(type, { bubbles: true, cancelable: true }));
    };

    const now = () => new Date().toLocaleTimeString('zh-TW', { hour12: false });

    const log = (text) => {
        chrome.runtime.sendMessage({ action: 'DEBUG_LOG', text }).catch(() => {});
    };


    const updateResult = (resArr, acc, bal, pay, isExceeded = false, meta = {}) => {
        const idx = resArr.findIndex(r => r.account === acc);
        const t = now();
        const patch = {
            balance: bal,
            payout: pay,
            time: t,
            exceeded: isExceeded,
            ...meta
        };
        if (idx !== -1) {
            resArr[idx] = { ...resArr[idx], ...patch };
        } else {
            resArr.push({ id: resArr.length + 1, account: acc, ...patch });
        }
        return resArr;
    };

    const parseMoney = (raw) => {
        if (raw === null || raw === undefined) return NaN;
        const text = String(raw).trim();
        const n = parseFloat(text.replace(/,/g, '').replace(/[^\d.-]/g, ''));
        if (!Number.isFinite(n)) return NaN;
        if (/輸|亏|虧|負|负/.test(text) && n > 0 && !text.includes('-')) return -n;
        return n;
    };
    const getLimitHit = (value, winLimitRaw, lossLimitRaw) => {
        const amount = Number(value);
        if (!Number.isFinite(amount) || amount === 0) return { hit: false, direction: '', limit: null, amount };
        const winLimit = Number(winLimitRaw);
        const lossLimit = Number(lossLimitRaw);
        if (amount > 0 && Number.isFinite(winLimit) && winLimit > 0 && amount >= winLimit) {
            return { hit: true, direction: '贏', limit: winLimit, amount };
        }
        if (amount < 0 && Number.isFinite(lossLimit) && lossLimit > 0 && Math.abs(amount) >= lossLimit) {
            return { hit: true, direction: '輸', limit: lossLimit, amount };
        }
        return { hit: false, direction: '', limit: null, amount };
    };

    const limitHitText = (hit) => hit && hit.hit ? String(hit.direction || '') + '達上限 ' + Number(hit.limit).toLocaleString() : '達上限';

    const cleanText = (el) => String(el?.innerText || el?.textContent || '').replace(/\s+/g, ' ').trim();

    const isVisible = (el) => {
        if (!el) return false;
        let cur = el;
        while (cur && cur !== document.body) {
            const style = window.getComputedStyle(cur);
            if (style.display === 'none' || style.visibility === 'hidden') return false;
            cur = cur.parentElement;
        }
        const rect = el.getBoundingClientRect();
        return rect.width > 0 && rect.height > 0;
    };

    const looksLikeMoney = (text) => /^-?\s*[\d,]+(?:\.\d+)?$/.test(String(text || '').trim());

    const findPayoutResult = () => {
        const noData = Array.from(document.querySelectorAll('td, div, span')).find(el => isVisible(el) && cleanText(el).includes('查無資料'));
        if (noData) return { type: 'nodata', val: '查無資料' };

        const candidates = [];
        const tables = Array.from(document.querySelectorAll('table')).filter(isVisible);

        tables.forEach((table) => {
            const rows = Array.from(table.querySelectorAll('tr')).filter(isVisible);
            if (!rows.length) return;

            let winLoseIdx = -1;
            rows.forEach((row) => {
                if (winLoseIdx >= 0) return;
                const texts = Array.from(row.querySelectorAll('th,td')).filter(isVisible).map(cleanText);
                winLoseIdx = texts.findIndex(text => text.includes('輸贏'));
            });

            const tableText = cleanText(table);
            const nearBox = table.closest('.panel, .box, .card, .tab-pane, .table-responsive, .content') || table.parentElement;
            const nearText = cleanText(nearBox);
            const baseScore = (nearText.includes('派彩統計') ? 100 : 0) + (tableText.includes('總有效投注') ? 25 : 0) + (tableText.includes('派彩') ? 15 : 0);

            rows.forEach((row) => {
                const rowText = cleanText(row);
                if (!rowText.includes('總計')) return;

                const cells = Array.from(row.querySelectorAll('td,th')).filter(isVisible);
                const cellTexts = cells.map(cleanText);
                let val = '';

                if (winLoseIdx >= 0 && cellTexts[winLoseIdx]) {
                    val = cellTexts[winLoseIdx];
                } else if (cellTexts.length >= 5 && tableText.includes('總有效投注') && tableText.includes('派彩')) {
                    val = cellTexts[4];
                } else {
                    val = cellTexts[cellTexts.length - 1] || '';
                }

                if (looksLikeMoney(val)) {
                    candidates.push({ type: 'data', val, score: baseScore + (winLoseIdx >= 0 ? 30 : 0) });
                }
            });
        });

        candidates.sort((a, b) => b.score - a.score);
        return candidates[0] || null;
    };

    const normalizeDateRangeText = (raw) => String(raw || '').trim().replace('T', ' ');

    const readQueryDateRange = () => {
        const inputs = Array.from(document.querySelectorAll('input')).filter(isVisible);
        const dateInputs = inputs.filter((input) => {
            const key = String((input.name || '') + ' ' + (input.id || '') + ' ' + (input.className || '')).toLowerCase();
            const value = normalizeDateRangeText(input.value);
            return key.includes('date') || /^\d{4}[-/]\d{2}[-/]\d{2}/.test(value);
        });

        const findByKey = (patterns) => dateInputs.find((input) => {
            const key = String((input.name || '') + ' ' + (input.id || '') + ' ' + (input.placeholder || '') + ' ' + (input.className || '')).toLowerCase();
            return patterns.some(pattern => key.includes(pattern));
        });

        const startInput = findByKey(['start', 'from', 'begin']) || dateInputs[0] || null;
        const endInput = findByKey(['end', 'to', 'finish']) || dateInputs.find(input => input !== startInput) || null;
        const start = normalizeDateRangeText(startInput?.value || '');
        const end = normalizeDateRangeText(endInput?.value || '');

        return {
            start,
            end,
            label: start && end ? start + ' ~ ' + end : start ? start + ' ~ 目前' : ''
        };
    };

    const pad2 = (n) => String(n).padStart(2, '0');
    const toDateSlash = (d) => d.getFullYear() + '/' + pad2(d.getMonth() + 1) + '/' + pad2(d.getDate());
    const toDateKey = (d) => d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate());
    const toDateTimeLocal = (d) => toDateKey(d) + ' ' + pad2(d.getHours()) + ':' + pad2(d.getMinutes());
    const toDateTimeSearch = (d) => toDateKey(d) + ' ' + pad2(d.getHours()) + ':' + pad2(d.getMinutes()) + ':00';

    const getCurrentPeriodStart = (resetRule) => {
        const anchorRaw = resetRule?.anchor;
        const anchorDate = anchorRaw ? new Date(anchorRaw) : null;
        const anchor = (anchorDate && !Number.isNaN(anchorDate.getTime())) ? anchorDate : null;
        if (!anchor) return null;

        const repeatWeekly = resetRule?.repeatWeekly !== false;
        if (!repeatWeekly) return anchor;

        const nowDate = new Date();
        const stepMs = 7 * 24 * 60 * 60 * 1000;
        if (nowDate < anchor) return anchor;

        const diffMs = nowDate.getTime() - anchor.getTime();
        const weeks = Math.floor(diffMs / stepMs);
        return new Date(anchor.getTime() + weeks * stepMs);
    };

    const getPeriodKey = (periodStart, repeatWeekly) => {
        if (!periodStart) return 'default';
        return repeatWeekly ? 'W:' + toDateKey(periodStart) : 'F:' + toDateKey(periodStart);
    };

    const normalizePoolId = (raw) => String(raw || '').trim().toUpperCase().replace(/\s+/g, '-');
    const accountKey = (name) => String(name || '').trim().toLowerCase();

    const nextAccount = async (state, results, opts = {}) => {
        const { isForceTask = false } = opts;

        if (state.parallelAuto) {
            const currentAccount = state.currentTaskAccount || (state.accounts && state.accounts[0] && state.accounts[0].name) || '';
            const currentKey = accountKey(currentAccount);
            const currentRow = (Array.isArray(results) ? results : []).slice().reverse().find(row => accountKey(row && row.account) === currentKey);
            const stored = await chrome.storage.local.get(['results']);
            const merged = Array.isArray(stored.results) ? [...stored.results] : [];
            if (currentRow) {
                const idx = merged.findIndex(row => accountKey(row && row.account) === currentKey);
                if (idx >= 0) merged[idx] = { ...merged[idx], ...currentRow };
                else merged.push(currentRow);
            }
            await chrome.storage.local.set({ results: merged, step: 'SEARCH' });
            const donePayload = {
                action: 'AUTO_TASK_DONE',
                taskId: state.currentTaskId || '',
                account: currentAccount
            };
            try {
                sessionStorage.removeItem('BEC_AUTO_TASK');
                sessionStorage.removeItem('BEC_AUTO_STEP');
            } catch (e) {}
            chrome.runtime.sendMessage(donePayload).catch(() => {});
            return;
        }

        const patch = {
            results,
            step: 'SEARCH'
        };

        if (isForceTask) {
            const queueState = await chrome.storage.local.get(['forceDisableQueue']);
            const queue = Array.isArray(queueState.forceDisableQueue) ? [...queueState.forceDisableQueue] : [];
            if (queue.length > 0) queue.shift();
            patch.forceDisableQueue = queue;
        } else {
            patch.currentIndex = state.currentIndex + 1;
        }

        await chrome.storage.local.set(patch);

        const currentUrl = window.location.href.split('?')[0];
        const targetUrl  = state.startUrl.split('?')[0];

        if (currentUrl === targetUrl) {
            window.location.reload(true);
        } else {
            window.location.href = state.startUrl;
        }
    };

    chrome.storage.local.get(null, async (state) => {
        if (state.parallelAuto) {
            let task = null;
            try {
                task = JSON.parse(sessionStorage.getItem('BEC_AUTO_TASK') || 'null');
            } catch (e) {
                task = null;
            }

            if (!task || !task.account || !task.account.name) {
                const claim = await chrome.runtime.sendMessage({ action: 'CLAIM_AUTO_TASK' }).catch(() => null);
                if (!claim || !claim.success || !claim.account) {
                    return;
                }
                task = {
                    taskId: claim.taskId,
                    account: claim.account,
                    startUrl: claim.startUrl,
                    autoConfig: claim.autoConfig
                };
                try {
                    sessionStorage.setItem('BEC_AUTO_TASK', JSON.stringify(task));
                    sessionStorage.setItem('BEC_AUTO_STEP', 'SEARCH');
                } catch (e) {}
            }

            state = {
                ...state,
                currentTaskId: task.taskId,
                currentTaskAccount: task.account.name,
                accounts: [task.account],
                currentIndex: 0,
                step: sessionStorage.getItem('BEC_AUTO_STEP') || 'SEARCH',
                startUrl: task.startUrl || state.startUrl || window.location.origin + '/index/user_info',
                autoConfig: task.autoConfig || state.autoConfig || {},
                forceDisableQueue: []
            };
        }

        const forceDisableQueue = Array.isArray(state.forceDisableQueue) ? state.forceDisableQueue : [];
        const normalDone = state.parallelAuto ? false : state.currentIndex >= (state.accounts?.length || 0);
        const hasForceTask = !state.parallelAuto && forceDisableQueue.length > 0;

        if (!state.isRunning || !state.accounts || (normalDone && !hasForceTask)) {
            if (state.isRunning && normalDone && !hasForceTask) {
                if (state.intervalMin > 0 && !state.isWaiting) {
                    log('WAIT_' + state.intervalMin);
                    await chrome.storage.local.set({ isWaiting: true });
                    chrome.runtime.sendMessage({ action: 'START_INTERVAL', minutes: state.intervalMin }).catch(() => {});
                } else if (!state.intervalMin && !state.isWaiting) {
                    chrome.storage.local.set({ isRunning: false });
                    log('FINISH');
                }
            }
            return;
        }

        const isForceTask = state.parallelAuto ? !!(state.accounts && state.accounts[0] && state.accounts[0].forceDisableOnly) : hasForceTask;
        const accountObj = state.parallelAuto ? state.accounts[0] : (isForceTask ? forceDisableQueue[0] : state.accounts[state.currentIndex]);
        if (!accountObj || !accountObj.name) {
            await nextAccount(state, state.results || [], { isForceTask });
            return;
        }

        const startDisabledAccounts = (state.disabledAccounts && typeof state.disabledAccounts === 'object') ? state.disabledAccounts : {};
        const disabledRecords = Array.isArray(state.disabledRecords) ? state.disabledRecords : [];
        const alreadyDisabled = !!startDisabledAccounts[accountKey(accountObj.name)] || disabledRecords.some(item => accountKey(item && item.account) === accountKey(accountObj.name));
        if (!isForceTask && alreadyDisabled) {
            log('[' + accountObj.name + '] SKIP_ALREADY_DISABLED');
            await nextAccount(state, state.results || [], { isForceTask: false });
            return;
        }

        let results = state.results || [];
        const currentHref = window.location.href;
        const autoConfig = state.autoConfig || {};
        const fallbackAnchor = autoConfig?.resetRule?.anchor || '';
        const effectiveAnchor = accountObj.resetAt || (accountObj.poolId ? fallbackAnchor : '') || '';
        const effectiveRepeatWeekly = accountObj.repeatWeekly !== false;
        const periodStart = effectiveAnchor ? getCurrentPeriodStart({ anchor: effectiveAnchor, repeatWeekly: effectiveRepeatWeekly }) : null;
        const periodKey = getPeriodKey(periodStart, effectiveRepeatWeekly);
        const queryDate = periodStart ? toDateTimeSearch(periodStart) : (accountObj.date || '0');
        
        let adaptiveDly = state.adaptiveDelay || 800;

        log('[' + accountObj.name + '] | ' + state.step + ' | ' + (periodStart ? toDateTimeLocal(periodStart) : '本週快捷(無重製時間)'));

        await waitFor(() => document.body);
        await sleep(adaptiveDly); 

        try {
            if (currentHref.toLowerCase().includes('/index/home')) {
                let manageBtn = await waitFor(() => {
                    const btn = document.querySelector('a[href="/index/user_info"]');
                    return (btn && btn.offsetWidth > 0) ? btn : null;
                }, 3000);

                if (!manageBtn) {
                    const memberMenu = await waitFor(() => {
                        for (const a of document.querySelectorAll('a[href="#"]')) {
                            if (a.innerText.includes('會員') && !a.innerText.includes('管理')) return a;
                        }
                        const icon = document.querySelector('i.fa-users');
                        return icon ? icon.closest('a') : null;
                    }, 3000);

                    if (memberMenu) {
                        memberMenu.click();
                        await waitFor(() => document.querySelector('a[href="/index/user_info"]'), 2000);
                    }
                    manageBtn = document.querySelector('a[href="/index/user_info"]');
                }

                const nextUrl = manageBtn ? (manageBtn.href || window.location.origin + '/index/user_info') : window.location.origin + '/index/user_info';
                await chrome.storage.local.set({ startUrl: nextUrl });

                if (manageBtn) {
                    manageBtn.click();
                    const urlChanged = await waitFor(() => !window.location.href.toLowerCase().includes('/index/home'), 2000);
                    if (!urlChanged) window.location.href = nextUrl;
                } else {
                    window.location.href = nextUrl;
                }
                return;
            }

            const isKnownPage = currentHref.toLowerCase().includes('/index/user_info') || state.step === 'EXTRACT';

            if (!isKnownPage) {
                    log('[' + accountObj.name + '] SKIP_PAGE_ERR');
                await nextAccount(state, results, { isForceTask });
                return;
            }

            if (state.step === 'SEARCH') {
                const input     = await waitFor(() => document.querySelector('#UserAccount'));
                const searchBtn = await waitFor(() => document.querySelector('#ulbtn'));

                if (!input || !searchBtn) throw new Error('UI_ERR');

                input.value = accountObj.name;
                triggerNativeEvent(input, 'input');
                triggerNativeEvent(input, 'change');
                triggerNativeEvent(input, 'keyup');
                searchBtn.click();

                const modifyBtn = await waitFor(() => {
                    for (const btn of document.querySelectorAll('button')) {
                        const text = btn.innerText.trim();
                        const onclick = btn.getAttribute('onclick') || '';
                        if (text === '修改' && onclick.includes('user_info') && onclick.toLowerCase().includes(accountObj.name.toLowerCase())) {
                            return btn;
                        }
                    }
                    return null;
                }, 10000);

                if (modifyBtn) {
                    if (state.parallelAuto) { try { sessionStorage.setItem('BEC_AUTO_STEP', 'EXTRACT'); } catch (e) {} } else { await chrome.storage.local.set({ step: 'EXTRACT' }); }
                    const match = (modifyBtn.getAttribute('onclick') || '').match(/location\.href\s*=\s*['"]([^'"]+)['"]/i);
                    if (match?.[1]) {
                        window.location.href = match[1].replace(/&amp;/g, '&');
                    } else {
                        modifyBtn.click();
                    }
                } else {
                    log('[' + accountObj.name + '] NOT_FOUND');
                    await nextAccount(state, results, { isForceTask });
                }
            }
            else if (state.step === 'EXTRACT') {
                let balanceStr = '0.00';
                let payoutStr  = '0';
                let hasData = false;
                let resultChecked = false;
                let queryRangeInfo = { start: '', end: '', label: '' };
                let weeklyPayoutStr = '';
                let weeklyPayoutNumber = null;
                let weeklyQueryRangeInfo = { start: '', end: '', label: '' };

                const accTab = await waitFor(() => document.querySelector('a[href="#account"]'));
                if (accTab) {
                    accTab.click();
                    const balEl = await waitFor(() => {
                        const el = document.querySelector('#totalBalanceValue');
                        return el && el.innerText.trim() !== '' ? el : null;
                    }, 3000);
                    if (balEl) balanceStr = balEl.innerText.trim();
                }

                const resTab = await waitFor(() => document.querySelector('a[href="#Result"]'));
                if (resTab) {
                    resTab.click();
                    
                    await waitFor(() => {
                        return document.querySelector('input[name="startDate"]') || Array.from(document.querySelectorAll('button')).find(b => b.innerText.includes('本週'));
                    }, 3000);

                    if (!queryDate || queryDate === '0') {
                        const weekBtn = await waitFor(() => {
                            for (const b of document.querySelectorAll('button')) {
                                if (b.innerText.includes('本週') && (b.getAttribute('onclick') || '').includes('setDate')) return b;
                            }
                            return null;
                        }, 3000);
                        if (weekBtn) weekBtn.click();
                    } else {
                        const dateInput = await waitFor(() => document.querySelector('input[name="startDate"]'), 3000);
                        const queryBtn = await waitFor(() => document.querySelector('button.btn-submit[onclick*="uTResult"]'), 3000);
                        if (dateInput && queryBtn) {
                            dateInput.value = queryDate;
                            triggerNativeEvent(dateInput, 'input');
                            triggerNativeEvent(dateInput, 'change');
                            const enterEvent = new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true });
                            dateInput.dispatchEvent(enterEvent);
                            queryBtn.click();
                        }
                    }

                    await sleep(1200);
                    queryRangeInfo = readQueryDateRange();
                    const resultFound = await waitFor(() => findPayoutResult(), 10000);

                    if (resultFound) {
                        resultChecked = true;
                        payoutStr = resultFound.val;
                        if (resultFound.type === 'data') {
                            hasData = true;
                        }
                    }
                }
                    const needsWeeklySnapshot = !!periodStart && !String(accountObj.poolId || '').trim() && !!accountObj.resetAt;
                    if (needsWeeklySnapshot && hasData) {
                        const weekBtn = await waitFor(() => {
                            for (const b of document.querySelectorAll('button')) {
                                if (b.innerText.includes('本週') && (b.getAttribute('onclick') || '').includes('setDate')) return b;
                            }
                            return null;
                        }, 3000);
                        if (weekBtn) {
                            weekBtn.click();
                            await sleep(1200);
                            weeklyQueryRangeInfo = readQueryDateRange();
                            const weeklyFound = await waitFor(() => findPayoutResult(), 10000);
                            if (weeklyFound && weeklyFound.type === 'data') {
                                weeklyPayoutStr = weeklyFound.val;
                                const n = parseMoney(weeklyPayoutStr);
                                weeklyPayoutNumber = Number.isFinite(n) ? n : null;
                            }
                        }
                    }


                const payoutNum = parseMoney(payoutStr);
                const individualWinLimit = Number(accountObj.winLimit ?? accountObj.limit);
                const individualLossLimit = Number(accountObj.lossLimit ?? accountObj.limit);
                const individualHit = getLimitHit(payoutNum, individualWinLimit, individualLossLimit);
                const individualExceeded = individualHit.hit;

                let poolExceeded = false;
                let poolSingleExceeded = false;
                let poolAlertText = '';
                let poolSingleAlertText = '';
                const poolId = normalizePoolId(accountObj.poolId);
                const poolWinLimit = Number(accountObj.poolWinLimit ?? accountObj.poolLimit);
                const poolLossLimit = Number(accountObj.poolLossLimit ?? accountObj.poolLimit);
                const poolLimit = Math.max(Number.isFinite(poolWinLimit) ? poolWinLimit : 0, Number.isFinite(poolLossLimit) ? poolLossLimit : 0);
                const hasPoolLimit = (Number.isFinite(poolWinLimit) && poolWinLimit > 0) || (Number.isFinite(poolLossLimit) && poolLossLimit > 0);
                const poolMode = accountObj.poolMode === 'hybrid' ? 'hybrid' : 'total';
                let nextPoolStatus = state.poolStatus || {};
                let nextForceMap = (state.poolForceMembers && typeof state.poolForceMembers === 'object') ? { ...state.poolForceMembers } : {};
                let nextForceQueue = Array.isArray(state.forceDisableQueue) ? [...state.forceDisableQueue] : [];
                let forceChanged = false;

                const poolSingleHit = getLimitHit(payoutNum, poolWinLimit, poolLossLimit);
                if (poolId && poolMode === 'hybrid' && resultChecked && poolSingleHit.hit) {
                    poolSingleExceeded = true;
                    poolSingleAlertText = '共用池 ' + poolId + ' 方式1：單帳' + limitHitText(poolSingleHit);
                }

                if (!state.parallelAuto && poolId && hasPoolLimit && resultChecked) {
                    const prevPool = nextPoolStatus[poolId];
                    const members = (prevPool && prevPool.periodKey === periodKey && prevPool.members && typeof prevPool.members === 'object')
                        ? { ...prevPool.members }
                        : {};

                    members[accountObj.name] = Number.isFinite(payoutNum) ? payoutNum : 0;

                    const memberAccounts = (state.accounts || []).filter((acc) => {
                        const pid = normalizePoolId(acc?.poolId);
                        return pid === poolId && String(acc?.name || '').trim();
                    });
                    const queriedMemberKeys = new Set(Object.keys(members).map(accountKey));
                    const allPoolMembersQueried = memberAccounts.length > 0 && memberAccounts.every((acc) => {
                        return queriedMemberKeys.has(accountKey(acc?.name));
                    });

                    const total = Object.values(members).reduce((sum, v) => {
                        const n = Number(v);
                        return Number.isFinite(n) ? sum + n : sum;
                    }, 0);
                    const poolTotalHit = getLimitHit(total, poolWinLimit, poolLossLimit);

                    nextPoolStatus = {
                        ...nextPoolStatus,
                        [poolId]: {
                            periodKey,
                            limit: poolLimit,
                            winLimit: poolWinLimit,
                            lossLimit: poolLossLimit,
                            total,
                            allQueried: allPoolMembersQueried,
                            mode: poolMode,
                            members
                        }
                    };

                    poolExceeded = allPoolMembersQueried && poolTotalHit.hit;
                    if (poolExceeded) {
                        poolAlertText = '共用池 ' + poolId + ' 全部查完，總和' + limitHitText(poolTotalHit) + '，目前總和 ' + total.toLocaleString();

                        const disabledKeySet = new Set(Object.keys((state.disabledAccounts && typeof state.disabledAccounts === 'object') ? state.disabledAccounts : {}));
                        const queueKeySet = new Set(nextForceQueue.map(item => accountKey(item?.name)));

                        memberAccounts.forEach((memberAcc) => {
                            const memberName = String(memberAcc.name || '').trim();
                            if (!memberName) return;

                            const key = accountKey(memberName);
                            if (!nextForceMap[key]) {
                                nextForceMap[key] = { poolId, reason: poolAlertText };
                                forceChanged = true;
                            }

                            if (memberName !== accountObj.name && !disabledKeySet.has(key) && !queueKeySet.has(key)) {
                                nextForceQueue.push({ ...memberAcc, forceDisableOnly: true });
                                queueKeySet.add(key);
                                forceChanged = true;
                            }
                        });
                    } else if (!allPoolMembersQueried) {
                        log('[' + accountObj.name + '] POOL_WAIT_ALL ' + poolId);
                    }

                    await chrome.storage.local.set({ poolStatus: nextPoolStatus, currentPeriodKey: periodKey });
                }

                if (forceChanged) {
                    await chrome.storage.local.set({
                        poolForceMembers: nextForceMap,
                        forceDisableQueue: nextForceQueue
                    });
                }

                const forceMeta = nextForceMap[accountKey(accountObj.name)];
                const forcedByPool = !!(forceMeta && normalizePoolId(forceMeta.poolId) === poolId);
                const forceReason = forcedByPool
                    ? (forceMeta.reason || 'Pool ' + forceMeta.poolId + ' reached limit, group disable')
                    : '';

                const isExceeded = individualExceeded || poolSingleExceeded || poolExceeded || forcedByPool || !!accountObj.forceDisableOnly;

                if (hasData) {
                    const resultMeta = {
                        poolId: poolId || '',
                        poolMode,
                        queryStart: queryRangeInfo.start || (periodStart ? toDateTimeSearch(periodStart) : ''),
                        queryEnd: queryRangeInfo.end || '',
                        queryRange: queryRangeInfo.label || (periodStart ? toDateTimeSearch(periodStart) + ' ~ 目前' : '本週'),
                        resetAt: effectiveAnchor || '',
                        periodStart: periodStart ? toDateTimeSearch(periodStart) : '',
                        isSharedPool: !!poolId,
                        resetPayout: payoutStr,
                        resetPayoutNumber: Number.isFinite(payoutNum) ? payoutNum : null,
                        weeklyPayout: weeklyPayoutStr,
                        weeklyPayoutNumber,
                        weeklyQueryRange: weeklyQueryRangeInfo.label || ''
                    };
                    results = updateResult(results, accountObj.name, balanceStr, payoutStr, isExceeded, resultMeta);
                } else {
                    log('[' + accountObj.name + '] SKIP_NODATA');
                }

                if (individualExceeded) {
                    log('[' + accountObj.name + '] INDIVIDUAL_LIMIT_HIT');
                }
                if (poolSingleExceeded) {
                    log('[' + accountObj.name + '] POOL_SINGLE_LIMIT_HIT ' + poolSingleAlertText);
                }
                if (poolExceeded) {
                    log('[' + accountObj.name + '] POOL_LIMIT_HIT ' + poolAlertText);
                }
                if (forcedByPool || accountObj.forceDisableOnly) {
                    log('[' + accountObj.name + '] POOL_FORCE_DISABLE');
                }

                const disabledAccounts = (state.disabledAccounts && typeof state.disabledAccounts === 'object')
                    ? { ...state.disabledAccounts }
                    : {};
                const disabledKey = accountKey(accountObj.name);
                const alreadyDisabled = !!disabledAccounts[disabledKey];

                if (isExceeded && !alreadyDisabled) {
                    log('[' + accountObj.name + '] EXCEEDED_LIMIT_START');
                    try {
                        const infoTab = await waitFor(() => document.querySelector('a.nav-link[href="#account"]'), 3000);
                        if (infoTab) infoTab.click();
                        await sleep(1000);

                        const statusSelect = await waitFor(() => document.querySelector('select[name="ustatus"]'), 3000);
                        if (statusSelect) {
                            statusSelect.value = "0";
                            triggerNativeEvent(statusSelect, 'change');
                        }

                        const modifySubmitBtn = await waitFor(() => {
                            const btns = Array.from(document.querySelectorAll('button[type="submit"]'));
                            return btns.find(b => b.innerText.includes('修改') && b.offsetWidth > 0);
                        }, 3000);
                        if (modifySubmitBtn) modifySubmitBtn.click();

                        const clickSwalBtn = async (btnText, timeout = 5000) => {
                            const btn = await waitFor(() => {
                                const btns = Array.from(document.querySelectorAll('.swal2-confirm'));
                                return btns.find(b => b.innerText.trim() === btnText && b.offsetWidth > 0);
                            }, timeout);
                            if (btn) {
                                btn.click();
                                await sleep(1000);
                                return true;
                            }
                            return false;
                        };

                        await clickSwalBtn('確定', 5000);
                        await clickSwalBtn('OK', 5000);

                        const transferBtn = await waitFor(() => document.querySelector('button.totalAll'), 3000);
                        if (transferBtn) transferBtn.click();

                        await clickSwalBtn('確定', 5000);
                        await clickSwalBtn('OK', 15000);

                        const alertReason = [];
                        if (individualExceeded) alertReason.push('個人' + (payoutNum < 0 ? '輸' : '贏') + '達上限');
                        if (poolSingleExceeded) alertReason.push(poolSingleAlertText || '共用池單帳達上限');
                        if (poolExceeded) alertReason.push(poolAlertText || '共用額度達上限');
                        if (!poolExceeded && forcedByPool) alertReason.push(forceReason || '共用池總和達上限');
                        const reasonText = alertReason.join(' / ') || '已達上限';
                        const alertMsg = '帳號 ' + accountObj.name + ' ' + reasonText + '，已停用並轉回主錢包，請前往查詢';

                        const storedData = await chrome.storage.local.get(['disabledRecords']);
                        const disabledRecords = Array.isArray(storedData.disabledRecords) ? [...storedData.disabledRecords] : [];
                        disabledAccounts[disabledKey] = true;

                        const disabledRecord = {
                            account: accountObj.name,
                            payout: payoutStr,
                            payoutNumber: Number.isFinite(payoutNum) ? payoutNum : null,
                            resetPayout: payoutStr,
                            resetPayoutNumber: Number.isFinite(payoutNum) ? payoutNum : null,
                            weeklyPayout: weeklyPayoutStr,
                            weeklyPayoutNumber,
                            balance: balanceStr,
                            reason: reasonText,
                            poolId: poolId || '',
                            poolMode,
                            poolTotalNumber: forceMeta && Number.isFinite(Number(forceMeta.poolTotalNumber)) ? Number(forceMeta.poolTotalNumber) : null,
                            poolLimitNumber: forceMeta && Number.isFinite(Number(forceMeta.poolLimitNumber)) ? Number(forceMeta.poolLimitNumber) : null,
                            poolDirection: forceMeta && forceMeta.poolDirection ? String(forceMeta.poolDirection) : '',
                            poolMemberCount: forceMeta && Number.isFinite(Number(forceMeta.poolMemberCount)) ? Number(forceMeta.poolMemberCount) : null,
                            queryStart: queryRangeInfo.start || (periodStart ? toDateTimeSearch(periodStart) : ''),
                            queryEnd: queryRangeInfo.end || '',
                            queryRange: queryRangeInfo.label || (periodStart ? toDateTimeSearch(periodStart) + ' ~ 目前' : '本週'),
                            weeklyQueryRange: weeklyQueryRangeInfo.label || '',
                            time: new Date().toLocaleString('zh-TW', { hour12: false }),
                            at: new Date().toISOString()
                        };
                        const existingIdx = disabledRecords.findIndex(item => accountKey(item.account) === disabledKey);
                        if (existingIdx >= 0) {
                            disabledRecords[existingIdx] = { ...disabledRecords[existingIdx], ...disabledRecord };
                        } else {
                            disabledRecords.push(disabledRecord);
                        }

                        await chrome.storage.local.set({ disabledAccounts, disabledRecords });

                        chrome.runtime.sendMessage({
                            action: 'SHOW_ALERT',
                            title: 'ALERT',
                            account: accountObj.name,
                            message: alertMsg
                        }).catch(() => {});

                        log('[' + accountObj.name + '] EXCEEDED_LIMIT_DONE');
                    } catch (ex) {
                        log('[' + accountObj.name + '] EXCEEDED_LIMIT_ERR: ' + ex.message);
                    }
                }
                
                await nextAccount(state, results, { isForceTask });
            }

        } catch (error) {
            log('[' + accountObj.name + '] ERR: ' + error.message);
            await nextAccount(state, results, { isForceTask });
        }
    });
})();





