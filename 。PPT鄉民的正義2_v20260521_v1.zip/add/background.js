const TARGET_URL = 'https://b9a9vnfik.becgame88168.com/index/Home';
let backgroundWindowId = null;

const storageGet = (keys) => new Promise(resolve => chrome.storage.local.get(keys, resolve));
const storageSet = (obj) => new Promise(resolve => chrome.storage.local.set(obj, resolve));
const storageRemove = (keys) => new Promise(resolve => chrome.storage.local.remove(keys, resolve));
const accountKey = (name) => String(name || '').trim().toLowerCase();
const normalizePoolId = (raw) => String(raw || '').trim().toUpperCase().replace(/\s+/g, '-');

const closeWindowQuiet = (id) => {
    if (!id) return;
    chrome.windows.remove(id, () => { void chrome.runtime.lastError; });
};

const closeAutoWindows = async () => {
    const data = await storageGet(['bgWindowId', 'bgWindowIds', 'activeAutoWindows', 'targetTabIds']);
    const ids = new Set();
    if (backgroundWindowId) ids.add(backgroundWindowId);
    if (data.bgWindowId) ids.add(data.bgWindowId);
    (Array.isArray(data.bgWindowIds) ? data.bgWindowIds : []).forEach(id => ids.add(id));
    (Array.isArray(data.activeAutoWindows) ? data.activeAutoWindows : []).forEach(id => ids.add(id));
    ids.forEach(closeWindowQuiet);
    backgroundWindowId = null;
    await storageRemove(['bgWindowId', 'bgWindowIds', 'targetTabId', 'targetTabIds', 'activeAutoWindows', 'activeTasks']);
};

const getDisabledKeySet = (data) => {
    const set = new Set();
    const disabledAccounts = data.disabledAccounts && typeof data.disabledAccounts === 'object' ? data.disabledAccounts : {};
    Object.keys(disabledAccounts).forEach(k => { if (disabledAccounts[k]) set.add(accountKey(k)); });
    (Array.isArray(data.disabledRecords) ? data.disabledRecords : []).forEach(r => {
        const k = accountKey(r && r.account);
        if (k) set.add(k);
    });
    return set;
};

const appendLog = async (text) => {
    const data = await storageGet(['debugLog']);
    const log = data.debugLog || [];
    log.push('[' + new Date().toLocaleTimeString('zh-TW', { hour12: false }) + '] ' + text);
    if (log.length > 80) log.shift();
    await storageSet({ debugLog: log });
};

const getLimitHit = (value, winLimitRaw, lossLimitRaw) => {
    const amount = Number(value);
    if (!Number.isFinite(amount) || amount === 0) return { hit: false };
    const winLimit = Number(winLimitRaw);
    const lossLimit = Number(lossLimitRaw);
    if (amount > 0 && Number.isFinite(winLimit) && winLimit > 0 && amount >= winLimit) return { hit: true, direction: '贏', limit: winLimit };
    if (amount < 0 && Number.isFinite(lossLimit) && lossLimit > 0 && Math.abs(amount) >= lossLimit) return { hit: true, direction: '輸', limit: lossLimit };
    return { hit: false };
};

const poolModeOf = (pool) => {
    const raw = String((pool && pool.mode) || '').toLowerCase();
    return raw === 'hybrid' ? 'hybrid' : 'total';
};

const maybeQueuePoolForceDisables = async () => {
    const data = await storageGet(['isRunning', 'autoConfig', 'results', 'autoQueue', 'activeTasks', 'disabledAccounts', 'disabledRecords', 'poolForceMembers']);
    if (!data.isRunning || !data.autoConfig) return;

    const cfg = data.autoConfig || {};
    const pools = Array.isArray(cfg.sharedPools) ? cfg.sharedPools : [];
    const accounts = Array.isArray(cfg.accounts) ? cfg.accounts : [];
    const results = Array.isArray(data.results) ? data.results : [];
    const queue = Array.isArray(data.autoQueue) ? [...data.autoQueue] : [];
    const activeTasks = data.activeTasks && typeof data.activeTasks === 'object' ? data.activeTasks : {};
    const forceMap = data.poolForceMembers && typeof data.poolForceMembers === 'object' ? { ...data.poolForceMembers } : {};
    const disabledSet = getDisabledKeySet(data);
    const queuedSet = new Set(queue.map(acc => accountKey(acc && acc.name)));
    Object.values(activeTasks).forEach(task => queuedSet.add(accountKey(task && task.account && task.account.name)));
    let changed = false;

    pools.forEach(pool => {
        const poolId = normalizePoolId(pool && pool.id);
        if (!poolId) return;
        const members = accounts.filter(acc => normalizePoolId(acc && acc.poolId) === poolId && String(acc && acc.name || '').trim());
        if (!members.length) return;
        const resultMap = new Map(results.map(r => [accountKey(r && r.account), r]));
        const allDone = members.every(acc => resultMap.has(accountKey(acc.name)) || disabledSet.has(accountKey(acc.name)));
        if (!allDone) return;

        const total = members.reduce((sum, acc) => {
            const r = resultMap.get(accountKey(acc.name));
            const n = Number(r && (r.resetPayoutNumber ?? r.payoutNumber));
            return Number.isFinite(n) ? sum + n : sum;
        }, 0);
        const winLimit = Number(pool.winLimitWan || pool.limitWan || 0) * 10000;
        const lossLimit = Number(pool.lossLimitWan || pool.limitWan || 0) * 10000;
        const hit = getLimitHit(total, winLimit, lossLimit);
        if (!hit.hit) return;

        const reason = '共用池 ' + poolId + ' 全部查完，總和' + hit.direction + '達上限 ' + Number(hit.limit).toLocaleString() + '，目前總和 ' + total.toLocaleString();
                const forceInfo = {
            poolId,
            reason,
            poolTotalNumber: total,
            poolLimitNumber: Number(hit.limit),
            poolDirection: hit.direction || '',
            poolMemberCount: members.length
        };
        members.forEach(member => {
            const key = accountKey(member.name);
            if (!key || disabledSet.has(key) || queuedSet.has(key)) return;
            forceMap[key] = forceInfo;
            queue.unshift({
                name: member.name,
                poolId: poolId,
                poolLimit: Math.max(winLimit, lossLimit) || null,
                poolWinLimit: winLimit || null,
                poolLossLimit: lossLimit || null,
                poolMode: poolModeOf(pool),
                limit: null,
                winLimit: null,
                lossLimit: null,
                date: member.date || '0',
                resetAt: member.resetAt || (cfg.resetRule && cfg.resetRule.anchor) || '',
                repeatWeekly: !(cfg.resetRule && cfg.resetRule.repeatWeekly === false),
                forceDisableOnly: true
            });
            queuedSet.add(key);
            changed = true;
        });
        if (changed) appendLog(reason);
    });

    if (changed) await storageSet({ autoQueue: queue, poolForceMembers: forceMap });
};

const getAdaptiveWindowLimit = (pendingCount, maxCapRaw) => {
    const pending = Math.max(0, Number(pendingCount) || 0);
    const maxCap = Math.max(1, Math.min(10, Number(maxCapRaw) || 10));
    if (pending <= 0) return 0;
    if (pending <= 2) return Math.min(maxCap, pending);
    if (pending <= 6) return Math.min(maxCap, 3);
    if (pending <= 12) return Math.min(maxCap, 4);
    if (pending <= 24) return Math.min(maxCap, 6);
    if (pending <= 40) return Math.min(maxCap, 8);
    return maxCap;
};
const openAutoWindow = async (url, incognito) => new Promise(resolve => {
    chrome.windows.getCurrent({ populate: false }, (currentWin) => {
        const windowConfig = {
            url,
            type: 'normal',
            state: 'normal',
            focused: false,
            incognito,
            width: 600,
            height: 600
        };
        chrome.windows.create(windowConfig, async (win) => {
            if (chrome.runtime.lastError || !win) {
                resolve({ success: false, error: chrome.runtime.lastError && chrome.runtime.lastError.message || 'Failed' });
                return;
            }
            if (incognito && !win.incognito) {
                closeWindowQuiet(win.id);
                resolve({ success: false, error: 'INCOGNITO_DISABLED' });
                return;
            }
            if (currentWin && currentWin.id) chrome.windows.update(currentWin.id, { focused: true });
            backgroundWindowId = win.id;
            const tabId = win.tabs && win.tabs[0] && win.tabs[0].id;
            const data = await storageGet(['bgWindowIds', 'activeAutoWindows', 'targetTabIds']);
            const bgWindowIds = Array.isArray(data.bgWindowIds) ? data.bgWindowIds : [];
            const activeAutoWindows = Array.isArray(data.activeAutoWindows) ? data.activeAutoWindows : [];
            const targetTabIds = data.targetTabIds && typeof data.targetTabIds === 'object' ? data.targetTabIds : {};
            if (!bgWindowIds.includes(win.id)) bgWindowIds.push(win.id);
            if (!activeAutoWindows.includes(win.id)) activeAutoWindows.push(win.id);
            if (tabId) targetTabIds[String(tabId)] = true;
            await storageSet({ bgWindowId: win.id, bgWindowIds, activeAutoWindows, targetTabId: tabId, targetTabIds });
            if (tabId && win.tabs[0].status === 'complete') {
                chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] }).catch(() => {});
            }
            resolve({ success: true, tabId, windowId: win.id });
        });
    });
});

const pumpParallelWindows = async () => {
    const data = await storageGet(['isRunning', 'isWaiting', 'autoQueue', 'activeAutoWindows', 'maxParallelWindows', 'parallelWindowMode', 'parallelAuto', 'startUrl']);
    if (!data.isRunning || data.isWaiting || !data.parallelAuto) return { success: true, opened: 0 };
    const queue = Array.isArray(data.autoQueue) ? data.autoQueue : [];
    const active = Array.isArray(data.activeAutoWindows) ? data.activeAutoWindows : [];
    const pendingCount = queue.length + active.length;
    const maxCap = Math.max(1, Math.min(10, Number(data.maxParallelWindows) || 10));
    const limit = data.parallelWindowMode === 'fixed' ? maxCap : getAdaptiveWindowLimit(pendingCount, maxCap);
    const need = Math.max(0, Math.min(limit - active.length, queue.length));
    await storageSet({ currentParallelLimit: limit, currentParallelActive: active.length, currentParallelPending: pendingCount });
    let openedCount = 0;
    for (let i = 0; i < need; i += 1) {
        const opened = await openAutoWindow(data.startUrl || TARGET_URL, true);
        if (!opened.success) {
            await storageSet({ isRunning: false, isWaiting: false, parallelAuto: false, lastAutoError: opened.error || 'OPEN_FAILED' });
            await appendLog('OPEN_FAILED ' + (opened.error || ''));
            return { success: false, error: opened.error || 'OPEN_FAILED', opened: openedCount };
        }
        openedCount += 1;
    }
    if (openedCount > 0) await appendLog('AUTO_WINDOWS active=' + (active.length + openedCount) + ' limit=' + limit + ' pending=' + pendingCount);
    return { success: true, opened: openedCount, limit };
};

const finishIfDone = async () => {
    await maybeQueuePoolForceDisables();
    const data = await storageGet(['isRunning', 'parallelAuto', 'autoQueue', 'activeAutoWindows', 'activeTasks', 'intervalMin', 'isWaiting']);
    if (!data.isRunning || !data.parallelAuto) return;
    const queue = Array.isArray(data.autoQueue) ? data.autoQueue : [];
    const activeWindows = Array.isArray(data.activeAutoWindows) ? data.activeAutoWindows : [];
    const activeTasks = data.activeTasks && typeof data.activeTasks === 'object' ? data.activeTasks : {};
    if (queue.length === 0 && activeWindows.length === 0 && Object.keys(activeTasks).length === 0) {
        if (data.intervalMin > 0 && !data.isWaiting) {
            await appendLog('WAIT_' + data.intervalMin);
            await storageSet({ isWaiting: true });
            chrome.alarms.create('BEC_INTERVAL', { delayInMinutes: data.intervalMin });
        } else if (!data.intervalMin && !data.isWaiting) {
            await storageSet({ isRunning: false, isWaiting: false });
            await appendLog('FINISH');
        }
    }
};

const claimTask = async (sender, sendResponse) => {
    const data = await storageGet(['isRunning', 'autoQueue', 'activeTasks', 'disabledAccounts', 'disabledRecords', 'autoConfig', 'startUrl', 'completedCount']);
    if (!data.isRunning) {
        sendResponse({ success: false, done: true });
        const winId = sender && sender.tab && sender.tab.windowId;
        if (winId) setTimeout(() => closeWindowQuiet(winId), 250);
        return;
    }
    const queue = Array.isArray(data.autoQueue) ? [...data.autoQueue] : [];
    const disabledSet = getDisabledKeySet(data);
    let account = null;
    while (queue.length > 0 && !account) {
        const candidate = queue.shift();
        const key = accountKey(candidate && candidate.name);
        if (!key) continue;
        if (!candidate.forceDisableOnly && disabledSet.has(key)) {
            appendLog('SKIP_DISABLED ' + candidate.name);
            continue;
        }
        account = candidate;
    }
    if (!account) {
        await storageSet({ autoQueue: queue });
        sendResponse({ success: false, done: true });
        const winId = sender && sender.tab && sender.tab.windowId;
        if (winId) setTimeout(() => closeWindowQuiet(winId), 250);
        setTimeout(() => finishIfDone(), 500);
        return;
    }
    const taskId = 'task_' + Date.now() + '_' + Math.random().toString(16).slice(2);
    const activeTasks = data.activeTasks && typeof data.activeTasks === 'object' ? { ...data.activeTasks } : {};
    activeTasks[taskId] = {
        account,
        tabId: sender && sender.tab && sender.tab.id,
        windowId: sender && sender.tab && sender.tab.windowId,
        startedAt: Date.now()
    };
    const completedBase = Number(data.completedCount || 0);
    await storageSet({ autoQueue: queue, activeTasks, currentIndex: completedBase + Object.keys(activeTasks).length });
    sendResponse({ success: true, taskId, account, startUrl: data.startUrl || TARGET_URL, autoConfig: data.autoConfig || {} });
};

const taskDone = async (message, sender, sendResponse) => {
    const data = await storageGet(['activeTasks', 'completedCount', 'activeAutoWindows', 'targetTabIds']);
    const activeTasks = data.activeTasks && typeof data.activeTasks === 'object' ? { ...data.activeTasks } : {};
    if (message.taskId && activeTasks[message.taskId]) delete activeTasks[message.taskId];
    const completedCount = Number(data.completedCount || 0) + 1;
    const tabId = sender && sender.tab && sender.tab.id;
    const windowId = sender && sender.tab && sender.tab.windowId;
    const targetTabIds = data.targetTabIds && typeof data.targetTabIds === 'object' ? { ...data.targetTabIds } : {};
    if (tabId) delete targetTabIds[String(tabId)];
    await storageSet({ activeTasks, completedCount, currentIndex: completedCount, targetTabIds });
    sendResponse({ success: true });
    if (windowId) setTimeout(() => closeWindowQuiet(windowId), 250);
    setTimeout(async () => {
        await pumpParallelWindows();
        await finishIfDone();
    }, 600);
};

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'CREATE_PARALLEL_WINDOWS') {
        sendResponse({ success: true });
        (async () => {
            chrome.alarms.clear('BEC_INTERVAL');
            await closeAutoWindows();
            await storageSet({ parallelAuto: true, parallelWindowMode: message.mode === 'fixed' ? 'fixed' : 'auto', maxParallelWindows: Math.max(1, Math.min(10, Number(message.maxLimit || message.limit || 10))) });
            const pumped = await pumpParallelWindows();
            if (pumped && pumped.success === false) await appendLog('PARALLEL_START_FAILED ' + (pumped.error || ''));
        })().catch(err => appendLog('PARALLEL_START_ERR ' + (err && err.message || String(err))));
        return false;
    }

    if (message.action === 'CLAIM_AUTO_TASK') {
        claimTask(sender, sendResponse).catch(err => sendResponse({ success: false, error: err && err.message || String(err) }));
        return true;
    }

    if (message.action === 'AUTO_TASK_DONE') {
        taskDone(message, sender, sendResponse).catch(err => sendResponse({ success: false, error: err && err.message || String(err) }));
        return true;
    }

    if (message.action === 'CREATE_BACKGROUND_WINDOW') {
        (async () => {
            chrome.alarms.clear('BEC_INTERVAL');
            await closeAutoWindows();
            await storageSet({ parallelAuto: false });
            const opened = await openAutoWindow(message.url || TARGET_URL, message.incognito !== false);
            sendResponse(opened);
        })().catch(err => sendResponse({ success: false, error: err && err.message || String(err) }));
        return true;
    }

    if (message.action === 'CLOSE_BACKGROUND_WINDOW') {
        (async () => {
            chrome.alarms.clear('BEC_INTERVAL');
            await closeAutoWindows();
            await storageSet({ isRunning: false, isWaiting: false, parallelAuto: false });
            sendResponse({ success: true });
        })().catch(err => sendResponse({ success: false, error: err && err.message || String(err) }));
        return true;
    }

    if (message.action === 'DEBUG_LOG') {
        appendLog(message.text || '');
        return false;
    }

    if (message.action === 'STOP_TTS') {
        if (chrome.tts) chrome.tts.stop();
        return false;
    }

    if (message.action === 'SHOW_ALERT') {
        if (chrome.tts) {
            chrome.tts.speak(message.message, { lang: 'zh-TW', rate: 1.0, volume: 1.0, enqueue: true });
        }
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (tabs.length > 0 && tabs[0].url && tabs[0].url.startsWith('http')) {
                chrome.scripting.executeScript({
                    target: { tabId: tabs[0].id },
                    func: (msg, accName) => {
                        const divId = 'bec-alert-' + accName;
                        if (document.getElementById(divId)) return;
                        const div = document.createElement('div');
                        div.id = divId;
                        div.style.position = 'fixed';
                        div.style.top = '6px';
                        div.style.right = '320px';
                        div.style.backgroundColor = '#ff4d4f';
                        div.style.color = '#fff';
                        div.style.padding = '6px 14px';
                        div.style.fontSize = '14px';
                        div.style.fontWeight = 'bold';
                        div.style.fontFamily = 'sans-serif';
                        div.style.borderRadius = '4px';
                        div.style.boxShadow = '0 2px 10px rgba(0,0,0,0.5)';
                        div.style.zIndex = '2147483647';
                        div.style.display = 'flex';
                        div.style.alignItems = 'center';
                        div.style.gap = '12px';
                        div.innerHTML = '<span>警告 ' + msg + '</span><button class="bec-alert-close-btn" style="background:#fff; color:#ff4d4f; border:none; padding:4px 10px; border-radius:4px; cursor:pointer; font-weight:bold; font-size:12px; outline:none;">已確認</button>';
                        div.querySelector('.bec-alert-close-btn').addEventListener('click', () => {
                            div.remove();
                            chrome.runtime.sendMessage({ action: 'STOP_TTS' });
                        });
                        document.body.appendChild(div);
                    },
                    args: [message.message, message.account]
                }).catch(() => {});
            }
        });
        chrome.notifications.create({
            type: 'basic',
            title: message.title || 'BEC LITE',
            message: message.message || '',
            priority: 2,
            requireInteraction: true,
            iconUrl: chrome.runtime.getURL('icon128.png')
        }, () => { if (chrome.runtime.lastError) console.warn('Notification failed:', chrome.runtime.lastError.message); });
        return false;
    }

    if (message.action === 'START_INTERVAL') {
        chrome.alarms.create('BEC_INTERVAL', { delayInMinutes: message.minutes });
        closeAutoWindows();
        sendResponse({ success: true });
        return true;
    }
});

chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name !== 'BEC_INTERVAL') return;
    chrome.storage.local.get(['isRunning', 'accounts'], async (data) => {
        if (!data.isRunning) return;
        await appendLog('啟動背景查詢');
        await storageSet({
            autoQueue: Array.isArray(data.accounts) ? data.accounts : [],
            activeTasks: {},
            activeAutoWindows: [],
            targetTabIds: {},
            completedCount: 0,
            currentIndex: 0,
            step: 'SEARCH',
            isWaiting: false,
            startUrl: TARGET_URL,
            poolStatus: {},
            currentPeriodKey: '',
            forceDisableQueue: [],
            poolForceMembers: {}
        });
        await pumpParallelWindows();
    });
});

chrome.windows.onRemoved.addListener((windowId) => {
    (async () => {
        const data = await storageGet(['activeAutoWindows', 'bgWindowIds', 'bgWindowId', 'targetTabIds', 'isWaiting', 'parallelAuto']);
        const activeAutoWindows = (Array.isArray(data.activeAutoWindows) ? data.activeAutoWindows : []).filter(id => id !== windowId);
        const bgWindowIds = (Array.isArray(data.bgWindowIds) ? data.bgWindowIds : []).filter(id => id !== windowId);
        const patch = { activeAutoWindows, bgWindowIds };
        if (data.bgWindowId === windowId || backgroundWindowId === windowId) {
            backgroundWindowId = null;
            patch.bgWindowId = bgWindowIds[0] || null;
        }
        await storageSet(patch);
        if (data.parallelAuto) {
            await pumpParallelWindows();
            await finishIfDone();
        } else if ((data.bgWindowId === windowId || backgroundWindowId === windowId) && !data.isWaiting) {
            await storageSet({ isRunning: false, isWaiting: false });
            chrome.alarms.clear('BEC_INTERVAL');
        }
    })();
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
    if (changeInfo.status !== 'complete') return;
    chrome.storage.local.get(['isRunning', 'targetTabId', 'targetTabIds'], (data) => {
        const targetTabIds = data.targetTabIds && typeof data.targetTabIds === 'object' ? data.targetTabIds : {};
        if (!data.isRunning || (data.targetTabId !== tabId && !targetTabIds[String(tabId)])) return;
        chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] }).catch(() => {});
    });
});