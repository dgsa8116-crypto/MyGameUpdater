(() => {
    const isBecGamePage = () => {
        try {
            const hostname = String(window.location?.hostname || '').toLowerCase();
            return hostname === 'becgame88168.com' || hostname.endsWith('.becgame88168.com');
        } catch (error) {
            return false;
        }
    };

    if (!isBecGamePage()) {
        document.getElementById('bec-page-pet-host')?.remove();
        window.__becPagePetLoaded = false;
        return;
    }

    if (window.__becPagePetLoaded) {
        if (typeof window.__becPagePetRefresh === 'function') window.__becPagePetRefresh();
        return;
    }
    window.__becPagePetLoaded = true;

    const extensionApi = (typeof chrome === 'object' && chrome) ? chrome : {};
    const runtimeApi = extensionApi.runtime || {};
    const storageArea = extensionApi.storage?.local || null;
    const storageEvents = extensionApi.storage?.onChanged || null;
    const assetUrl = (file) => {
        try {
            return typeof runtimeApi.getURL === 'function' ? runtimeApi.getURL(file) : file;
        } catch (error) {
            return file;
        }
    };

    const STORE = { enabled: 'becPagePetEnabled', bubble: 'becPagePetBubble', position: 'becPagePetPosition' };
    const idleFrames = ['momo-shime-sit1.png', 'momo-shime-sit2.png', 'momo-shime-sit3.png', 'momo-shime-sit4.png'].map(assetUrl);
    const petFrames = ['momo-shime1.png', 'momo-shime2.png', 'momo-shime3.png', 'momo-shime4.png'].map(assetUrl);
    const alertFrame = assetUrl('momo-shime-alert.png');
    const MAX_Z = 2147483647;
    const INITIAL_SCAN_DELAYS = [250, 900, 1800, 3600, 6500];

    let host = null;
    let state = { enabled: true, bubble: true, position: null };
    let drag = null;
    let hideTimer = 0;
    let alertTimer = 0;
    let frameTimer = 0;
    let frameIndex = 0;
    let autoScanTimer = 0;
    let moodTimer = 0;
    let observer = null;
    let scanBooted = false;
    let lastTask = null;
    let lastTaskKey = '';
    const autoPresentedTaskKeys = new Set();
    let visibleReason = 'idle';

    const storageGet = (keys) => new Promise(resolve => {
        if (!storageArea || typeof storageArea.get !== 'function') {
            resolve({});
            return;
        }
        try {
            storageArea.get(keys, value => resolve(value || {}));
        } catch (error) {
            resolve({});
        }
    });
    const storageSet = (obj) => new Promise(resolve => {
        if (!storageArea || typeof storageArea.set !== 'function') {
            resolve();
            return;
        }
        try {
            storageArea.set(obj, () => {
                void runtimeApi.lastError;
                resolve();
            });
        } catch (error) {
            resolve();
        }
    });
    const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
    const clean = (text) => String(text || '').replace(/[\s\u200B-\u200D\uFEFF]+/g, '');
    const cleanValue = (text) => String(text || '').trim();
    const escapeRegExp = (text) => String(text).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const todayStr = () => {
        const d = new Date();
        return `${d.getFullYear()}/${String(d.getMonth() + 1).padStart(2, '0')}/${String(d.getDate()).padStart(2, '0')}`;
    };
    const isValidValue = (text) => {
        const value = cleanValue(text);
        return value && value !== '無資料' && value !== '--' && value !== '-';
    };

    const ensurePet = () => {
        if (host && document.documentElement.contains(host)) return;
        host = document.createElement('div');
        host.id = 'bec-page-pet-host';
        host.classList.add('is-hidden');
        host.style.zIndex = String(MAX_Z);
        const shadow = host.attachShadow({ mode: 'open' });
        shadow.innerHTML = `
            <style>
                :host { position: fixed; right: 24px; bottom: 24px; width: 162px; height: 190px; z-index: ${MAX_Z}; pointer-events: none; overflow: visible; font-family: "Microsoft JhengHei", "Noto Sans TC", Arial, sans-serif; }
                :host(.is-hidden) { display: none; }
                :host(.no-bubble) .speech { display: none; }
                .pet { position: absolute; inset: 0; pointer-events: auto; user-select: none; -webkit-user-select: none; animation: pet-roam 4.8s ease-in-out infinite; }
                :host(.is-idle) .pet { animation: pet-idle-sit 3.2s ease-in-out infinite; }
                :host(.is-working) .pet { animation: pet-roam 4.8s ease-in-out infinite; }
                .speech { position: absolute; right: 92px; bottom: 126px; min-width: 178px; max-width: 270px; padding: 10px 13px; border: 1px solid rgba(141,244,255,.78); border-radius: 18px 18px 6px 18px; color: #efffff; background: linear-gradient(138deg, rgba(5,43,72,.96), rgba(1,10,26,.94)); box-shadow: 0 0 22px rgba(0,229,255,.35), inset 0 0 18px rgba(128,245,255,.14); font-size: 13px; line-height: 1.4; font-weight: 800; text-shadow: 0 0 8px rgba(0,229,255,.8); opacity: 0; transform: translateY(8px) scale(.96); transition: opacity .22s ease, transform .22s ease; pointer-events: none; }
                .speech.show { opacity: 1; transform: translateY(0) scale(1); }
                .dialog { position: absolute; right: 18px; bottom: 154px; width: min(336px, calc(100vw - 32px)); max-height: min(360px, calc(100vh - 36px)); display: none; flex-direction: column; gap: 9px; padding: 12px; border: 1px solid rgba(141,244,255,.72); border-radius: 16px; color: #eaffff; background: linear-gradient(145deg, rgba(4,32,56,.97), rgba(1,9,24,.97)); box-shadow: 0 18px 34px rgba(0,0,0,.42), 0 0 24px rgba(0,229,255,.28), inset 0 0 18px rgba(128,245,255,.1); pointer-events: auto; }
                .dialog.show { display: flex; }
                .dialog::after { content: ""; position: absolute; right: 38px; bottom: -11px; width: 18px; height: 18px; border-right: 1px solid rgba(141,244,255,.72); border-bottom: 1px solid rgba(141,244,255,.72); background: rgba(1,9,24,.97); transform: rotate(45deg); pointer-events: none; }
                .dialog-head { display: flex; align-items: center; justify-content: space-between; gap: 10px; font-weight: 900; color: #f2ffff; }
                .dialog-close { width: 24px; height: 24px; border-radius: 999px; border: 1px solid rgba(141,244,255,.6); color: #eaffff; background: rgba(0,14,31,.82); cursor: pointer; }
                .dialog-text { font-size: 13px; line-height: 1.5; color: #dffcff; }
                .task { border: 1px solid rgba(141,244,255,.3); border-radius: 14px; background: rgba(0,18,35,.66); overflow: hidden; }
                .task[hidden], .copy-actions[hidden], .copy-btn[hidden] { display: none; }
                .task-title { padding: 9px 10px; font-size: 13px; font-weight: 900; color: #f3ffff; background: linear-gradient(110deg, rgba(25,201,255,.22), rgba(7,33,52,.76), rgba(216,138,72,.13)); }
                .task-body { min-height: 58px; max-height: 122px; overflow: auto; padding: 10px; color: #d9f8ff; font: 12px/1.55 "Consolas", "Microsoft JhengHei", monospace; white-space: pre-wrap; word-break: break-word; }
                .copy-actions { display: grid; grid-template-columns: minmax(0, 1fr) 92px; gap: 8px; align-items: stretch; position: relative; z-index: 2; }
                .copy-btn { width: 100%; height: 34px; min-height: 34px; box-sizing: border-box; display: inline-flex; align-items: center; justify-content: center; padding: 0 10px; border: 1px solid rgba(141,244,255,.52); border-radius: 12px; color: #ecfeff; background: linear-gradient(145deg, rgba(20,104,142,.38), rgba(4,22,36,.9), rgba(216,138,72,.16)); cursor: pointer; font-weight: 900; line-height: 1; white-space: nowrap; overflow: hidden; }
                .copy-time-btn { padding: 0 8px; }
                .copy-btn:disabled { opacity: .48; cursor: not-allowed; }
                .body { position: absolute; right: 12px; bottom: 22px; width: 122px; height: 132px; cursor: grab; border: 0; background: transparent; outline: none; overflow: visible; padding: 0; filter: drop-shadow(0 11px 12px rgba(0,0,0,.42)) drop-shadow(0 0 14px rgba(143,239,255,.48)); }
                .body:active { cursor: grabbing; }
                .sprite { display: block; width: 100%; height: 100%; object-fit: contain; pointer-events: none; transform-origin: 50% 100%; animation: pet-step 1.25s ease-in-out infinite; }
                .base { position: absolute; right: 4px; bottom: 4px; width: 138px; height: 28px; display: flex; align-items: center; justify-content: center; padding: 0 10px; box-sizing: border-box; border: 1px solid rgba(126,244,255,.42); border-radius: 999px; color: #eaffff; background: rgba(0,8,20,.72); box-shadow: 0 0 20px rgba(0,229,255,.22), inset 0 0 14px rgba(140,255,228,.1); font-size: 12px; font-weight: 900; line-height: 1; white-space: nowrap; text-shadow: 0 0 8px rgba(0,229,255,.65); }
                .base.is-empty { color: rgba(234,255,255,.62); }
                .dot { position: absolute; right: 18px; bottom: 28px; width: 13px; height: 13px; border-radius: 999px; background: #8dffce; box-shadow: 0 0 12px #8dffce; }
                .dialog-close:hover, .copy-btn:hover:not(:disabled) { border-color: rgba(200,250,255,.9); }
                :host(.is-working) .dot { background: #ffd36e; box-shadow: 0 0 14px #ffd36e; animation: pet-pulse .9s infinite; }
                :host(.is-alert) .dot { background: #ff6d8a; box-shadow: 0 0 14px #ff6d8a, 0 0 26px rgba(255,109,138,.5); animation: pet-pulse .55s infinite; }
                :host(.is-alert) .pet { animation: pet-alert .52s ease-in-out 5; }
                @keyframes pet-roam { 0%, 100% { transform: translate(0, 0); } 22% { transform: translate(-7px, -5px); } 48% { transform: translate(4px, -9px); } 72% { transform: translate(8px, -4px); } }
                @keyframes pet-idle-sit { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-3px); } }
                @keyframes pet-step { 0%, 100% { transform: translateY(0) scaleX(1); } 35% { transform: translateY(-5px) scaleX(.98); } 70% { transform: translateY(1px) scaleX(1.02); } }
                @keyframes pet-alert { 0%, 100% { transform: translateX(0); } 25% { transform: translateX(-5px); } 75% { transform: translateX(5px); } }
                @keyframes pet-pulse { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.35); } }
                @media (max-width: 520px) { :host { right: 12px; bottom: 12px; } .dialog { right: 4px; left: auto; bottom: 154px; } }
            </style>
            <div class="dialog" aria-live="polite">
                <div class="dialog-head"><span>墨墨助手</span><button class="dialog-close" type="button" title="收起">×</button></div>
                <div class="dialog-text">我找到工單了，內容已整理好。</div>
                <div class="task" hidden>
                    <div class="task-title"></div>
                    <div class="task-body"></div>
                </div>
                <div class="copy-actions" hidden>
                    <button class="copy-btn copy-main-btn" type="button">複製工單內容</button>
                    <button class="copy-btn copy-time-btn" type="button">複製時間</button>
                </div>
            </div>
            <div class="pet">
                <div class="speech"><span></span></div>
                <button class="body" type="button" title="墨墨：可拖曳、可點擊">
                    <img class="sprite" src="${idleFrames[0]}" alt="墨墨">
                </button>
                <span class="dot"></span>
                <div class="base is-empty"><span class="balance-text">USDT --</span></div>
            </div>`;
        document.documentElement.appendChild(host);

        const body = shadow.querySelector('.body');
        const copyBtn = shadow.querySelector('.copy-main-btn');
        const copyTimeBtn = shadow.querySelector('.copy-time-btn');
        const dialogClose = shadow.querySelector('.dialog-close');

        body.addEventListener('pointerdown', onDragStart);
        body.addEventListener('click', () => {
            if (drag && drag.moved) return;
            if (lastTask) {
                toggleDialog(!isDialogOpen());
                showBubble('可複製工單內容或時間。', true);
                return;
            }
            toggleDialog(false);
            showBubble('墨墨待命中。', true);
        });
        copyBtn.addEventListener('click', () => copyLastTask());
        copyTimeBtn.addEventListener('click', () => copyLastTaskTime());
        dialogClose.addEventListener('click', () => dismissCurrentTask());
        startFrameLoop();
    };

    const getShadow = () => host && host.shadowRoot;
    const isDialogOpen = () => Boolean(getShadow()?.querySelector('.dialog')?.classList.contains('show'));
    const toggleDialog = (show) => {
        const dialog = getShadow()?.querySelector('.dialog');
        if (dialog) dialog.classList.toggle('show', Boolean(show));
    };
    const dismissCurrentTask = () => {
        if (lastTask) autoPresentedTaskKeys.add(taskKey(lastTask));
        renderTask(null);
        concealPet();
    };
    const applyVisibility = () => {
        if (!host) return;
        host.classList.toggle('is-hidden', !visibleReason);
        host.classList.toggle('no-bubble', !state.bubble);
        host.classList.toggle('is-idle', visibleReason === 'idle');
    };
    const currentPetFrames = () => (visibleReason === 'idle' && !host?.classList.contains('is-working')) ? idleFrames : petFrames;
    const revealPet = (reason) => {
        visibleReason = reason || 'task';
        ensurePet();
        applyPosition();
        applyVisibility();
        startFrameLoop();
    };
    const concealPet = () => {
        visibleReason = 'idle';
        window.clearTimeout(hideTimer);
        toggleDialog(false);
        const speech = getShadow()?.querySelector('.speech');
        if (speech) speech.classList.remove('show');
        setMood('');
        applyVisibility();
    };
    const setMood = (mood = '') => {
        if (!host) return;
        window.clearTimeout(moodTimer);
        host.classList.toggle('is-working', mood === 'working');
        host.classList.toggle('is-alert', mood === 'alert');
        const sprite = getShadow()?.querySelector('.sprite');
        if (sprite && mood === 'alert') sprite.src = alertFrame;
        if (sprite && mood !== 'alert') {
            const frames = currentPetFrames();
            sprite.src = frames[frameIndex % frames.length];
        }
        if (mood === 'alert') {
            moodTimer = window.setTimeout(() => {
                if (!host) return;
                host.classList.remove('is-alert');
                const currentSprite = getShadow()?.querySelector('.sprite');
                const frames = currentPetFrames();
                if (currentSprite) currentSprite.src = frames[frameIndex % frames.length];
            }, 4200);
        }
    };
    const showBubble = (text, force = false, mood = '') => {
        if (!host || (!state.bubble && !force)) return;
        const speech = getShadow()?.querySelector('.speech');
        if (!speech) return;
        speech.querySelector('span').textContent = text || '墨墨已整理好。';
        speech.classList.add('show');
        if (mood) setMood(mood);
        window.clearTimeout(hideTimer);
        hideTimer = window.setTimeout(() => speech.classList.remove('show'), mood === 'alert' ? 7000 : 4200);
    };
    const startFrameLoop = () => {
        if (frameTimer) return;
        frameTimer = window.setInterval(() => {
            if (!host || host.classList.contains('is-hidden')) return;
            const sprite = getShadow()?.querySelector('.sprite');
            if (!sprite || host.classList.contains('is-alert')) return;
            const frames = currentPetFrames();
            frameIndex = (frameIndex + 1) % frames.length;
            sprite.src = frames[frameIndex];
        }, 360);
    };
    const formatUsdt2 = (amount) => Number(amount || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    const renderTrcBalance = (balance) => {
        ensurePet();
        const base = getShadow()?.querySelector('.base');
        const text = getShadow()?.querySelector('.balance-text');
        if (!base || !text) return;
        const amount = Number(balance?.amount);
        if (!Number.isFinite(amount)) {
            base.classList.add('is-empty');
            text.textContent = 'USDT --';
            return;
        }
        base.classList.remove('is-empty');
        text.textContent = `${formatUsdt2(amount)} USDT`;
    };

    const renderTask = (task) => {
        ensurePet();
        const shadow = getShadow();
        if (!shadow) return;
        const dialogText = shadow.querySelector('.dialog-text');
        const taskPanel = shadow.querySelector('.task');
        const title = shadow.querySelector('.task-title');
        const body = shadow.querySelector('.task-body');
        const copyActions = shadow.querySelector('.copy-actions');
        const copy = shadow.querySelector('.copy-main-btn');
        const copyTime = shadow.querySelector('.copy-time-btn');
        lastTask = task || null;
        if (!task || !task.copyText) {
            dialogText.textContent = '墨墨提醒。';
            taskPanel.hidden = true;
            copyActions.hidden = true;
            copy.disabled = true;
            copyTime.disabled = true;
            title.textContent = '';
            body.textContent = '';
            return;
        }
        dialogText.textContent = `我找到 ${task.title}，內容已整理好。`;
        taskPanel.hidden = false;
        copyActions.hidden = false;
        copy.disabled = false;
        copyTime.disabled = !task.time;
        title.textContent = task.meta ? `${task.title}｜${task.meta}` : task.title;
        body.textContent = task.copyText.trim();
    };
    const taskKey = (task) => {
        const no = cleanValue(task?.no);
        if (no) return [task?.type || task?.title, no].filter(Boolean).join('|');
        return [task?.title, task?.acc, task?.amt, task?.copyText].filter(Boolean).join('|');
    };
    const resetPresentedTasksForClosedModal = () => {
        if (autoPresentedTaskKeys.size) autoPresentedTaskKeys.clear();
        lastTaskKey = '';
    };
    const showDetectedTask = async (task) => {
        if (!task?.copyText) return null;
        window.clearTimeout(alertTimer);
        const key = taskKey(task);
        const alreadyPresented = autoPresentedTaskKeys.has(key);
        lastTaskKey = key;
        if (alreadyPresented) {
            if (!isDialogOpen()) {
                renderTask(null);
                if (visibleReason === 'task') concealPet();
            }
            return task;
        }
        renderTask(task);
        revealPet('task');
        setMood('working');
        autoPresentedTaskKeys.add(key);
        toggleDialog(true);
        showBubble(`找到${task.title}，內容已整理。`, true, 'working');
        await storageSet({ momoAssistantLastOrder: task });
        return task;
    };
    const showAlert = (text, mood = 'alert') => {
        ensurePet();
        renderTask(null);
        revealPet('alert');
        const dialogText = getShadow()?.querySelector('.dialog-text');
        if (dialogText) dialogText.textContent = text || '墨墨提醒。';
        toggleDialog(true);
        showBubble(text || '墨墨提醒。', true, mood);
        window.clearTimeout(alertTimer);
        alertTimer = window.setTimeout(() => {
            if (visibleReason === 'alert' && !lastTask) concealPet();
        }, 12000);
    };

    const ORDER_LABELS = ['存款單號', '存款单号', '提款單號', '提款单号', '單號', '单号', '訂單號', '订单号', '交易單號', '交易单号', '交易編號', '交易编号', '編號', '编号'];
    const ACCOUNT_LABELS = ['會員帳號', '会员帐号', '會員账号', '会员账号', '帳號', '账号'];
    const METHOD_LABELS = ['銀行', '银行', '收款銀行', '收款银行', '收款方式', '付款方式', '支付方式', '存款方式', '提款方式', '通道名稱', '通道名称', '渠道名稱', '渠道名称', '支付通道'];
    const USDT_HINT_LABELS = ['幣別', '币别', '幣種', '币种', '鏈類型', '链类型', '鏈別', '链别', '協議', '协议', '充值方式', '提款方式', '提領方式', '提领方式'];
    const TIME_LABELS = ['存款時間', '存款时间', '提款時間', '提款时间', '申請日期', '申请日期', '時間', '时间'];
    const STANDARD_DEPOSIT_AMOUNT_LABELS = ['金額', '金额', '實際金額', '实际金额'];
    const STANDARD_WITHDRAW_AMOUNT_LABELS = ['金額', '金额', '實際金額', '实际金额', '實際提領金額', '实际提领金额', '實際出款金額', '实际出款金额'];
    const USDT_DEPOSIT_AMOUNT_LABELS = ['USDT數量', 'USDT 数量', 'USDT数量', 'USDT金額', 'USDT 金額', 'USDT金额', 'U數量', 'U数量', '充值數量', '充值数量', '數量', '数量', '實際金額', '实际金额', '金額', '金额'];
    const USDT_WITHDRAW_AMOUNT_LABELS = ['USDT數量', 'USDT 数量', 'USDT数量', 'USDT金額', 'USDT 金額', 'USDT金额', 'U數量', 'U数量', '提領數量', '提领数量', '提領USDT', '提领USDT', '實際提領金額', '实际提领金额', '實際出款金額', '实际出款金额', '數量', '数量', '實際金額', '实际金额', '金額', '金额'];
    const KNOWN_LABELS = [
        ...ORDER_LABELS,
        ...ACCOUNT_LABELS,
        ...METHOD_LABELS,
        ...USDT_HINT_LABELS,
        ...TIME_LABELS,
        ...STANDARD_DEPOSIT_AMOUNT_LABELS,
        ...STANDARD_WITHDRAW_AMOUNT_LABELS,
        ...USDT_DEPOSIT_AMOUNT_LABELS,
        ...USDT_WITHDRAW_AMOUNT_LABELS,
        '會員資料', '会员资料', '會員ID', '会员ID', '全名', '代理', '優惠資料', '优惠资料', '投注量', '從', '从', '累積打碼量', '累计打码量', '所需打碼量', '所需打码量'
    ];
    const MODAL_SELECTOR = '[role="dialog"], .modal, .modal-dialog, .modal-content, .modal-body, .el-dialog, .ant-modal, .ant-modal-content, .layui-layer, .swal2-popup, .ui-dialog, .ui-dialog-content, .bootbox';
    const ORDER_MARKER_SELECTOR = 'td, th, dt, dd, label, span, p, li, div';
    const normalizeLabel = (text) => clean(text).replace(/[：:]+$/, '');
    const sameLabel = (text, labels) => {
        const normalized = normalizeLabel(text);
        return labels.some(label => normalized === normalizeLabel(label));
    };
    const isKnownLabelText = (text) => {
        const normalized = normalizeLabel(text);
        if (!normalized) return true;
        return KNOWN_LABELS.some(label => normalized === normalizeLabel(label));
    };
    const containsLabelNoise = (text) => {
        const normalized = normalizeLabel(text);
        if (!normalized) return true;
        const hits = KNOWN_LABELS.reduce((sum, label) => sum + (normalized.includes(normalizeLabel(label)) ? 1 : 0), 0);
        return hits >= 2 && !/\b[DW][A-Z0-9][A-Z0-9-]{4,}\b/i.test(text);
    };
    const visibleText = (root) => cleanValue(root?.innerText || root?.textContent || '');
    const isVisibleElement = (el) => {
        if (!el || el === document.body) return true;
        if (typeof Element !== 'undefined' && !(el instanceof Element)) return false;
        const style = window.getComputedStyle ? window.getComputedStyle(el) : null;
        if (style && (style.display === 'none' || style.visibility === 'hidden')) return false;
        const rects = typeof el.getClientRects === 'function' ? el.getClientRects() : null;
        return rects ? rects.length > 0 : visibleText(el).length > 0;
    };
    const hasModalIdentity = (el) => {
        if (!el || el === document.body) return false;
        const role = String(el.getAttribute?.('role') || '').toLowerCase();
        const className = String(el.className || '').toLowerCase();
        return role === 'dialog' || /modal|dialog|layui-layer|swal2|bootbox|ui-dialog|el-dialog|ant-modal/.test(className);
    };
    const isActiveModalRoot = (el) => {
        if (!el || el === document.body || !isVisibleElement(el) || !hasModalIdentity(el)) return false;
        const text = visibleText(el);
        if (!text || text.length < 40 || text.length > 32000) return false;
        if (!/單據處理/.test(text)) return false;
        return /(存款單號|存款单号|提款單號|提款单号|[DW][A-Z0-9][A-Z0-9-]{4,})/i.test(text);
    };
    const closestActiveModal = (el) => {
        let current = el;
        while (current && current !== document.body) {
            if (current.matches?.(MODAL_SELECTOR) && isActiveModalRoot(current)) return current;
            current = current.parentElement;
        }
        return null;
    };
    const cleanFieldValue = (raw, maxLen = 180) => {
        const value = cleanValue(raw).replace(/\s+/g, ' ');
        if (!value || value.length > maxLen || value === '無資料' || value === '--' || value === '-') return '';
        if (isKnownLabelText(value) || containsLabelNoise(value)) return '';
        return value;
    };
    const inlineValue = (raw, labels) => {
        const source = cleanValue(raw);
        if (!source || source.length > 180) return '';
        for (const label of labels) {
            const match = source.match(new RegExp(`^\\s*${escapeRegExp(label)}(?:\\s*[:：-]\\s*|\\s+)(.+)$`, 'i'));
            if (match) return cleanFieldValue(match[1].split(/[\n\r\t|]/)[0]);
        }
        return '';
    };
    const textValue = (text, labels) => {
        const lines = String(text || '').split(/\n+/).map(line => cleanValue(line)).filter(Boolean);
        for (let i = 0; i < lines.length; i += 1) {
            for (const label of labels) {
                const inline = inlineValue(lines[i], [label]);
                if (inline) return inline;
                if (sameLabel(lines[i], [label]) && lines[i + 1]) {
                    const next = cleanFieldValue(lines[i + 1]);
                    if (next) return next;
                }
            }
        }
        const source = String(text || '').slice(0, 6000);
        for (const label of labels) {
            const match = source.match(new RegExp(`${escapeRegExp(label)}(?:\\s*[:：-]\\s*|\\s+)([^\\n\\r\\t|]{1,100})`, 'i'));
            if (match) {
                const value = cleanFieldValue(match[1].split(/\s{2,}/)[0]);
                if (value) return value;
            }
        }
        return '';
    };
    const fieldScope = (el, root) => {
        let current = el;
        while (current && current !== root && current !== document.body) {
            const tag = String(current.tagName || '').toUpperCase();
            const className = String(current.className || '').toLowerCase();
            if (/^(TABLE|DL|FIELDSET|FORM)$/.test(tag) || /table|panel|box|card|detail|info|form|資料|资料|單據|单据/.test(className)) {
                return current;
            }
            current = current.parentElement;
        }
        return root;
    };
    const addRow = (rows, label, value, source = 'dom', scope = null) => {
        const cleanLabel = normalizeLabel(label);
        const cleanRaw = cleanFieldValue(value);
        if (!cleanLabel || !cleanRaw) return;
        rows.push({ label: cleanLabel, raw: cleanRaw, source, scope });
    };
    const collectRows = (root) => {
        const rows = [];
        const trList = Array.from(root.querySelectorAll?.('tr') || []);
        for (const tr of trList) {
            if (!isVisibleElement(tr)) continue;
            const scope = fieldScope(tr, root);
            const cells = Array.from(tr.children || []).filter(cell => /^(TD|TH)$/i.test(cell.tagName || ''));
            for (let i = 0; i < cells.length - 1; i += 2) addRow(rows, visibleText(cells[i]), visibleText(cells[i + 1]), 'tr', scope);
        }
        const dts = Array.from(root.querySelectorAll?.('dt') || []);
        for (const dt of dts) {
            if (!isVisibleElement(dt)) continue;
            const dd = dt.nextElementSibling;
            if (dd && /DD/i.test(dd.tagName || '')) addRow(rows, visibleText(dt), visibleText(dd), 'dl', fieldScope(dt, root));
        }
        const fields = Array.from(root.querySelectorAll?.('td, th, label, span, p, li, div') || []);
        for (const el of fields) {
            if (!isVisibleElement(el)) continue;
            const raw = visibleText(el);
            if (!raw || raw.length > 180) continue;
            const scope = fieldScope(el, root);
            const next = el.nextElementSibling;
            if (next) addRow(rows, raw, visibleText(next), 'sibling', scope);
            for (const labels of [ORDER_LABELS, ACCOUNT_LABELS, METHOD_LABELS, USDT_HINT_LABELS, TIME_LABELS, USDT_DEPOSIT_AMOUNT_LABELS, USDT_WITHDRAW_AMOUNT_LABELS, STANDARD_DEPOSIT_AMOUNT_LABELS, STANDARD_WITHDRAW_AMOUNT_LABELS]) {
                const value = inlineValue(raw, labels);
                if (value) addRow(rows, labels.find(label => raw.toLowerCase().includes(label.toLowerCase())) || raw, value, 'inline', scope);
            }
        }
        return rows;
    };
    const findRows = (rows, labels) => rows.filter(row => sameLabel(row.label, labels) && cleanFieldValue(row.raw));
    const findValue = (rows, labels, fallbackText = '') => findRows(rows, labels)[0]?.raw || textValue(fallbackText, labels);
    const looksLikeTimeValue = (value) => /\d{4}[-/]\d{1,2}[-/]\d{1,2}/.test(value) || /\d{1,2}:\d{2}(?::\d{2})?/.test(value);
    const parseAmount = (raw) => {
        const text = cleanValue(raw);
        const patterns = [
            /(?:USDT|U)\s*[:：]?\s*([+-]?[\d,]+(?:\.\d+)?)/i,
            /([+-]?[\d,]+(?:\.\d+)?)\s*(?:USDT|U)\b/i,
            /([+-]?[\d,]+(?:\.\d+)?)/,
        ];
        for (const pattern of patterns) {
            const match = text.match(pattern);
            if (match) return match[1].replace(/,/g, '');
        }
        return '';
    };
    const amountScore = ({ label, raw }, isUsdt) => {
        const text = `${label} ${raw}`.toUpperCase();
        if (/USDT|TRC|ERC|TRON|\bU\b/.test(text)) return 100;
        if (/提領數量|提领数量|充值數量|充值数量|數量|数量|U數量|U数量/.test(label)) return isUsdt ? 90 : 5;
        if (/實際提領金額|实际提领金额|實際出款金額|实际出款金额/.test(label)) return 80;
        if (/實際金額|实际金额/.test(label)) return 60;
        if (/金額|金额/.test(label)) return 40;
        return 0;
    };
    const findAmount = (rows, labels, fallbackText, isUsdt) => {
        const candidates = findRows(rows, labels)
            .map(row => ({ ...row, amount: parseAmount(row.raw), score: amountScore(row, isUsdt) }))
            .filter(row => row.amount);
        candidates.sort((a, b) => b.score - a.score);
        if (candidates[0]?.amount) return candidates[0].amount;
        return parseAmount(textValue(fallbackText, labels));
    };
    const findTime = (rows, type, scopes = null) => {
        const sourceRows = scopes?.size ? rows.filter(row => row.scope && scopes.has(row.scope)) : rows;
        const fromRows = (labels) => findRows(sourceRows, labels)
            .map(row => cleanFieldValue(row.raw, 80))
            .find(looksLikeTimeValue) || '';
        if (type === 'deposit') {
            return fromRows(['存款時間', '存款时间'])
                || fromRows(['申請日期', '申请日期'])
                || fromRows(['時間', '时间']);
        }
        return fromRows(['提款時間', '提款时间'])
            || fromRows(['申請日期', '申请日期'])
            || fromRows(['時間', '时间']);
    };
    const detectMethod = (raw) => {
        const text = String(raw || '').toUpperCase();
        if (/USDT|TRC|ERC|TRON/.test(text)) return 'USDT';
        if (/ALIPAY|支付寶|支付宝/.test(text)) return '支付寶';
        if (/WECHAT|微信/.test(text)) return '微信';
        if (/ATM/.test(text)) return 'ATM';
        if (/網銀|网银|銀行轉帳|银行转账/.test(text)) return '網銀';
        return cleanValue(raw) || '入款';
    };
    const buildCopyText = (type, isUsdt, data) => {
        const v = (field) => cleanValue(data[field]);
        if (type === 'deposit') return [todayStr(), isUsdt ? 'USDT' : detectMethod(data.method), v('no'), v('acc'), v('amt')].join('\t');
        if (type === 'withdraw') return [todayStr(), isUsdt ? 'USDT 出款' : '出款', v('no'), v('acc'), '', v('amt')].join('\t');
        return '';
    };
    const normalizeOrderNo = (raw) => {
        const match = String(raw || '').match(/\b([DW][A-Z0-9][A-Z0-9-]{4,})\b/i);
        return match ? match[1].trim() : '';
    };
    const orderScopesFor = (rows, no) => {
        const scopes = new Set();
        const normalizedNo = normalizeOrderNo(no);
        rows.forEach(row => {
            const rowNo = normalizeOrderNo(`${row.label} ${row.raw}`);
            if (row.scope && rowNo && (!normalizedNo || rowNo.toUpperCase() === normalizedNo.toUpperCase())) scopes.add(row.scope);
        });
        return scopes;
    };
    const getCandidateRoots = () => {
        const roots = new Set();
        const add = (el) => {
            const modal = closestActiveModal(el) || (isActiveModalRoot(el) ? el : null);
            if (modal) roots.add(modal);
        };
        const markers = Array.from(document.querySelectorAll(ORDER_MARKER_SELECTOR)).filter(el => {
            const text = visibleText(el);
            if (!text || text.length > 180) return false;
            return sameLabel(text, ORDER_LABELS) || inlineValue(text, ORDER_LABELS) || /\b[DW][A-Z0-9][A-Z0-9-]{4,}\b/i.test(text);
        });
        for (const marker of markers) add(marker);
        Array.from(document.querySelectorAll(MODAL_SELECTOR)).forEach(add);
        return Array.from(roots);
    };
    const buildTaskFromRoot = (root) => {
        if (!isActiveModalRoot(root)) return null;
        const rootText = visibleText(root);
        if (!/(存款|提款|出款|提領|提领|充值|訂單|订单|單號|单号|[DW][A-Z0-9][A-Z0-9-]{4,})/i.test(rootText.slice(0, 12000))) return null;
        const rows = collectRows(root);
        let no = normalizeOrderNo(findValue(rows, ORDER_LABELS, rootText)) || normalizeOrderNo(rootText);
        if (!no) return null;
        const prefix = no.charAt(0).toUpperCase();
        if (prefix !== 'D' && prefix !== 'W') return null;
        const type = prefix === 'W' ? 'withdraw' : 'deposit';
        const acc = findValue(rows, ACCOUNT_LABELS, rootText);
        const methodRaw = findValue(rows, METHOD_LABELS, rootText);
        const hintRaw = findValue(rows, USDT_HINT_LABELS, rootText);
        const usdtEvidence = `${methodRaw} ${hintRaw} ${findRows(rows, [...USDT_DEPOSIT_AMOUNT_LABELS, ...USDT_WITHDRAW_AMOUNT_LABELS]).map(row => `${row.label} ${row.raw}`).join(' ')}`;
        const isUsdt = /USDT|TRC20?|ERC20?|TRON|虛擬貨幣|虚拟货币|泰達|泰达/i.test(usdtEvidence);
        const amountLabels = type === 'withdraw'
            ? (isUsdt ? USDT_WITHDRAW_AMOUNT_LABELS : STANDARD_WITHDRAW_AMOUNT_LABELS)
            : (isUsdt ? USDT_DEPOSIT_AMOUNT_LABELS : STANDARD_DEPOSIT_AMOUNT_LABELS);
        const amt = findAmount(rows, amountLabels, rootText, isUsdt);
        const time = findTime(rows, type, orderScopesFor(rows, no));
        if (!isValidValue(acc) || !isValidValue(amt)) return null;
        const data = { no, acc, amt, method: methodRaw, time };
        const title = `${isUsdt ? 'USDT ' : ''}${type === 'withdraw' ? '提款工單' : '存款工單'}`;
        const copyText = buildCopyText(type, isUsdt, data);
        const score = 40
            + (acc ? 20 : 0)
            + (amt ? 20 : 0)
            + (methodRaw ? 8 : 0)
            + (/單據處理|工單|存款|提款/.test(rootText.slice(0, 1000)) ? 8 : 0)
            + (root === document.body ? -18 : 0)
            + Math.max(0, 8 - Math.floor(rootText.length / 3000));
        return {
            score,
            size: rootText.length,
            task: {
                title,
                type,
                isUsdt,
                no,
                acc: cleanFieldValue(acc, 80),
                amt: cleanFieldValue(amt, 40),
                time: cleanFieldValue(time, 80),
                copyText,
                meta: [no, acc, amt && `${amt}${isUsdt ? ' USDT' : ''}`].filter(Boolean).join(' · '),
                updatedAt: Date.now()
            }
        };
    };
    const detectOrderFromPage = () => {
        if (!document.body) return null;
        const best = getCandidateRoots()
            .map(buildTaskFromRoot)
            .filter(Boolean)
            .filter(result => result.score >= 70)
            .sort((a, b) => b.score - a.score || a.size - b.size)[0];
        return best?.task || null;
    };

    const runAutoScan = async () => {
        const task = detectOrderFromPage();
        if (task) return showDetectedTask(task);
        resetPresentedTasksForClosedModal();
        if (visibleReason === 'task') {
            renderTask(null);
            concealPet();
        }
        return null;
    };
    const scheduleAutoScan = (delay = 650) => {
        window.clearTimeout(autoScanTimer);
        autoScanTimer = window.setTimeout(() => runAutoScan().catch(() => {}), delay);
    };
    const bootAutoScan = () => {
        if (scanBooted) return;
        scanBooted = true;
        const start = () => {
            if (!document.body) {
                window.setTimeout(start, 300);
                return;
            }
            ensurePet();
            applyPosition();
            applyVisibility();
            INITIAL_SCAN_DELAYS.forEach(delay => window.setTimeout(() => runAutoScan().catch(() => {}), delay));
            if (!observer) {
                observer = new MutationObserver(() => scheduleAutoScan());
                observer.observe(document.body, { childList: true, subtree: true, characterData: true });
            }
        };
        if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, { once: true });
        else start();
    };

    const copyText = async (text) => {
        const value = cleanValue(text);
        if (!value) return false;
        try {
            await navigator.clipboard.writeText(value);
            return true;
        } catch (error) {
            const textarea = document.createElement('textarea');
            textarea.value = value;
            textarea.setAttribute('readonly', 'readonly');
            textarea.style.cssText = 'position:fixed;left:-9999px;top:-9999px;opacity:0;';
            document.body.appendChild(textarea);
            textarea.select();
            const ok = document.execCommand('copy');
            textarea.remove();
            return ok;
        }
    };
    const copyLastTask = async () => {
        if (!lastTask?.copyText) return;
        const ok = await copyText(lastTask.copyText);
        showBubble(ok ? '已複製。' : '複製失敗，請手動選取內容。', true, ok ? 'working' : 'alert');
    };
    const copyLastTaskTime = async () => {
        if (!lastTask?.time) return;
        const ok = await copyText(lastTask.time);
        showBubble(ok ? '已複製時間。' : '複製失敗，請手動選取時間。', true, ok ? 'working' : 'alert');
    };

    const onDragStart = (event) => {
        if (!host || event.button > 0) return;
        const rect = host.getBoundingClientRect();
        host.style.left = `${rect.left}px`;
        host.style.top = `${rect.top}px`;
        host.style.right = 'auto';
        host.style.bottom = 'auto';
        drag = { startX: event.clientX, startY: event.clientY, left: rect.left, top: rect.top, moved: false };
        event.preventDefault();
        window.addEventListener('pointermove', onDragMove, true);
        window.addEventListener('pointerup', onDragEnd, true);
    };
    const onDragMove = (event) => {
        if (!drag || !host) return;
        const dx = event.clientX - drag.startX;
        const dy = event.clientY - drag.startY;
        if (Math.abs(dx) + Math.abs(dy) > 4) drag.moved = true;
        const width = host.offsetWidth || 162;
        const height = host.offsetHeight || 190;
        host.style.left = `${clamp(drag.left + dx, 8, Math.max(8, window.innerWidth - width - 8))}px`;
        host.style.top = `${clamp(drag.top + dy, 8, Math.max(8, window.innerHeight - height - 8))}px`;
    };
    const onDragEnd = async () => {
        if (!drag || !host) return;
        window.removeEventListener('pointermove', onDragMove, true);
        window.removeEventListener('pointerup', onDragEnd, true);
        const rect = host.getBoundingClientRect();
        state.position = { left: Math.round(rect.left), top: Math.round(rect.top) };
        await storageSet({ [STORE.position]: state.position });
        setTimeout(() => { drag = null; }, 0);
    };
    const applyPosition = () => {
        if (!host) return;
        const pos = state.position;
        if (pos && Number.isFinite(Number(pos.left)) && Number.isFinite(Number(pos.top))) {
            const width = host.offsetWidth || 162;
            const height = host.offsetHeight || 190;
            host.style.left = `${clamp(Number(pos.left), 8, Math.max(8, window.innerWidth - width - 8))}px`;
            host.style.top = `${clamp(Number(pos.top), 8, Math.max(8, window.innerHeight - height - 8))}px`;
            host.style.right = 'auto';
            host.style.bottom = 'auto';
        } else {
            host.style.left = 'auto';
            host.style.top = 'auto';
            host.style.right = '24px';
            host.style.bottom = '24px';
        }
    };

    const loadSettings = async () => {
        const data = await storageGet([STORE.enabled, STORE.bubble, STORE.position, 'trcMonitorBalance']);
        state.enabled = true;
        state.bubble = data[STORE.bubble] !== false;
        state.position = data[STORE.position] || null;
        ensurePet();
        renderTrcBalance(data.trcMonitorBalance);
        applyPosition();
        applyVisibility();
        if (data[STORE.enabled] === false) void storageSet({ [STORE.enabled]: true });
        bootAutoScan();
        scheduleAutoScan(100);
    };
    window.__becPagePetRefresh = () => loadSettings().catch(() => {});

    if (runtimeApi.onMessage && typeof runtimeApi.onMessage.addListener === 'function') {
        runtimeApi.onMessage.addListener((message, sender, sendResponse) => {
            if (!message) return false;
            if (message.action === 'BEC_PET_UPDATE') {
                state.enabled = true;
                state.bubble = message.bubble !== false;
                ensurePet();
                applyPosition();
                applyVisibility();
                runAutoScan().finally(() => sendResponse({ success: true }));
                return true;
            }
            if (message.action === 'BEC_PET_TASK') {
                const currentTask = detectOrderFromPage();
                if (!currentTask || (message.task?.no && currentTask.no !== message.task.no)) {
                    if (!currentTask) resetPresentedTasksForClosedModal();
                    renderTask(null);
                    concealPet();
                    sendResponse({ success: false, ignored: true });
                    return true;
                }
                showDetectedTask(currentTask).finally(() => sendResponse({ success: true }));
                return true;
            }
            if (message.action === 'BEC_PET_SAY') {
                showAlert(String(message.text || '墨墨提醒。'), message.mood || 'alert');
                sendResponse({ success: true });
                return true;
            }
            return false;
        });
    }

    if (storageEvents && typeof storageEvents.addListener === 'function') {
        storageEvents.addListener((changes, area) => {
            if (area !== 'local') return;
            let needsApply = false;
            if (changes[STORE.enabled]) { state.enabled = true; needsApply = true; }
            if (changes[STORE.bubble]) { state.bubble = changes[STORE.bubble].newValue !== false; needsApply = true; }
            if (changes[STORE.position]) { state.position = changes[STORE.position].newValue || null; needsApply = true; }
            if (needsApply) {
                ensurePet();
                applyPosition();
                applyVisibility();
                scheduleAutoScan(100);
            }
            if (changes.trcMonitorLastAlert && changes.trcMonitorLastAlert.newValue) {
                showAlert(changes.trcMonitorLastAlert.newValue.text || 'TRC 入款提醒。', 'alert');
            }
            if (changes.trcMonitorBalance) {
                renderTrcBalance(changes.trcMonitorBalance.newValue);
            }
        });
    }

    window.addEventListener('resize', () => applyPosition(), { passive: true });
    loadSettings().catch(() => {});
})();
