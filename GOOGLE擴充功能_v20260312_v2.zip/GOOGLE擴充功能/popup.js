document.addEventListener('DOMContentLoaded', () => {
    // --- 導覽切換 ---
    const navBtns = document.querySelectorAll('.nav-btn');
    const tabPanes = document.querySelectorAll('.tab-pane');

    navBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            navBtns.forEach(b => b.classList.remove('active'));
            tabPanes.forEach(p => p.classList.remove('active'));
            btn.classList.add('active');
            const target = document.getElementById(btn.dataset.target);
            if (target) target.classList.add('active');
        });
    });

    // --- 複製功能 ---
    function copyToClipboard(text) {
        if (!text || text === "無資料") return;
        navigator.clipboard.writeText(text.trim()).then(() => {
            const toast = document.getElementById('toast');
            toast.classList.add('show');
            setTimeout(() => toast.classList.remove('show'), 1500);
        });
    }

    // ================= 原有功能綁定 =================
    document.getElementById('btn-copy-dep-combined').addEventListener('click', () => {
        copyToClipboard(`${document.getElementById('dep-no').value}\t${document.getElementById('dep-acc').value}\t${document.getElementById('dep-amt').value}`);
    });
    document.getElementById('btn-copy-dep-time-only').addEventListener('click', () => {
        copyToClipboard(document.getElementById('dep-time').value);
    });
    document.getElementById('btn-copy-wd-full-combined').addEventListener('click', () => {
        const d = new Date();
        const today = `${d.getFullYear()}/${String(d.getMonth()+1).padStart(2,'0')}/${String(d.getDate()).padStart(2,'0')}`;
        copyToClipboard(`${today}\t出款\t${document.getElementById('wd-no').value}\t${document.getElementById('wd-acc').value}\t\t${document.getElementById('wd-amt').value}`);
    });

    // ================= USDT 功能綁定 =================
    document.getElementById('btn-copy-usdt-dep-combined').addEventListener('click', () => {
        copyToClipboard(`${document.getElementById('usdt-dep-no').value}\t${document.getElementById('usdt-dep-acc').value}\t${document.getElementById('usdt-dep-amt').value}`);
    });
    document.getElementById('btn-copy-usdt-dep-time-only').addEventListener('click', () => {
        copyToClipboard(document.getElementById('usdt-dep-time').value);
    });
    document.getElementById('btn-copy-usdt-wd-combined').addEventListener('click', () => {
        const d = new Date();
        const today = `${d.getFullYear()}/${String(d.getMonth()+1).padStart(2,'0')}/${String(d.getDate()).padStart(2,'0')}`;
        copyToClipboard(`${today}\t出款\t${document.getElementById('usdt-wd-no').value}\t${document.getElementById('usdt-wd-acc').value}\t\t${document.getElementById('usdt-wd-amt').value}`);
    });

    // ================= 新增：富鼎出 功能綁定 =================
    document.getElementById('btn-copy-fuding').addEventListener('click', () => {
        const no = document.getElementById('fd-no').value;
        const bName = document.getElementById('fd-bank-name').value;
        const bCode = document.getElementById('fd-bank-code').value;
        const acc = document.getElementById('fd-acc').value;
        const branch = document.getElementById('fd-branch').value;
        const amt = document.getElementById('fd-amt').value;

        // 富鼎專屬排版，完全依照您的格式要求
        const template = `【代付確認提單】\n交易編號 ${no}\n銀行名稱 ${bName}\n銀行代碼 ( ${bCode} )\n銀行帳號 ${acc}\n分行 ${branch}\n金額 ${amt}`;
        copyToClipboard(template);
    });

    // --- 資料讀取核心 ---
    async function handleFetch(statusId, type, isUsdt = false) {
        const statusEl = document.getElementById(statusId);
        statusEl.textContent = "SCANNING...";
        
        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            const results = await chrome.scripting.executeScript({
                target: { tabId: tab.id, allFrames: true },
                func: grabPageData,
                args: [type, isUsdt]
            });

            // 初始化所有可能用到的欄位
            let data = { no: '', acc: '', amt: '', time: '', bankName: '', bankCode: '', branch: '' };
            results.forEach(res => {
                if (res.result) {
                    Object.keys(res.result).forEach(k => { 
                        if (res.result[k] && (!data[k] || data[k] === '')) data[k] = res.result[k]; 
                    });
                }
            });

            if (type === 'fuding') {
                // 處理富鼎介面賦值
                document.getElementById('fd-no').value = data.no || '無資料';
                document.getElementById('fd-bank-name').value = data.bankName || '無資料';
                document.getElementById('fd-bank-code').value = data.bankCode || '無資料';
                document.getElementById('fd-acc').value = data.acc || '無資料';
                document.getElementById('fd-branch').value = data.branch || '無資料';
                // 將數字轉為千分位，如 18000 -> 18,000
                document.getElementById('fd-amt').value = data.amt ? Number(data.amt).toLocaleString() : '無資料';
            } else {
                // 處理一般與 USDT 介面賦值
                let p = '';
                if (type === 'deposit') p = isUsdt ? 'usdt-dep' : 'dep';
                else p = isUsdt ? 'usdt-wd' : 'wd';

                document.getElementById(`${p}-no`).value = data.no || '無資料';
                document.getElementById(`${p}-acc`).value = data.acc || '無資料';
                document.getElementById(`${p}-amt`).value = data.amt || '無資料';
                if(type === 'deposit') document.getElementById(`${p}-time`).value = data.time || '無資料';
            }

            statusEl.textContent = data.no ? "DATA UNLOCKED" : "DATA NOT FOUND";
            statusEl.style.color = data.no ? "#ffb347" : "#ff4d4d";
        } catch (e) {
            statusEl.textContent = "ERROR";
        }
    }

    // 注入網頁的抓取腳本
    function grabPageData(type, isUsdt) {
        const tds = Array.from(document.querySelectorAll('td'));
        
        const getVal = (labels, isAmountField = false) => {
            for (let td of tds) {
                const txt = td.innerText.replace(/\s+/g, '');
                // 精確匹配標籤
                if (labels.some(l => txt === l || txt === l + ':' || txt === l + '：')) {
                    const next = td.nextElementSibling;
                    if (next && next.tagName === 'TD') {
                        let rawVal = next.innerText.trim();
                        
                        // 金額欄位過濾
                        if (isAmountField) {
                            if (isUsdt) {
                                const usdtMatch = rawVal.match(/([\d,.]+)[^\d]*USDT/i);
                                if (usdtMatch) return usdtMatch[1].replace(/,/g, '');
                                continue;
                            } else {
                                if (rawVal.toUpperCase().includes('USDT')) {
                                    if (type === 'withdraw' || type === 'fuding') continue;
                                    const normalMatch = rawVal.match(/[\d,.]+/);
                                    return normalMatch ? normalMatch[0].replace(/,/g, '') : rawVal;
                                } else {
                                    const normalMatch = rawVal.match(/[\d,.]+/);
                                    return normalMatch ? normalMatch[0].replace(/,/g, '') : rawVal;
                                }
                            }
                        }
                        return rawVal;
                    }
                }
            }
            return '';
        };

        if (type === 'deposit') {
            return {
                no: getVal(['存款單號', '單號']),
                acc: getVal(['會員帳號', '帳號']),
                amt: getVal(['金額', '實際金額'], true),
                time: getVal(['存款時間', '申請日期', '時間'])
            };
        } else if (type === 'withdraw') {
            return {
                no: getVal(['提款單號', '單號']),
                acc: getVal(['會員帳號', '帳號']),
                amt: getVal(['金額', '實際金額', '實際提領金額'], true)
            };
        } else if (type === 'fuding') {
            // 【新增：富鼎出 專屬抓取邏輯】
            const rawBank = getVal(['銀行']); // 抓到如: "( 103 ) 臺灣新光商銀"
            let bankCode = '';
            let bankName = rawBank;
            
            // 使用正則拆解銀行代碼與名稱
            const bankMatch = rawBank.match(/\(\s*(\d+)\s*\)\s*(.*)/);
            if (bankMatch) {
                bankCode = bankMatch[1];       // 抓取代碼 (例如: 103)
                bankName = bankMatch[2].trim(); // 抓取名稱 (例如: 臺灣新光商銀)
            }

            return {
                no: getVal(['提款單號', '單號']),
                bankCode: bankCode,
                bankName: bankName,
                branch: getVal(['分行']),
                acc: getVal(['帳號']), // 利用嚴格比對，跳過"會員帳號"，直接精準命中"帳號"
                amt: getVal(['金額', '實際金額', '實際提領金額'], true)
            };
        }
    }

    // ================= 綁定抓取按鈕 =================
    document.getElementById('btn-fetch-deposit').addEventListener('click', () => handleFetch('dep-status', 'deposit', false));
    document.getElementById('btn-fetch-withdraw').addEventListener('click', () => handleFetch('wd-status', 'withdraw', false));
    
    document.getElementById('btn-fetch-usdt-dep').addEventListener('click', () => handleFetch('usdt-dep-status', 'deposit', true));
    document.getElementById('btn-fetch-usdt-wd').addEventListener('click', () => handleFetch('usdt-wd-status', 'withdraw', true));
    
    // 新增：綁定富鼎出抓取
    document.getElementById('btn-fetch-fuding').addEventListener('click', () => handleFetch('fuding-status', 'fuding', false));
});