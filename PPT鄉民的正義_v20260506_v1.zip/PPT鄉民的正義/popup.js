document.addEventListener('DOMContentLoaded', () => {
    const $ = (sel, ctx = document) => ctx.querySelector(sel);
    const $$ = (sel, ctx = document) => [...ctx.querySelectorAll(sel)];

    const todayStr = () => {
        const d = new Date();
        return `${d.getFullYear()}/${String(d.getMonth() + 1).padStart(2, '0')}/${String(d.getDate()).padStart(2, '0')}`;
    };

    function showToast(msg = 'COPIED') {
        const t = $('#toast');
        t.textContent = msg;
        t.classList.add('show');
        setTimeout(() => t.classList.remove('show'), 1500);
    }

    async function copyText(text) {
        if (!text || text === '無資料') return;
        await navigator.clipboard.writeText(text.trim());
        showToast();
    }

    function switchTab(targetId) {
        $$('.nav-btn').forEach(b => b.classList.remove('active'));
        $$('.tab-pane').forEach(p => p.classList.remove('active'));
        const btn = $(`.nav-btn[data-target="${targetId}"]`);
        const pane = $(`#${targetId}`);
        if (btn) btn.classList.add('active');
        if (pane) pane.classList.add('active');
        return pane;
    }

    $('.nav-container').addEventListener('click', (e) => {
        const btn = e.target.closest('.nav-btn');
        if (btn) switchTab(btn.dataset.target);
    });

    const fieldVal = (pane, field) => $(`input[data-field="${field}"]`, pane)?.value || '';

    $('.content').addEventListener('click', (e) => {
        const btn = e.target.closest('.js-copy');
        if (!btn) return;

        const pane = btn.closest('.tab-pane');
        const key = btn.dataset.copy;
        let text = '';

        switch (key) {
            case 'deposit-format': {
                let method = fieldVal(pane, 'method');
                if (!method || method === '無資料') method = '入款';
                text = [todayStr(), method, fieldVal(pane, 'no'), fieldVal(pane, 'acc'), fieldVal(pane, 'amt')].join('\t');
                break;
            }
            case 'usdt-deposit-format': {
                text = [todayStr(), '入款', fieldVal(pane, 'no'), fieldVal(pane, 'acc'), fieldVal(pane, 'amt')].join('\t');
                break;
            }
            case 'withdraw-format': {
                text = [todayStr(), '出款', fieldVal(pane, 'no'), fieldVal(pane, 'acc'), '', fieldVal(pane, 'amt')].join('\t');
                break;
            }
            case 'fuding-template': {
                const v = (f) => fieldVal(pane, f);
                text = [
                    '【代付確認提單】',
                    `交易編號 ${v('no')}`,
                    `銀行名稱 ${v('bankName')}`,
                    `銀行代碼 ( ${v('bankCode')} )`,
                    `銀行帳號 ${v('acc')}`,
                    `分行 ${v('branch')}`,
                    `金額 ${v('amt')}`
                ].join('\n');
                break;
            }
            case 'time': {
                text = fieldVal(pane, 'time');
                break;
            }
            default: {
                text = key.split(',').map(f => fieldVal(pane, f)).join('\t');
            }
        }
        copyText(text);
    });

    $('.content').addEventListener('click', async (e) => {
        const btn = e.target.closest('.js-fetch');
        if (!btn) return;
        const pane = btn.closest('.tab-pane');
        await fetchAndFill(pane);
    });

    async function fetchAndFill(pane) {
        const { type, usdt } = pane.dataset;
        const isUsdt = usdt === 'true';
        const pill = $('.js-status', pane);

        pill.textContent = 'SCANNING';
        pill.className = 'pill js-status scanning';

        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            
            if (!tab || !tab.url || !tab.url.startsWith('http')) {
                pill.textContent = 'INVALID PAGE';
                pill.className = 'pill js-status error';
                return null;
            }

            const results = await chrome.scripting.executeScript({
                target: { tabId: tab.id, allFrames: true },
                func: grabPageData,
                args: [type, isUsdt]
            });

            const data = {};
            for (const { result } of results) {
                if (!result) continue;
                for (const [k, v] of Object.entries(result)) {
                    if (v && !data[k]) data[k] = v;
                }
            }

            if (type === 'fuding' && data.amt) {
                data.amt = Number(data.amt).toLocaleString();
            }

            $$('input[data-field]', pane).forEach(input => {
                input.value = data[input.dataset.field] || '無資料';
            });

            const ok = !!data.no;
            pill.textContent = ok ? 'ONLINE' : 'NO DATA';
            pill.className = 'pill js-status ' + (ok ? 'online' : 'error');

            return data;
        } catch (err) {
            pill.textContent = 'ERROR';
            pill.className = 'pill js-status error';
            return null;
        }
    }

    async function autoDetect() {
        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            if (!tab || !tab.url || !tab.url.startsWith('http')) return;

            const probeResults = await chrome.scripting.executeScript({
                target: { tabId: tab.id, allFrames: true },
                func: probePageType
            });

            let orderNo = '';
            let bankRaw = '';
            for (const { result } of probeResults) {
                if (!result) continue;
                if (result.orderNo && !orderNo) orderNo = result.orderNo;
                if (result.bankRaw && !bankRaw) bankRaw = result.bankRaw;
            }

            const prefix = orderNo.charAt(0).toUpperCase();
            const bankUpper = bankRaw.toUpperCase();

            let targetTab = 'tab-deposit';

            if (prefix === 'D') {
                if (bankUpper.includes('USDT') || bankUpper.includes('TRC')) targetTab = 'tab-usdt-deposit';
                else targetTab = 'tab-deposit';
            } else if (prefix === 'W') {
                if (bankUpper.includes('USDT') || bankUpper.includes('TRC')) targetTab = 'tab-usdt-withdraw';
                else targetTab = 'tab-withdraw';
            }

            const pane = switchTab(targetTab);
            if (pane) await fetchAndFill(pane);
        } catch (err) {}
    }

    function probePageType() {
        const tds = Array.from(document.querySelectorAll('td'));
        let orderNo = '';
        let bankRaw = '';
        const orderLabels = ['存款單號', '提款單號', '單號'];
        const bankLabels = ['銀行', '收款銀行', '收款方式', '付款方式', '支付方式', '存款方式', '通道名稱'];

        for (const td of tds) {
            const txt = td.innerText.replace(/[\s\u200B-\u200D\uFEFF]+/g, '');
            if (!txt || txt.length > 20) continue; 
            if (!orderNo && orderLabels.some(l => txt === l || txt === l + ':' || txt === l + '：')) {
                const next = td.nextElementSibling;
                if (next?.tagName === 'TD') orderNo = next.innerText.trim();
            }
            if (!bankRaw && bankLabels.some(l => txt === l || txt === l + ':' || txt === l + '：')) {
                const next = td.nextElementSibling;
                if (next?.tagName === 'TD') bankRaw = next.innerText.trim();
            }
            if (orderNo && bankRaw) break;
        }
        return { orderNo, bankRaw };
    }

    function grabPageData(type, isUsdt) {
        const tds = Array.from(document.querySelectorAll('td'));

        const getVal = (labels, isAmount = false) => {
            for (const td of tds) {
                const txt = td.innerText.replace(/[\s\u200B-\u200D\uFEFF]+/g, '');
                if (!txt || txt.length > 20) continue;

                if (!labels.some(l => txt === l || txt === l + ':' || txt === l + '：')) continue;

                const next = td.nextElementSibling;
                if (!next || next.tagName !== 'TD') continue;
                const raw = next.innerText.trim();

                if (!raw) continue;
                if (!isAmount) return raw;

                if (isUsdt) {
                    const m = raw.match(/([\d,.]+)[^\d]*USDT/i);
                    if (m) return m[1].replace(/,/g, '');
                    continue; 
                }

                if (raw.toUpperCase().includes('USDT') && (type !== 'withdraw' && type !== 'fuding')) continue;
                
                const numMatch = raw.match(/[\d,.]+/);
                return numMatch ? numMatch[0].replace(/,/g, '') : raw;
            }
            return '';
        };

        function detectMethod() {
            const methodRules = [
                [['支付寶', 'ALIPAY'], '支付寶'],
                [['微信', 'WECHAT', 'WXPAY'], '微信'],
                [['超商', '便利商店', 'CVS', 'IBON'], '超商'],
                [['銀聯', 'UNIONPAY', 'CUP'], '銀聯'],
                [['LINEPAY', 'LINE PAY'], 'LinePay'],
                [['JKOPAY', '街口'], '街口支付'],
                [['USDT', 'TRC', 'ERC', '虛擬貨幣'], 'USDT'],
                [['網銀', '銀行轉帳'], '網銀'],
                [['ATM'], 'ATM'],
            ];

            function matchMethod(text) {
                const upper = text.toUpperCase();
                for (const [keywords, label] of methodRules) {
                    if (keywords.some(kw => upper.includes(kw.toUpperCase()))) return label;
                }
                return '';
            }

            const bankLabels = ['銀行', '收款銀行', '收款方式', '付款方式', '支付方式', '存款方式', '通道名稱'];
            for (const td of tds) {
                const txt = td.innerText.replace(/[\s\u200B-\u200D\uFEFF]+/g, '');
                if (!txt || txt.length > 15) continue; 
                
                if (!bankLabels.some(l => txt === l || txt === l + ':' || txt === l + '：')) continue;

                const next = td.nextElementSibling;
                if (!next || next.tagName !== 'TD') continue;
                const val = next.innerText.trim();
                if (!val) continue; 
                
                const m = matchMethod(val);
                if (m) return m;
                return val; 
            }
            return matchMethod(tds.map(td => td.innerText).join(' '));
        }

        const FIELD_MAP = {
            deposit: {
                no:     ['存款單號', '單號'],
                acc:    ['會員帳號', '帳號'],
                amt:    [['金額', '實際金額'], true],
                method: () => detectMethod(),
                time:   () => getVal(['存款時間']) || getVal(['申請日期']) || getVal(['時間'])
            },
            withdraw: {
                no:  ['提款單號', '單號'],
                acc: ['會員帳號', '帳號'],
                amt: [['金額', '實際金額', '實際提領金額'], true]
            },
            fuding: {
                no:     ['提款單號', '單號'],
                acc:    ['帳號'],
                amt:    [['金額', '實際金額', '實際提領金額'], true],
                branch: ['分行'],
                _bank:  ['銀行']
            }
        };

        const cfg = FIELD_MAP[type];
        if (!cfg) return null;

        const result = {};
        for (const [key, def] of Object.entries(cfg)) {
            if (key.startsWith('_')) continue;
            if (typeof def === 'function') {
                result[key] = def();
            } else if (Array.isArray(def) && def[1] === true) {
                result[key] = getVal(def[0], true);
            } else {
                result[key] = getVal(def);
            }
        }

        if (type === 'fuding') {
            const rawBank = getVal(cfg._bank);
            const m = rawBank.match(/\(\s*(\d+)\s*\)\s*(.*)/);
            result.bankCode = m ? m[1] : '';
            result.bankName = m ? m[2].trim() : rawBank;
        }

        return result;
    }

    const startBtn = $('#startBtn');
    const stopBtn = $('#stopBtn');
    const logBtn = $('#logBtn');
    const exportBtn = $('#exportBtn');
    const accountList = $('#accountList');
    const accCount = $('#accCount');
    const clearListBtn = $('#clearListBtn');
    const resultBody = $('#resultBody');
    const statusTextAuto = $('.js-status-auto');
    const debugPanel = $('#debugPanel');
    const alertPanel = $('#alertPanel');
    const logModal = $('#logModal');
    const closeLogBtn = $('#closeLogBtn');
    const intervalBtns = $$('.int-btn');
    const uploadJsonBtn = $('#uploadJsonBtn');
    const jsonFileInput = $('#jsonFileInput');

    let selectedInterval = 0;
    
    const updateAccCount = () => {
        const lines = accountList.value.split('\n').filter(line => line.trim() !== '');
        accCount.textContent = `(${lines.length})`;
    };
    accountList.addEventListener('input', updateAccCount);

    clearListBtn.addEventListener('click', () => {
        accountList.value = '';
        updateAccCount();
        showToast('CLEARED');
    });

    intervalBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            intervalBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            selectedInterval = parseInt(btn.dataset.val, 10);
        });
    });

    logBtn.addEventListener('click', () => { logModal.style.display = 'flex'; });
    closeLogBtn.addEventListener('click', () => { logModal.style.display = 'none'; });

    exportBtn.addEventListener('click', () => {
        chrome.storage.local.get(['results'], (data) => {
            const res = data.results || [];
            if (res.length === 0) {
                showToast('NO DATA TO EXPORT');
                return;
            }

            const getRawPayoutText = (valStr) => {
                if (!valStr || valStr === 'Not Found' || valStr === '—' || valStr === '查無資料' || valStr === 'No Data') return '—';
                const num = parseFloat(valStr.replace(/,/g, ''));
                if (isNaN(num) || num === 0) return '0';
                const fmt = Math.abs(num).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
                return num > 0 ? `贏${fmt}` : `輸${fmt}`;
            };

            const dateStr = todayStr(); 
            let content = '\ufeff'; 
            
            res.forEach(r => {
                const payText = getRawPayoutText(r.payout);
                const timeText = r.time || '-';
                const line = `帳號:${r.account} 錢包餘額:${r.balance} 輸贏:${payText} 更新時間:${dateStr} ${timeText}`;
                content += `"${line}"\n`;
            });
            
            const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `BEC_DATA_${dateStr.replace(/\//g, '')}.csv`;
            a.click();
            URL.revokeObjectURL(url);
            showToast('EXPORT COMPLETE');
        });
    });

    uploadJsonBtn.addEventListener('click', () => {
        jsonFileInput.click();
    });

    jsonFileInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (event) => {
            const content = event.target.result.trim();
            let lines = [];
            
            try {
                const data = JSON.parse(content);
                if (Array.isArray(data)) {
                    lines = data.map(item => {
                        const acc = item.name || item.account || '';
                        const limit = item.limit !== undefined ? item.limit : '';
                        const date = item.date !== undefined ? item.date : '0';
                        if (!acc) return null;
                        return `${acc},${limit},${date}`;
                    }).filter(Boolean);
                }
            } catch (err) {
                lines = content.split('\n')
                    .map(line => line.trim())
                    .filter(line => line.length > 0 && line.includes(',')); 
            }

            if (lines.length > 0) {
                accountList.value = lines.join('\n');
                updateAccCount();
                showToast('DATA LOADED');
            } else {
                showToast('INVALID FORMAT');
            }
            jsonFileInput.value = ''; 
        };
        reader.readAsText(file);
    });

    const formatPayout = (valStr) => {
        if (!valStr || valStr === 'Not Found' || valStr === '—' || valStr === '查無資料' || valStr === 'No Data')
            return `<span style="color:var(--text-3)">${valStr || '—'}</span>`;
        const num = parseFloat(valStr.replace(/,/g, ''));
        if (isNaN(num) || num === 0) return `<span style="color:var(--text-2)">0</span>`;
        const fmt = Math.abs(num).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        return num > 0
            ? `<span style="color:var(--border-blue); font-weight:bold;">贏 ${fmt}</span>`
            : `<span style="color:var(--text-red); font-weight:bold;">輸 ${fmt}</span>`;
    };

    const updateUIAuto = () => {
        chrome.storage.local.get(['results', 'isRunning', 'isWaiting', 'currentIndex', 'accounts', 'debugLog'], (data) => {
            resultBody.innerHTML = '';
            let alertsHTML = '';
            
            (data.results || []).forEach(res => {
                const tr = document.createElement('tr');
                if (res.exceeded) tr.style.backgroundColor = 'rgba(243, 156, 18, 0.15)';
                
                const balColor = res.balance?.startsWith('Error') || res.balance?.startsWith('錯誤') ? 'color:var(--text-red)' : 'color:var(--text-2)';
                tr.innerHTML = `
                    <td style="padding:4px; color:var(--text-1);">${res.account}</td>
                    <td style="padding:4px; ${balColor}">${res.balance}</td>
                    <td style="padding:4px; text-align:right;">${formatPayout(res.payout)}</td>`;
                resultBody.appendChild(tr);

                if (res.exceeded) {
                    alertsHTML += `<div style="margin-bottom:4px;">! ALERT: ${res.account} [${res.payout}]</div>`;
                }
            });

            if (alertsHTML) {
                alertPanel.innerHTML = alertsHTML;
                alertPanel.style.display = 'block';
            } else {
                alertPanel.style.display = 'none';
                alertPanel.innerHTML = '';
            }

            debugPanel.innerHTML = '';
            (data.debugLog || []).forEach(line => {
                const div = document.createElement('div');
                const isErr  = line.toLowerCase().includes('error') || line.includes('錯誤');
                const isWarn = line.toLowerCase().includes('warning') || line.includes('警告') || line.includes('alert') || line.includes('略過');
                div.style.color = isErr ? 'var(--text-red)' : isWarn ? 'var(--border-hot)' : 'var(--border-base)';
                div.textContent = line;
                debugPanel.appendChild(div);
            });
            debugPanel.scrollTop = debugPanel.scrollHeight;

            if (data.isRunning) {
                if (data.isWaiting) {
                    statusTextAuto.textContent = 'WAITING';
                    statusTextAuto.className = 'pill js-status-auto scanning';
                } else {
                    statusTextAuto.textContent = `RUNNING ${(data.currentIndex || 0) + 1}/${data.accounts?.length || 0}`;
                    statusTextAuto.className = 'pill js-status-auto online';
                }
                startBtn.disabled  = true;
                stopBtn.disabled = false;
            } else {
                statusTextAuto.textContent = 'STANDBY';
                statusTextAuto.className = 'pill js-status-auto';
                startBtn.disabled  = false;
                stopBtn.disabled = true;
            }
        });
    };

    updateUIAuto();
    setInterval(updateUIAuto, 800);

    const TARGET_URL = 'https://b9a9vnfik.becgame88168.com/index/Home';

    startBtn.addEventListener('click', () => {
        const rawLines = accountList.value.split('\n').filter(line => line.trim() !== '');
        if (!rawLines.length) return;

        const accounts = [];
        for (const line of rawLines) {
            const parts = line.split(',');
            if (parts.length >= 2) {
                const accName = parts[0].trim();
                const limitVal = parseFloat(parts[1].trim());
                const dateVal = parts.length >= 3 ? parts[2].trim() : '0';
                
                const finalLimit = (isNaN(limitVal) || limitVal <= 0) ? null : limitVal * 10000;

                accounts.push({
                    name: accName, limit: finalLimit, date: dateVal
                });
            }
        }

        if (!accounts.length) return;

        startBtn.disabled = true;
        statusTextAuto.textContent = 'INIT...';
        statusTextAuto.className = 'pill js-status-auto scanning';

        chrome.storage.local.set({
            accounts, currentIndex: 0, adaptiveDelay: 800, intervalMin: selectedInterval,
            isRunning: true, isWaiting: false, step: 'SEARCH', startUrl: TARGET_URL, results: [], debugLog: []
        }, () => {
            chrome.runtime.sendMessage({ action: 'CREATE_BACKGROUND_WINDOW', url: TARGET_URL, incognito: true }, (resp) => {
                if (resp?.success) {
                    updateUIAuto();
                } else {
                    chrome.storage.local.set({ isRunning: false, isWaiting: false });
                    statusTextAuto.textContent = 'ERROR';
                    statusTextAuto.className = 'pill js-status-auto error';
                    startBtn.disabled = false;
                    stopBtn.disabled = true;
                    
                    if (resp?.error === 'INCOGNITO_DISABLED') {
                        showToast('REQUIRE INCOGNITO PERMISSION');
                    } else {
                        showToast('EXECUTION FAILED: ' + (resp?.error || 'UNKNOWN'));
                    }
                }
            });
        });
    });

    stopBtn.addEventListener('click', () => {
        chrome.storage.local.set({ isRunning: false, isWaiting: false }, () => {
            chrome.runtime.sendMessage({ action: 'CLOSE_BACKGROUND_WINDOW' }, updateUIAuto);
        });
    });

    autoDetect();
});