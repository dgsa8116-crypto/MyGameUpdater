document.addEventListener('DOMContentLoaded', () => {
    // 導覽切換
    const navBtns = document.querySelectorAll('.nav-btn');
    const tabPanes = document.querySelectorAll('.tab-pane');
    navBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            navBtns.forEach(b => b.classList.remove('active'));
            tabPanes.forEach(p => p.classList.remove('active'));
            btn.classList.add('active');
            document.getElementById(btn.dataset.target).classList.add('active');
        });
    });

    // 複製功能
    function copyToClipboard(text) {
        if (!text || text === "無資料") return;
        navigator.clipboard.writeText(text.trim()).then(() => {
            const toast = document.getElementById('toast');
            toast.classList.add('show');
            setTimeout(() => toast.classList.remove('show'), 1500);
        });
    }

    // 按鈕監聽
    document.getElementById('btn-copy-dep-combined').addEventListener('click', () => {
        const no = document.getElementById('dep-no').value;
        const acc = document.getElementById('dep-acc').value;
        const amt = document.getElementById('dep-amt').value;
        if(no && acc && amt) copyToClipboard(`${no}\t${acc}\t${amt}`);
    });

    document.getElementById('btn-copy-dep-time-only').addEventListener('click', () => {
        copyToClipboard(document.getElementById('dep-time').value);
    });

    document.getElementById('btn-copy-wd-full-combined').addEventListener('click', () => {
        const no = document.getElementById('wd-no').value;
        const acc = document.getElementById('wd-acc').value;
        const amt = document.getElementById('wd-amt').value;
        const today = new Date().toLocaleDateString('zh-TW', {year:'numeric', month:'2-digit', day:'2-digit'}).replace(/\//g, '/');
        if(no && acc && amt) copyToClipboard(`${today}\t出款\t${no}\t${acc}\t\t${amt}`);
    });

    // 讀取資料
    async function handleFetch(statusId, type) {
        const statusEl = document.getElementById(statusId);
        statusEl.textContent = "SCANNING...";
        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            const results = await chrome.scripting.executeScript({
                target: { tabId: tab.id, allFrames: true },
                func: grabPageData,
                args: [type]
            });

            let data = { no: '', acc: '', amt: '', time: '' };
            results.forEach(res => {
                if (res.result) {
                    Object.keys(res.result).forEach(k => { if (res.result[k]) data[k] = res.result[k]; });
                }
            });

            const p = type === 'deposit' ? 'dep' : 'wd';
            document.getElementById(`${p}-no`).value = data.no || '無資料';
            document.getElementById(`${p}-acc`).value = data.acc || '無資料';
            document.getElementById(`${p}-amt`).value = data.amt || '無資料';
            if(type === 'deposit') document.getElementById('dep-time').value = data.time || '無資料';

            statusEl.textContent = data.no ? "DATA UNLOCKED" : "DATA NOT FOUND";
            statusEl.style.color = data.no ? "#ffb347" : "#ff4d4d";
        } catch (e) { statusEl.textContent = "ERROR"; }
    }

    function grabPageData(type) {
        const tds = Array.from(document.querySelectorAll('td'));
        const getVal = (labels) => {
            for (let td of tds) {
                const txt = td.innerText.replace(/\s+/g, '');
                if (labels.some(l => txt.includes(l))) {
                    const next = td.nextElementSibling;
                    if (next && next.tagName === 'TD') return next.innerText.trim();
                }
            }
            return '';
        };

        if(type === 'deposit') {
            return {
                no: getVal(['存款單號', '單號']),
                acc: getVal(['會員帳號', '帳號']),
                amt: getVal(['金額', '實際金額']).replace(/[^0-9.]/g, ''),
                time: getVal(['存款時間', '時間'])
            };
        } else {
            return {
                no: getVal(['提款單號', '單號']),
                acc: getVal(['會員帳號', '帳號']),
                amt: getVal(['金額', '實際金額']).replace(/[^0-9.]/g, '')
            };
        }
    }

    document.getElementById('btn-fetch-deposit').addEventListener('click', () => handleFetch('dep-status', 'deposit'));
    document.getElementById('btn-fetch-withdraw').addEventListener('click', () => handleFetch('wd-status', 'withdraw'));
});