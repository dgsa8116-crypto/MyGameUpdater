(() => {
    if (window.__momoRankSnifferMainLoaded) return;
    window.__momoRankSnifferMainLoaded = true;

    const isRankPage = () => /(?:^|\/)rank(?:[/?#]|$)|rank/i.test(`${location.pathname || ''}${location.search || ''}${location.hash || ''}`);
    if (!isRankPage()) return;

    const MAX_RESPONSE_TEXT = 1200000;
    const MAX_ACCOUNTS = 250;
    const ACCOUNT_KEY_RE = /account|username|user_?name|member|login|player/i;
    const ACCOUNT_RE = /\b(?=[a-z0-9_]{4,30}\b)(?=[a-z0-9_]*\d)[a-z][a-z0-9_]*\b/ig;
    const EXCLUDE_RE = /^(rank|ranking|yesterday|today|tomorrow|account|username|member|player|admin|null|undefined|vip\d*|usdt|twd|trc20|erc20|http|https|becgame)$/i;
    const BAD_TOKEN_RE = /^(?:fun|7vslcx|trx|txid|hash|order|token|address)/i;

    const clean = (value) => String(value || '').replace(/\s+/g, ' ').trim();
    const shouldInspectUrl = (url) => {
        try {
            const parsed = new URL(url, location.href);
            if (parsed.origin !== location.origin) return false;
            return true;
        } catch (error) {
            return false;
        }
    };
    const validAccount = (value) => {
        const text = clean(value);
        if (!text || text.includes('*') || text.length < 4 || text.length > 30) return '';
        const match = text.match(/^[a-z][a-z0-9_]{3,29}$/i);
        if (!match) return '';
        const account = match[0];
        if (!/\d/.test(account) || EXCLUDE_RE.test(account) || BAD_TOKEN_RE.test(account)) return '';
        return account;
    };
    const addAccount = (set, value) => {
        const account = validAccount(value);
        if (account && set.size < MAX_ACCOUNTS) set.add(account);
    };
    const walkValue = (value, key, set, depth = 0) => {
        if (set.size >= MAX_ACCOUNTS || depth > 9 || value == null) return;
        if (typeof value === 'string') {
            const text = clean(value);
            if (ACCOUNT_KEY_RE.test(String(key || ''))) addAccount(set, text);
            if (text.length <= 80) {
                for (const match of text.matchAll(ACCOUNT_RE)) addAccount(set, match[0]);
            }
            return;
        }
        if (Array.isArray(value)) {
            value.slice(0, 500).forEach(item => walkValue(item, key, set, depth + 1));
            return;
        }
        if (typeof value === 'object') {
            Object.entries(value).slice(0, 120).forEach(([childKey, childValue]) => walkValue(childValue, childKey, set, depth + 1));
        }
    };
    const extractAccounts = (text) => {
        const source = String(text || '');
        if (!source || source.length > MAX_RESPONSE_TEXT) return [];
        const found = new Set();
        try {
            walkValue(JSON.parse(source), '', found);
        } catch (error) {
            const slice = source.slice(0, 250000);
            for (const match of slice.matchAll(ACCOUNT_RE)) addAccount(found, match[0]);
        }
        return [...found];
    };
    const publishAccounts = (accounts, url) => {
        if (!accounts.length) return;
        window.postMessage({
            source: 'momo-rank-sniffer',
            type: 'MOMO_RANK_SIGNAL',
            accounts,
            url: String(url || location.href),
            at: Date.now()
        }, location.origin);
    };
    const inspectText = (text, url) => {
        if (!shouldInspectUrl(url)) return;
        window.setTimeout(() => publishAccounts(extractAccounts(text), url), 0);
    };
    const inspectResponse = (response, url) => {
        try {
            if (!response || !response.ok || !shouldInspectUrl(url)) return;
            const type = String(response.headers?.get?.('content-type') || '').toLowerCase();
            if (type && !/json|text|javascript|html/.test(type)) return;
            const contentLength = Number(response.headers?.get?.('content-length') || 0);
            if (contentLength > MAX_RESPONSE_TEXT) return;
            response.clone().text().then(text => inspectText(text, url)).catch(() => {});
        } catch (error) {}
    };

    const nativeFetch = window.fetch;
    if (typeof nativeFetch === 'function') {
        window.fetch = function momoRankFetch(input, init) {
            const promise = nativeFetch.apply(this, arguments);
            try {
                const url = typeof input === 'string' ? input : input?.url;
                promise.then(response => inspectResponse(response, new URL(url || response?.url || '', location.href).href)).catch(() => {});
            } catch (error) {}
            return promise;
        };
    }

    const nativeOpen = XMLHttpRequest.prototype.open;
    const nativeSend = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.open = function momoRankOpen(method, url) {
        try {
            this.__momoRankUrl = new URL(url || '', location.href).href;
        } catch (error) {
            this.__momoRankUrl = String(url || '');
        }
        return nativeOpen.apply(this, arguments);
    };
    XMLHttpRequest.prototype.send = function momoRankSend() {
        try {
            this.addEventListener('loadend', () => {
                try {
                    if (this.status < 200 || this.status >= 300) return;
                    if (this.responseType && this.responseType !== 'text') return;
                    inspectText(this.responseText || '', this.__momoRankUrl || location.href);
                } catch (error) {}
            });
        } catch (error) {}
        return nativeSend.apply(this, arguments);
    };
})();
