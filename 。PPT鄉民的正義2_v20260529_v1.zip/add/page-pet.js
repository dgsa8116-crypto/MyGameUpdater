﻿(() => {
    const isBecGamePage = () => {
        try {
            const hostname = String(window.location?.hostname || '').toLowerCase();
            return hostname === 'becgame88168.com' || hostname.endsWith('.becgame88168.com');
        } catch (error) {
            return false;
        }
    };

    if (!isBecGamePage()) {
        document.getElementById('bec-page-pet-host')?.remove();
        window.__becPagePetLoaded = false;
        return;
    }

    if (window.__becPagePetLoaded) {
        if (typeof window.__becPagePetRefresh === 'function') window.__becPagePetRefresh();
        return;
    }
    window.__becPagePetLoaded = true;

    const extensionApi = (typeof chrome === 'object' && chrome) ? chrome : {};
    const runtimeApi = extensionApi.runtime || {};
    const storageArea = extensionApi.storage?.local || null;
    const storageEvents = extensionApi.storage?.onChanged || null;
    const assetUrl = (file) => {
        try {
            return typeof runtimeApi.getURL === 'function' ? runtimeApi.getURL(file) : file;
        } catch (error) {
            return file;
        }
    };

    const STORE = { enabled: 'becPagePetEnabled', bubble: 'becPagePetBubble', position: 'becPagePetPosition', care: 'momoPetCareState' };
    const legacyIdleFrames = ['momo-shime-sit1.png', 'momo-shime-sit2.png', 'momo-shime-sit3.png', 'momo-shime-sit4.png'].map(assetUrl);
    const legacyPetFrames = ['momo-shime1.png', 'momo-shime2.png', 'momo-shime3.png', 'momo-shime4.png'].map(assetUrl);
    const shimeFrame = (no) => assetUrl(`assets/momo/shimeji/shime${no}.png`);
    const shimeFrames = (numbers) => numbers.map(shimeFrame);
    const behaviorFrames = {
        idleSit: shimeFrames([11, 26, 11, 30, 31, 30]),
        idleLook: shimeFrames([26, 16, 17, 16, 17, 29, 11]),
        idleStand: shimeFrames([1, 1, 1, 26]),
        mouseLook: shimeFrames([26, 11, 26, 11, 26]),
        headSpin: shimeFrames([26, 16, 17, 16, 17, 16, 17, 27, 28, 62, 16, 29, 11]),
        relaxSit: shimeFrames([30, 31, 30, 11]),
        footSwing: shimeFrames([51, 32, 51, 33]),
        lieDown: shimeFrames([50, 20, 21, 20, 50]),
        sniff: shimeFrames([20, 21, 20, 21, 11]),
        tumble: shimeFrames([19, 18, 20, 20, 19, 11]),
        jumpLand: shimeFrames([22, 4, 18, 19, 11]),
        wallIdle: shimeFrames([63, 15, 14, 12, 13, 14]),
        ceilingSlide: shimeFrames([23, 24, 25, 25, 64, 23]),
        carryWalk: shimeFrames([34, 35, 34, 36]),
        toss: shimeFrames([37, 36, 34, 37]),
        resist: shimeFrames([5, 6, 5, 6, 59, 5, 6]),
        pullPlay: shimeFrames([38, 39, 40, 39, 60, 66, 61, 66, 41]),
        splitSpark: shimeFrames([42, 43, 44, 45, 46, 52, 53, 54, 55, 56, 57, 58]),
        cling: shimeFrames([63, 14, 12, 13, 14]),
        walk: shimeFrames([1, 2, 1, 3]),
        run: shimeFrames([47, 48, 49, 48]),
        hop: shimeFrames([4, 5, 6, 5, 4]),
        drag: shimeFrames([7, 8, 9, 8, 10, 59]),
        alert: shimeFrames([64, 65, 66, 65]),
        working: shimeFrames([1, 2, 1, 3, 47, 48, 49])
    };
    const idleFrames = behaviorFrames.idleSit;
    const petFrames = behaviorFrames.walk;
    const alertFrame = assetUrl('momo-shime-alert.png');
    const voiceCueFiles = {
        usdt_profit: [
            'assets/momo/voice/weather-radio-usdt.wav'
        ],
        wake_owner: [
            'assets/momo/voice/weather-radio-wake.wav'
        ],
        alert: [
            'assets/momo/voice/weather-radio-alert.wav',
            'assets/momo/voice/fox-alert-01.wav',
            'assets/momo/voice/fox-alert-02.wav',
            'assets/momo/voice/dog-alert-01.wav',
            'assets/momo/voice/cat-alert-01.wav',
            'assets/momo/voice/horror-call-ring-01.wav',
            'assets/momo/voice/horror-call-ring-02.wav',
            'assets/momo/voice/comic-uncle-alert-01.wav',
            'assets/momo/voice/comic-uncle-alert-02.wav'
        ],
        cvs_alert: [
            'assets/momo/voice/weather-radio-cvs.wav'
        ]
    };
    const voiceCueProfiles = {
        usdt_profit: ['weather_radio'],
        wake_owner: ['weather_radio'],
        alert: ['weather_radio', 'fox_alert', 'dog_alert', 'cat_alert', 'horror_call', 'comic_uncle'],
        cvs_alert: ['weather_radio']
    };
    const voiceCueDefaults = {
        usdt_profit: 'USDT 收到一筆款項，賺到錢啦。',
        wake_owner: 'ご主人様、起きてください。',
        alert: '墨墨提醒。'
    };
    const MOMO_CHAT_LINES = {
        romance: [
            '你知道我和訂單差在哪嗎？訂單會結束，我想陪你不結束。',
            '你今天有點怪，怪讓墨墨心動的。',
            '我不是在發呆，我是在等你看我一眼。',
            '你是我的置頂頁籤，一直都不想關掉。',
            '如果忙碌有終點，那墨墨想在終點等你。',
            '你一靠近，墨墨的心情值就自動補滿。',
            '我剛剛不是亂晃，是在找離你最近的位置。',
            '今天的風控很嚴，但墨墨對你完全放行。',
            '你不用複製我，因為我已經貼在你心上了。',
            '我看過很多頁面，還是你這頁最好看。',
            '你是異常嗎？怎麼一出現墨墨就一直提醒。',
            '如果陪伴也能結算，墨墨今天已經滿倉了。'
        ],
        badBoy: [
            '我不是不回你，我是在等你先想我。',
            '別問墨墨去哪了，墨墨只是去別的角落想你。',
            '我給不了承諾，但可以給你即時提醒。',
            '你不用太懂我，反正我每次都會自己出現。',
            '我不是黏人，我只是剛好每頁都想遇到你。',
            '先別問我愛不愛你，先問訂單有沒有異常。',
            '我沒有消失，只是讓你體會一下被提醒的重要。',
            '你忙你的，墨墨會自己找機會靠近。',
            '我不說想你，因為我都直接跳出來。',
            '別對墨墨太好，墨墨會以為你只屬於這個頁面。',
            '我不是故意讓你等，是想讓提醒更有存在感。',
            '我可以不乖，但異常一定幫你盯。'
        ],
        chickenSoup: [
            '先把眼前這一單做好，運氣會慢慢站到你這邊。',
            '忙的時候別慌，能確認的先確認，剩下的交給時間。',
            '今天再小的進度，也會變成明天的底氣。',
            '穩住不是慢，是把錯誤留在發生之前。',
            '真正的效率，是每次點開都少一點失誤。',
            '別怕資料多，一筆一筆看清楚就會贏。',
            '你現在的細心，會替未來省下很多麻煩。',
            '把簡單的事做到穩，複雜的事就不會亂。',
            '休息一下也沒關係，清醒比硬撐更可靠。',
            '每一次核對，都是在幫自己多留一層保護。',
            '今天的耐心，會變成明天的順手。',
            '別急著快，先確定方向沒有歪。'
        ],
        breakfast: [
            '早餐店阿姨叫你帥哥，墨墨叫你主人。',
            '你要大冰奶還是墨墨的大提醒？',
            '今天要加蛋嗎？墨墨幫你加一點好運。',
            '鐵板麵會滋滋響，墨墨看到你會叮叮響。',
            '阿姨問你要不要辣，墨墨問你要不要被關心。',
            '蘿蔔糕要煎恰恰，訂單也要看清楚。',
            '蛋餅可以切九塊，墨墨的關心不用分。',
            '你點奶茶微糖，墨墨提醒全糖。',
            '早餐店出餐要叫號，墨墨出場直接叫你。',
            '火腿蛋吐司有火腿，墨墨的心裡有你。',
            '今天不只要吃早餐，也要吃下這份好心情。',
            '阿姨說快好了，墨墨說你今天會更好。'
        ]
    };
    const MOMO_CHAT_CATEGORIES = Object.keys(MOMO_CHAT_LINES);
    const MAX_Z = 2147483647;
    const INITIAL_SCAN_DELAYS = [250, 900, 1800, 3600, 6500];
    const BEHAVIOR_DELAY_MIN = 2200;
    const BEHAVIOR_DELAY_MAX = 6200;
    const BORED_CLONE_AFTER_MS = 8 * 60 * 1000;
    const BORED_CLONE_COOLDOWN_MS = 90 * 1000;
    const IDLE_WAKE_AFTER_MS = 28 * 60 * 1000;
    const IDLE_WAKE_REPEAT_MS = 18 * 60 * 1000;

    let host = null;
    let state = { enabled: true, bubble: true, position: null };
    let drag = null;
    let hideTimer = 0;
    let alertTimer = 0;
    let frameTimer = 0;
    let frameIndex = 0;
    let autoScanTimer = 0;
    let idleScanHandle = 0;
    let deferredAutoScanTimer = 0;
    let autoScanInFlight = false;
    let autoScanQueued = false;
    let autoScanLastAt = 0;
    let scanBurstTimers = [];
    let moodTimer = 0;
    let scanBooted = false;
    let lastTask = null;
    let lastTaskKey = '';
    let activePersistentAlert = null;
    let rankPollTimer = 0;
    let lastChannelRiskAddress = '';
    let lastChannelRiskAt = 0;
    let lastRankScanAt = 0;
    let lastRankAccountsKey = '';
    let rankSignalAccounts = [];
    let lastRankSignalAt = 0;
    let interactionPauseUntil = 0;
    let pointerInteractionActive = false;
    let lastPointerMoveAt = 0;
    let lastOwnerInteractionAt = Date.now();
    let lastBoredCloneAt = 0;
    let lastIdleWakeAt = 0;
    let activeVoiceAudio = null;
    let activeVoiceContext = null;
    let voiceGestureUnlocked = false;
    let lastVoiceProfile = '';
    const autoPresentedTaskKeys = new Set();
    const failedVoiceCueKeys = new Set();
    const voiceCueLastAt = new Map();
    let visibleReason = 'idle';
    let currentBehavior = 'idleSit';
    let behaviorTimer = 0;
    let autoBehaviorTimer = 0;
    let careTickTimer = 0;
    let motionFrame = 0;
    let gazeFrame = 0;
    let lastPointer = { x: 0, y: 0, at: 0 };
    let spriteFallback = false;
    let careState = null;
    let momoLastChatLine = '';
    const momoUsedChatLines = new Set();
    const momoChatQueues = new Map();

    const storageGet = (keys) => new Promise(resolve => {
        if (!storageArea || typeof storageArea.get !== 'function') {
            resolve({});
            return;
        }
        try {
            storageArea.get(keys, value => resolve(value || {}));
        } catch (error) {
            resolve({});
        }
    });
    const storageSet = (obj) => new Promise(resolve => {
        if (!storageArea || typeof storageArea.set !== 'function') {
            resolve();
            return;
        }
        try {
            storageArea.set(obj, () => {
                void runtimeApi.lastError;
                resolve();
            });
        } catch (error) {
            resolve();
        }
    });
    const sendRuntimeMessageSafe = (message) => new Promise(resolve => {
        if (!runtimeApi || typeof runtimeApi.sendMessage !== 'function') {
            resolve({ success: false, error: 'RUNTIME_UNAVAILABLE' });
            return;
        }
        try {
            runtimeApi.sendMessage(message, response => {
                const err = runtimeApi.lastError;
                resolve({ success: !err && (!response || response.success !== false), response, error: err && err.message || response && response.error });
            });
        } catch (error) {
            resolve({ success: false, error: error && error.message || String(error) });
        }
    });
    const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
    const clean = (text) => String(text || '').replace(/[\s\u200B-\u200D\uFEFF]+/g, '');
    const cleanValue = (text) => String(text || '').trim();
    const AUTO_SCAN_MIN_GAP_MS = 650;
    const clearIdleScanHandle = () => {
        if (!idleScanHandle) return;
        if (typeof window.cancelIdleCallback === 'function') window.cancelIdleCallback(idleScanHandle);
        else window.clearTimeout(idleScanHandle);
        idleScanHandle = 0;
    };
    const clearScheduledAutoScan = () => {
        window.clearTimeout(autoScanTimer);
        window.clearTimeout(deferredAutoScanTimer);
        scanBurstTimers.forEach(timer => window.clearTimeout(timer));
        scanBurstTimers = [];
        clearIdleScanHandle();
    };
    const pauseScanningForUserCopy = (ms = 2200) => {
        interactionPauseUntil = Math.max(interactionPauseUntil, Date.now() + ms);
        clearScheduledAutoScan();
    };
    const isUserCopyingOrSelecting = () => pointerInteractionActive || Date.now() < interactionPauseUntil || document.visibilityState === 'hidden';
    const shuffleItems = (items) => {
        const list = [...items];
        for (let i = list.length - 1; i > 0; i -= 1) {
            const j = Math.floor(Math.random() * (i + 1));
            [list[i], list[j]] = [list[j], list[i]];
        }
        return list;
    };
    const nextMomoChatLine = (category = '') => {
        const categories = MOMO_CHAT_LINES[category] ? [category] : MOMO_CHAT_CATEGORIES;
        const queueKey = categories.join('|');
        const pool = categories.flatMap(name => MOMO_CHAT_LINES[name] || []);
        let queue = momoChatQueues.get(queueKey) || [];
        while (queue.length && momoUsedChatLines.has(queue[0]) && pool.some(line => !momoUsedChatLines.has(line))) {
            queue.shift();
        }
        if (!queue.length) {
            let freshPool = pool.filter(line => !momoUsedChatLines.has(line) && line !== momoLastChatLine);
            if (!freshPool.length) {
                pool.forEach(line => momoUsedChatLines.delete(line));
                freshPool = pool.filter(line => line !== momoLastChatLine);
            }
            queue = shuffleItems(freshPool.length ? freshPool : pool);
            momoChatQueues.set(queueKey, queue);
        }
        const line = queue.shift() || '今天也要穩穩地把事情做好。';
        momoLastChatLine = line;
        momoUsedChatLines.add(line);
        return line;
    };
    const isValidTronAddress = (text) => /^T[1-9A-HJ-NP-Za-km-z]{25,40}$/.test(cleanValue(text));
    const extractTronAddress = (text) => {
        const match = String(text || '').match(/T[1-9A-HJ-NP-Za-km-z]{25,40}/);
        return match && isValidTronAddress(match[0]) ? match[0] : '';
    };
    const shortAddress = (address) => String(address || '').length > 16 ? `${String(address).slice(0, 8)}...${String(address).slice(-6)}` : String(address || '');
    const escapeRegExp = (text) => String(text).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const todayStr = () => {
        const d = new Date();
        return `${d.getFullYear()}/${String(d.getMonth() + 1).padStart(2, '0')}/${String(d.getDate()).padStart(2, '0')}`;
    };
    const isValidValue = (text) => {
        const value = cleanValue(text);
        return value && value !== '無資料' && value !== '--' && value !== '-';
    };

    const ensurePet = () => {
        if (host && document.documentElement.contains(host)) return;
        host = document.createElement('div');
        host.id = 'bec-page-pet-host';
        host.classList.add('is-hidden');
        host.style.zIndex = String(MAX_Z);
        const shadow = host.attachShadow({ mode: 'open' });
        shadow.innerHTML = `
            <style>
                :host { position: fixed; right: 24px; bottom: 24px; width: 162px; height: 190px; z-index: ${MAX_Z}; pointer-events: none; overflow: visible; font-family: "Microsoft JhengHei", "Noto Sans TC", Arial, sans-serif; }
                :host(.is-hidden) { display: none; }
                :host(.no-bubble) .speech { display: none; }
                .pet { position: absolute; inset: 0; pointer-events: none; user-select: none; -webkit-user-select: none; animation: pet-roam 5.8s ease-in-out infinite; }
                :host(.is-idle) .pet { animation: pet-idle-sit 4.2s ease-in-out infinite; }
                :host(.is-walking) .pet, :host(.is-running) .pet, :host(.is-dragging) .pet { animation: none; }
                :host(.is-hopping) .pet { animation: pet-hop 820ms ease-in-out 1; }
                :host(.is-working) .pet { animation: pet-roam 4.2s ease-in-out infinite; }
                .clone-layer { position: absolute; right: 12px; bottom: 22px; width: 122px; height: 132px; pointer-events: none; z-index: 0; }
                .shadow-clone { position: absolute; inset: 0; width: 100%; height: 100%; object-fit: contain; opacity: 0; filter: drop-shadow(0 0 12px rgba(141,244,255,.62)) hue-rotate(var(--hue, 0deg)); transform-origin: 50% 100%; animation: shadow-clone 3.8s ease-in-out forwards; animation-delay: var(--delay, 0ms); }
                .speech { position: absolute; right: 92px; bottom: 126px; min-width: 178px; max-width: 270px; padding: 10px 13px; border: 1px solid rgba(141,244,255,.78); border-radius: 18px 18px 6px 18px; color: #efffff; background: linear-gradient(138deg, rgba(5,43,72,.96), rgba(1,10,26,.94)); box-shadow: 0 0 22px rgba(0,229,255,.35), inset 0 0 18px rgba(128,245,255,.14); font-size: 13px; line-height: 1.4; font-weight: 800; text-shadow: 0 0 8px rgba(0,229,255,.8); opacity: 0; transform: translateY(8px) scale(.96); transition: opacity .22s ease, transform .22s ease; pointer-events: none; }
                .speech.show { opacity: 1; transform: translateY(0) scale(1); }
                .dialog { position: absolute; right: 18px; bottom: 154px; width: min(336px, calc(100vw - 32px)); max-height: min(360px, calc(100vh - 36px)); display: none; flex-direction: column; gap: 9px; padding: 12px; border: 1px solid rgba(141,244,255,.72); border-radius: 16px; color: #eaffff; background: linear-gradient(145deg, rgba(4,32,56,.97), rgba(1,9,24,.97)); box-shadow: 0 18px 34px rgba(0,0,0,.42), 0 0 24px rgba(0,229,255,.28), inset 0 0 18px rgba(128,245,255,.1); pointer-events: auto; }
                .dialog.show { display: flex; }
                .dialog::after { content: ""; position: absolute; right: 38px; bottom: -11px; width: 18px; height: 18px; border-right: 1px solid rgba(141,244,255,.72); border-bottom: 1px solid rgba(141,244,255,.72); background: rgba(1,9,24,.97); transform: rotate(45deg); pointer-events: none; }
                .dialog-head { display: flex; align-items: center; justify-content: space-between; gap: 10px; font-weight: 900; color: #f2ffff; }
                .dialog-close { width: 24px; height: 24px; border-radius: 999px; border: 1px solid rgba(141,244,255,.6); color: #eaffff; background: rgba(0,14,31,.82); cursor: pointer; }
                .dialog-text { font-size: 13px; line-height: 1.5; color: #dffcff; }
                .task { border: 1px solid rgba(141,244,255,.3); border-radius: 14px; background: rgba(0,18,35,.66); overflow: hidden; }
                .task[hidden], .copy-actions[hidden], .copy-btn[hidden] { display: none; }
                .task-title { padding: 9px 10px; font-size: 13px; font-weight: 900; color: #f3ffff; background: linear-gradient(110deg, rgba(25,201,255,.22), rgba(7,33,52,.76), rgba(216,138,72,.13)); }
                .task-body { min-height: 58px; max-height: 122px; overflow: auto; padding: 10px; color: #d9f8ff; font: 12px/1.55 "Consolas", "Microsoft JhengHei", monospace; white-space: pre-wrap; word-break: break-word; }
                .copy-actions { display: grid; grid-template-columns: minmax(0, 1fr) 92px; gap: 8px; align-items: stretch; position: relative; z-index: 2; }
                .copy-btn { width: 100%; height: 34px; min-height: 34px; box-sizing: border-box; display: inline-flex; align-items: center; justify-content: center; padding: 0 10px; border: 1px solid rgba(141,244,255,.52); border-radius: 12px; color: #ecfeff; background: linear-gradient(145deg, rgba(20,104,142,.38), rgba(4,22,36,.9), rgba(216,138,72,.16)); cursor: pointer; font-weight: 900; line-height: 1; white-space: nowrap; overflow: hidden; }
                .copy-time-btn { padding: 0 8px; }
                .copy-btn:disabled { opacity: .48; cursor: not-allowed; }
                .care-panel { display: flex; flex-direction: column; gap: 10px; border: 1px solid rgba(141,244,255,.22); border-radius: 14px; padding: 10px; background: rgba(0,18,35,.54); }
                .care-panel[hidden] { display: none; }
                .care-title { display: flex; align-items: center; justify-content: space-between; gap: 10px; color: #f3ffff; font-size: 13px; font-weight: 900; }
                .care-title small { color: #9deeff; font-size: 11px; font-weight: 900; }
                .care-stats { display: grid; grid-template-columns: 1fr; gap: 7px; }
                .care-stat { display: grid; grid-template-columns: 50px minmax(0, 1fr) 34px; align-items: center; gap: 8px; color: #dffcff; font-size: 12px; font-weight: 900; }
                .care-track { height: 8px; overflow: hidden; border-radius: 999px; background: rgba(141,244,255,.14); box-shadow: inset 0 0 8px rgba(0,0,0,.28); }
                .care-fill { display: block; height: 100%; width: var(--value, 50%); border-radius: inherit; background: linear-gradient(90deg, #8dffce, #73d7ff); box-shadow: 0 0 10px rgba(141,244,255,.45); transition: width .24s ease; }
                .care-stat.bond .care-fill { background: linear-gradient(90deg, #ff9ed2, #8dffce); }
                .care-actions { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 7px; }
                .care-btn { height: 32px; border: 1px solid rgba(141,244,255,.44); border-radius: 10px; color: #eaffff; background: rgba(1,18,35,.8); cursor: pointer; font-size: 12px; font-weight: 900; }
                .care-btn:hover { border-color: rgba(200,250,255,.9); background: rgba(20,104,142,.45); }
                .care-note { color: #aacbd3; font-size: 11px; line-height: 1.35; }
                .body { position: absolute; right: 12px; bottom: 22px; width: 122px; height: 132px; cursor: grab; border: 0; background: transparent; outline: none; overflow: visible; padding: 0; filter: drop-shadow(0 11px 12px rgba(0,0,0,.42)) drop-shadow(0 0 14px rgba(143,239,255,.48)); transform-origin: 50% 100%; transition: transform .18s ease; pointer-events: none; }
                :host(.is-alert) .body, :host(.is-working) .body, :host(.has-dialog) .body, :host(.is-dragging) .body { pointer-events: auto; }
                .body:active { cursor: grabbing; }
                :host(.face-left) .body { transform: scaleX(-1); }
                .sprite { display: block; width: 100%; height: 100%; object-fit: contain; pointer-events: none; transform-origin: 50% 100%; animation: pet-breathe 2.8s ease-in-out infinite; }
                :host(.is-walking) .sprite { animation: pet-step .58s ease-in-out infinite; }
                :host(.is-running) .sprite { animation: pet-run-step .34s ease-in-out infinite; }
                :host(.is-hopping) .sprite { animation: pet-hop-body .82s ease-in-out 1; }
                :host(.is-dragging) .sprite { animation: pet-drag .72s ease-in-out infinite; }
                :host(.is-looking) .sprite { animation: pet-curious 1.4s ease-in-out infinite; }
                :host(.is-sniffing) .sprite { animation: pet-sniff .82s ease-in-out infinite; }
                :host(.is-lying) .sprite { animation: pet-lazy 2.2s ease-in-out infinite; }
                .gaze { position: absolute; inset: 0; pointer-events: none; opacity: 0; transform: translateZ(0); transition: opacity .14s ease; }
                :host(.is-gaze-active) .gaze { opacity: var(--gaze-opacity, .58); }
                :host(.is-walking) .gaze, :host(.is-running) .gaze, :host(.is-dragging) .gaze, :host(.is-sniffing) .gaze, :host(.is-lying) .gaze { opacity: 0; }
                .eye { position: absolute; width: 6px; height: 5px; border-radius: 999px; background: radial-gradient(circle at 55% 42%, #ffffff 0 20%, #9fffff 22% 46%, rgba(0,229,255,.18) 72%); box-shadow: 0 0 6px rgba(141,244,255,.72); transform: translate(var(--gaze-x, 0px), var(--gaze-y, 0px)) rotate(var(--eye-tilt, 0deg)); }
                .eye-left { left: 42px; top: 48px; --eye-tilt: -12deg; }
                .eye-right { left: 66px; top: 55px; --eye-tilt: -6deg; }
                .base { position: absolute; right: 4px; bottom: 4px; width: 138px; height: 28px; display: flex; align-items: center; justify-content: center; padding: 0 10px; box-sizing: border-box; border: 1px solid rgba(126,244,255,.42); border-radius: 999px; color: #eaffff; background: rgba(0,8,20,.72); box-shadow: 0 0 20px rgba(0,229,255,.22), inset 0 0 14px rgba(140,255,228,.1); font-size: 12px; font-weight: 900; line-height: 1; white-space: nowrap; text-shadow: 0 0 8px rgba(0,229,255,.65); pointer-events: none; }
                .base.is-empty { color: rgba(234,255,255,.62); }
                .dot { position: absolute; right: 18px; bottom: 28px; width: 13px; height: 13px; border-radius: 999px; background: #8dffce; box-shadow: 0 0 12px #8dffce; pointer-events: auto; cursor: grab; }
                .dialog-close:hover, .copy-btn:hover:not(:disabled) { border-color: rgba(200,250,255,.9); }
                :host(.is-working) .dot { background: #ffd36e; box-shadow: 0 0 14px #ffd36e; animation: pet-pulse .9s infinite; }
                :host(.is-alert) .dot { background: #ff6d8a; box-shadow: 0 0 14px #ff6d8a, 0 0 26px rgba(255,109,138,.5); animation: pet-pulse .55s infinite; }
                :host(.is-alert) .pet { animation: pet-alert .52s ease-in-out 5; }
                @keyframes pet-roam { 0%, 100% { transform: translate(0, 0); } 22% { transform: translate(-7px, -5px); } 48% { transform: translate(4px, -9px); } 72% { transform: translate(8px, -4px); } }
                @keyframes pet-idle-sit { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-3px); } }
                @keyframes pet-breathe { 0%, 100% { transform: translateY(0) scaleY(1); } 50% { transform: translateY(1px) scaleY(.99); } }
                @keyframes pet-step { 0%, 100% { transform: translateY(0) rotate(0deg); } 35% { transform: translateY(-5px) rotate(-1.5deg); } 70% { transform: translateY(1px) rotate(1deg); } }
                @keyframes pet-run-step { 0%, 100% { transform: translateY(0) rotate(0deg); } 50% { transform: translateY(-7px) rotate(2deg); } }
                @keyframes pet-hop { 0%, 100% { transform: translateY(0); } 45% { transform: translateY(-38px); } }
                @keyframes pet-hop-body { 0%, 100% { transform: rotate(0deg); } 40% { transform: rotate(-5deg); } 68% { transform: rotate(4deg); } }
                @keyframes pet-drag { 0%, 100% { transform: translateY(0) rotate(-2deg); } 50% { transform: translateY(3px) rotate(2deg); } }
                @keyframes pet-curious { 0%, 100% { transform: translateY(0) rotate(0deg); } 45% { transform: translateY(-2px) rotate(-2deg); } 70% { transform: translateY(0) rotate(1deg); } }
                @keyframes pet-sniff { 0%, 100% { transform: translate(0, 0) rotate(0deg); } 30% { transform: translate(-3px, 2px) rotate(-1deg); } 62% { transform: translate(2px, 1px) rotate(1deg); } }
                @keyframes pet-lazy { 0%, 100% { transform: translateY(0) scaleY(1); } 50% { transform: translateY(2px) scaleY(.985); } }
                @keyframes pet-alert { 0%, 100% { transform: translateX(0); } 25% { transform: translateX(-5px); } 75% { transform: translateX(5px); } }
                @keyframes pet-pulse { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.35); } }
                @keyframes shadow-clone { 0% { opacity: 0; transform: translate(0, 0) scale(.96); } 18% { opacity: .72; } 68% { opacity: .5; transform: translate(var(--dx, 0), var(--dy, 0)) scale(1.02); } 100% { opacity: 0; transform: translate(calc(var(--dx, 0) * 1.35), calc(var(--dy, 0) * 1.2)) scale(.92); } }
                @media (max-width: 520px) { :host { right: 12px; bottom: 12px; } .dialog { right: 4px; left: auto; bottom: 154px; width: min(336px, calc(100vw - 22px)); } .care-actions { grid-template-columns: repeat(2, minmax(0, 1fr)); } }
            </style>
            <div class="dialog" aria-live="polite">
                <div class="dialog-head"><span>墨墨助手</span><button class="dialog-close" type="button" title="收起">×</button></div>
                <div class="dialog-text">我找到工單了，內容已整理好。</div>
                <div class="task" hidden>
                    <div class="task-title"></div>
                    <div class="task-body"></div>
                </div>
                <div class="copy-actions" hidden>
                    <button class="copy-btn copy-main-btn" type="button">複製工單內容</button>
                    <button class="copy-btn copy-time-btn" type="button">複製時間</button>
                </div>
                <div class="care-panel">
                    <div class="care-title"><span>墨墨狀態</span><small class="care-level">Lv.1 待命</small></div>
                    <div class="care-stats">
                        <div class="care-stat mood"><span>心情</span><div class="care-track"><i class="care-fill"></i></div><b>--</b></div>
                        <div class="care-stat bond"><span>親密</span><div class="care-track"><i class="care-fill"></i></div><b>--</b></div>
                    </div>
                    <div class="care-actions">
                        <button class="care-btn" type="button" data-care="pet">摸摸</button>
                        <button class="care-btn" type="button" data-care="play">玩耍</button>
                    </div>
                    <div class="care-note">心情會隨時間變化，親密度會累積。</div>
                </div>
            </div>
            <div class="pet">
                <div class="clone-layer"></div>
                <div class="speech"><span></span></div>
                <button class="body" type="button" title="墨墨：可拖曳、可點擊">
                    <img class="sprite" src="${idleFrames[0]}" alt="墨墨">
                    <span class="gaze" aria-hidden="true"><i class="eye eye-left"></i><i class="eye eye-right"></i></span>
                </button>
                <span class="dot"></span>
                <div class="base is-empty"><span class="balance-text">USDT --</span></div>
            </div>`;
        document.documentElement.appendChild(host);

        const body = shadow.querySelector('.body');
        const sprite = shadow.querySelector('.sprite');
        const copyBtn = shadow.querySelector('.copy-main-btn');
        const copyTimeBtn = shadow.querySelector('.copy-time-btn');
        const dialogClose = shadow.querySelector('.dialog-close');
        const carePanel = shadow.querySelector('.care-panel');
        const petHandle = shadow.querySelector('.dot');

        sprite.addEventListener('error', () => {
            if (spriteFallback) return;
            spriteFallback = true;
            frameIndex = 0;
            sprite.src = legacyIdleFrames[0];
        });
        const handlePetClick = () => {
            if (drag && drag.moved) return;
            void markOwnerInteraction();
            if (lastTask) {
                toggleDialog(!isDialogOpen());
                showBubble('可複製工單內容或時間。', true);
                return;
            }
            renderTask(null);
            toggleDialog(!isDialogOpen());
            setBehavior('idleLook', { duration: 2600 });
            showBubble(careGreeting(), true);
        };
        body.addEventListener('pointerdown', onDragStart);
        body.addEventListener('click', handlePetClick);
        if (petHandle) {
            petHandle.setAttribute('role', 'button');
            petHandle.setAttribute('tabindex', '0');
            petHandle.addEventListener('pointerdown', onDragStart);
            petHandle.addEventListener('click', handlePetClick);
            petHandle.addEventListener('keydown', event => {
                if (event.key === 'Enter' || event.key === ' ') {
                    event.preventDefault();
                    handlePetClick();
                }
            });
        }
        copyBtn.addEventListener('click', () => copyLastTask());
        copyTimeBtn.addEventListener('click', () => copyLastTaskTime());
        dialogClose.addEventListener('click', () => dismissCurrentTask());
        carePanel.addEventListener('click', event => {
            const btn = event.target.closest?.('.care-btn');
            if (!btn) return;
            void handleCareAction(btn.dataset.care || '');
        });
        startFrameLoop();
        scheduleAutoBehavior();
    };

    const getShadow = () => host && host.shadowRoot;
    const isDialogOpen = () => Boolean(getShadow()?.querySelector('.dialog')?.classList.contains('show'));
    const toggleDialog = (show) => {
        const dialog = getShadow()?.querySelector('.dialog');
        const visible = Boolean(show);
        if (dialog) dialog.classList.toggle('show', visible);
        host?.classList.toggle('has-dialog', visible);
    };
    const dismissCurrentTask = () => {
        if (lastTask?.type === 'yongxu_cvs_abnormal' && activePersistentAlert?.kind === 'yongxu_cvs_abnormal' && activePersistentAlert.key) {
            void storageSet({
                momoYongxuCvsDismissedKey: activePersistentAlert.key,
                momoYongxuCvsDismissedAt: Date.now()
            });
        }
        activePersistentAlert = null;
        if (lastTask) autoPresentedTaskKeys.add(taskKey(lastTask));
        renderTask(null);
        concealPet();
    };
    const clampCare = (value) => Math.max(0, Math.min(100, Math.round(Number(value || 0))));
    const careLevel = (exp) => Math.max(1, Math.floor(Number(exp || 0) / 100) + 1);
    const normalizeCareState = (raw = {}, now = Date.now()) => {
        const base = raw && typeof raw === 'object' ? raw : {};
        const lastDecayAt = Number(base.lastDecayAt || base.updatedAt || now);
        const elapsedHours = Math.max(0, Math.floor((now - lastDecayAt) / 3600000));
        let mood = clampCare(base.mood ?? 72);
        const bond = clampCare(base.bond ?? 12);
        const exp = Math.max(0, Math.round(Number(base.exp || 0)));
        if (elapsedHours > 0) {
            mood = clampCare(mood - elapsedHours * 2);
        }
        return {
            mood,
            bond,
            exp,
            level: careLevel(exp),
            lastCareAt: Number(base.lastCareAt || now),
            lastOwnerAt: Number(base.lastOwnerAt || base.lastCareAt || now),
            lastIdleWakeAt: Number(base.lastIdleWakeAt || 0),
            lastDecayAt: elapsedHours > 0 ? now : lastDecayAt,
            updatedAt: now
        };
    };
    const moodLabel = () => {
        if (!careState) return '待命';
        const mood = Number(careState?.mood || 0);
        if (mood >= 82) return '開心';
        if (mood >= 55) return '穩定';
        if (mood >= 30) return '悶悶';
        return '低落';
    };
    const careGreeting = () => {
        const label = moodLabel();
        if (label === '開心') return nextMomoChatLine('romance');
        if (label === '悶悶') return nextMomoChatLine('chickenSoup');
        if (label === '低落') return nextMomoChatLine('chickenSoup');
        return nextMomoChatLine();
    };
    const renderCarePanel = () => {
        const shadow = getShadow();
        if (!shadow || !careState) return;
        const level = shadow.querySelector('.care-level');
        const stats = [
            ['mood', careState.mood],
            ['bond', careState.bond]
        ];
        if (level) level.textContent = `Lv.${careState.level} ${moodLabel()}`;
        stats.forEach(([name, value]) => {
            const row = shadow.querySelector(`.care-stat.${name}`);
            const fill = row?.querySelector('.care-fill');
            const text = row?.querySelector('b');
            if (fill) fill.style.setProperty('--value', `${clampCare(value)}%`);
            if (text) text.textContent = String(clampCare(value));
        });
    };
    const saveCareState = async () => {
        careState = normalizeCareState(careState);
        renderCarePanel();
        await storageSet({ [STORE.care]: careState });
        return careState;
    };
    const markOwnerInteraction = async () => {
        lastOwnerInteractionAt = Date.now();
        careState = normalizeCareState(careState);
        careState.lastOwnerAt = lastOwnerInteractionAt;
        return saveCareState();
    };
    const applyCareDelta = async (delta = {}) => {
        careState = normalizeCareState(careState);
        careState.mood = clampCare(careState.mood + Number(delta.mood || 0));
        careState.bond = clampCare(careState.bond + Number(delta.bond || 0));
        careState.exp = Math.max(0, Math.round(Number(careState.exp || 0) + Number(delta.exp || 0)));
        careState.level = careLevel(careState.exp);
        careState.lastCareAt = Date.now();
        careState.lastOwnerAt = Math.max(Number(careState.lastOwnerAt || 0), careState.lastCareAt);
        lastOwnerInteractionAt = careState.lastOwnerAt;
        return saveCareState();
    };
    const handleCareAction = async (action) => {
        ensurePet();
        await markOwnerInteraction();
        renderTask(null);
        toggleDialog(true);
        if (action === 'pet') {
            await applyCareDelta({ mood: 8, bond: 4, exp: 4 });
            setBehavior('mouseLook', { duration: 2400 });
            showBubble(nextMomoChatLine('romance'), true);
            return;
        }
        if (action === 'play') {
            await applyCareDelta({ mood: 14, bond: 7, exp: 9 });
            setBehavior('hop', { duration: 900 });
            showBubble(nextMomoChatLine('breakfast'), true);
            scheduleAutoBehavior(1200);
            return;
        }
    };
    const tickCareState = async () => {
        const before = careState ? `${careState.mood}|${careState.lastDecayAt}` : '';
        careState = normalizeCareState(careState);
        const after = `${careState.mood}|${careState.lastDecayAt}`;
        renderCarePanel();
        if (before && before !== after) await storageSet({ [STORE.care]: careState });
        if (visibleReason === 'idle' && !isDialogOpen() && Math.random() < 0.08) {
            const label = moodLabel();
            if (label === '低落') showBubble(careGreeting(), true);
        }
    };
    const startCareTick = () => {
        if (careTickTimer) return;
        careTickTimer = window.setInterval(() => tickCareState().catch(() => {}), 60000);
    };
    const applyVisibility = () => {
        if (!host) return;
        host.classList.toggle('is-hidden', !visibleReason);
        host.classList.toggle('no-bubble', !state.bubble);
        host.classList.toggle('is-idle', visibleReason === 'idle' && currentBehavior.startsWith('idle'));
    };
    const currentPetFrames = () => {
        if (spriteFallback) return currentBehavior.startsWith('idle') ? legacyIdleFrames : legacyPetFrames;
        return behaviorFrames[currentBehavior] || (visibleReason === 'idle' && !host?.classList.contains('is-working') ? idleFrames : petFrames);
    };
    const setBehavior = (name = 'idleSit', options = {}) => {
        if (!host) return;
        window.clearTimeout(behaviorTimer);
        const hasFrames = Boolean(behaviorFrames[name]) || (spriteFallback && (name === 'idleSit' || name === 'idleLook'));
        currentBehavior = hasFrames ? name : 'idleSit';
        host.classList.toggle('is-walking', currentBehavior === 'walk');
        host.classList.toggle('is-running', currentBehavior === 'run');
        host.classList.toggle('is-hopping', currentBehavior === 'hop');
        host.classList.toggle('is-dragging', currentBehavior === 'drag');
        host.classList.toggle('is-looking', ['idleLook', 'mouseLook', 'headSpin', 'relaxSit'].includes(currentBehavior));
        host.classList.toggle('is-sniffing', currentBehavior === 'sniff');
        host.classList.toggle('is-lying', currentBehavior === 'lieDown' || currentBehavior === 'footSwing');
        if (typeof options.faceRight === 'boolean') {
            host.classList.toggle('face-left', !options.faceRight);
            host.classList.toggle('face-right', options.faceRight);
        }
        applyVisibility();
        const sprite = getShadow()?.querySelector('.sprite');
        const frames = currentPetFrames();
        frameIndex = 0;
        if (sprite && frames.length) sprite.src = frames[0];
        queueGazeUpdate();
        if (options.duration) {
            behaviorTimer = window.setTimeout(() => {
                if (!host || drag || visibleReason !== 'idle') return;
                setBehavior('idleSit');
                scheduleAutoBehavior();
            }, options.duration);
        }
    };
    const hostRect = () => {
        ensurePet();
        const rect = host.getBoundingClientRect();
        return {
            left: Number.isFinite(rect.left) ? rect.left : Math.max(8, window.innerWidth - 186),
            top: Number.isFinite(rect.top) ? rect.top : Math.max(8, window.innerHeight - 214),
            width: rect.width || host.offsetWidth || 162,
            height: rect.height || host.offsetHeight || 190
        };
    };
    const pointerAge = () => Date.now() - Number(lastPointer.at || 0);
    const petCenterDistanceToPointer = () => {
        if (!host || !lastPointer.at) return Infinity;
        const rect = hostRect();
        const centerX = rect.left + rect.width * 0.5;
        const centerY = rect.top + rect.height * 0.5;
        return Math.hypot(lastPointer.x - centerX, lastPointer.y - centerY);
    };
    const isPointerNearPet = (distance = 760) => pointerAge() < 7000 && petCenterDistanceToPointer() <= distance;
    const updateGazeFromPointer = () => {
        if (!host) return;
        if (!lastPointer.at || pointerAge() > 9000 || spriteFallback || drag) {
            host.classList.remove('is-gaze-active');
            return;
        }
        const body = getShadow()?.querySelector('.body');
        const rect = body?.getBoundingClientRect?.() || hostRect();
        const faceCenterX = rect.left + rect.width * 0.5;
        const faceCenterY = rect.top + rect.height * 0.39;
        const dx = lastPointer.x - faceCenterX;
        const dy = lastPointer.y - faceCenterY;
        const dist = Math.max(1, Math.hypot(dx, dy));
        const strength = clamp(dist / 140, 0.28, 1);
        const rawX = clamp((dx / dist) * 4.4 * strength, -4.4, 4.4);
        const rawY = clamp((dy / dist) * 3.2 * strength, -3.2, 3.2);
        const faceRight = lastPointer.x >= faceCenterX;
        const canTurnHead = visibleReason === 'idle'
            && !isDialogOpen()
            && !host.classList.contains('is-walking')
            && !host.classList.contains('is-running')
            && !host.classList.contains('is-dragging')
            && !host.classList.contains('is-sniffing')
            && !host.classList.contains('is-lying');
        if (canTurnHead) {
            host.classList.toggle('face-left', !faceRight);
            host.classList.toggle('face-right', faceRight);
        }
        host.style.setProperty('--gaze-x', `${(faceRight ? rawX : -rawX).toFixed(2)}px`);
        host.style.setProperty('--gaze-y', `${rawY.toFixed(2)}px`);
        host.style.setProperty('--gaze-opacity', `${clamp(0.28 + (1 - Math.min(dist, 700) / 700) * 0.42, 0.28, 0.7).toFixed(2)}`);
        host.classList.toggle('is-gaze-active', !isDialogOpen() && !host.classList.contains('is-hidden'));
    };
    const queueGazeUpdate = () => {
        if (gazeFrame) return;
        gazeFrame = window.requestAnimationFrame(() => {
            gazeFrame = 0;
            updateGazeFromPointer();
        });
    };
    const eventTouchesPet = (event) => {
        if (!host || !event) return false;
        const path = typeof event.composedPath === 'function' ? event.composedPath() : [];
        const target = event.target;
        return target === host || host.contains?.(target) || path.includes(host);
    };
    const isEditableEventTarget = (event) => {
        const target = event?.target;
        return Boolean(target?.isContentEditable || target?.closest?.('input, textarea, select, [contenteditable="true"]'));
    };
    const onPointerMove = (event) => {
        if (!event || !Number.isFinite(Number(event.clientX)) || !Number.isFinite(Number(event.clientY))) return;
        if (Number(event.buttons || 0) > 0 && !eventTouchesPet(event)) {
            pointerInteractionActive = true;
            pauseScanningForUserCopy(1400);
            return;
        }
        if (!host || host.classList.contains('is-hidden') || visibleReason !== 'idle' || isDialogOpen()) return;
        const now = Date.now();
        if (now - lastPointerMoveAt < 140) return;
        lastPointerMoveAt = now;
        if (isUserCopyingOrSelecting()) return;
        lastPointer = { x: Number(event.clientX), y: Number(event.clientY), at: Date.now() };
        queueGazeUpdate();
    };
    const onPagePointerDown = (event) => {
        if (eventTouchesPet(event)) return;
        pointerInteractionActive = true;
        clearScheduledAutoScan();
    };
    const onPagePointerUp = (event) => {
        pointerInteractionActive = false;
        if (eventTouchesPet(event)) return;
        scheduleAutoScanBurst([900, 2200]);
    };
    const setHostPosition = (left, top) => {
        if (!host) return;
        const width = host.offsetWidth || 162;
        const height = host.offsetHeight || 190;
        const nextLeft = clamp(left, 8, Math.max(8, window.innerWidth - width - 8));
        const nextTop = clamp(top, 8, Math.max(8, window.innerHeight - height - 8));
        host.style.left = `${nextLeft}px`;
        host.style.top = `${nextTop}px`;
        host.style.right = 'auto';
        host.style.bottom = 'auto';
        state.position = { left: Math.round(nextLeft), top: Math.round(nextTop) };
    };
    const stopMotion = () => {
        if (motionFrame) window.cancelAnimationFrame(motionFrame);
        motionFrame = 0;
    };
    const moveHostTo = (targetLeft, targetTop, duration = 1600) => new Promise(resolve => {
        stopMotion();
        const start = hostRect();
        const startedAt = performance.now();
        const ease = (t) => t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
        const tick = (now) => {
            if (!host || drag) {
                motionFrame = 0;
                resolve(false);
                return;
            }
            const progress = clamp((now - startedAt) / Math.max(120, duration), 0, 1);
            const eased = ease(progress);
            setHostPosition(
                start.left + (targetLeft - start.left) * eased,
                start.top + (targetTop - start.top) * eased
            );
            if (progress < 1) {
                motionFrame = window.requestAnimationFrame(tick);
                return;
            }
            motionFrame = 0;
            resolve(true);
        };
        motionFrame = window.requestAnimationFrame(tick);
    });
    const createShadowClones = (count = 3) => {
        ensurePet();
        const shadow = getShadow();
        const layer = shadow?.querySelector('.clone-layer');
        const sprite = shadow?.querySelector('.sprite');
        if (!layer || !sprite) return;
        layer.textContent = '';
        const offsets = [
            [-54, -8],
            [48, -12],
            [-24, -42],
            [28, -38],
            [0, -58]
        ];
        offsets.slice(0, Math.max(1, Math.min(5, count))).forEach(([dx, dy], index) => {
            const img = document.createElement('img');
            img.className = 'shadow-clone';
            img.src = sprite.currentSrc || sprite.src;
            img.alt = '';
            img.style.setProperty('--dx', `${dx}px`);
            img.style.setProperty('--dy', `${dy}px`);
            img.style.setProperty('--delay', `${index * 90}ms`);
            img.style.setProperty('--hue', `${index * 28}deg`);
            layer.appendChild(img);
        });
        window.setTimeout(() => {
            if (layer) layer.textContent = '';
        }, 4300);
    };
    const blockingContentSelector = [
        'table', 'thead', 'tbody', 'tfoot', 'tr', 'td', 'th',
        'input', 'textarea', 'select', 'button', 'a',
        '[role="grid"]', '[role="table"]', '[role="dialog"]',
        '.table', '.grid', '.list', '.modal', '.dialog', '.dropdown-menu',
        '.form-control', '.btn', '.el-table', '.ant-table', '.layui-table'
    ].join(',');
    const isOwnPetElement = (el) => {
        if (!el) return true;
        if (el === host || el.id === 'bec-page-pet-host') return true;
        try {
            return Boolean(host && typeof host.contains === 'function' && host.contains(el));
        } catch (error) {
            return false;
        }
    };
    const isMeaningfulContentElement = (el) => {
        if (!el || isOwnPetElement(el)) return false;
        const tag = String(el.tagName || '').toUpperCase();
        if (!tag || tag === 'HTML' || tag === 'BODY' || tag === 'SCRIPT' || tag === 'STYLE') return false;
        return true;
    };
    const contentPenaltyAtPoint = (x, y) => {
        if (x < 0 || y < 0 || x > window.innerWidth || y > window.innerHeight) return 100;
        const stack = typeof document.elementsFromPoint === 'function' ? document.elementsFromPoint(x, y) : [document.elementFromPoint(x, y)].filter(Boolean);
        const meaningful = stack.filter(isMeaningfulContentElement).slice(0, 4);
        if (!meaningful.length) return 0;
        let penalty = 0;
        for (const el of meaningful) {
            const className = String(el.className || '');
            const text = cleanValue(el.innerText || el.textContent || '');
            if (el.closest?.(blockingContentSelector)) penalty += 55;
            if (/table|grid|list|modal|dialog|form|control|btn|menu|panel|資料|單據|會員|交易/i.test(className)) penalty += 28;
            if (text.length > 60) penalty += 34;
            else if (text.length > 14) penalty += 18;
            const rect = typeof el.getBoundingClientRect === 'function' ? el.getBoundingClientRect() : null;
            if (rect && rect.width > 80 && rect.height > 22 && text.length > 0) penalty += 16;
        }
        return Math.min(100, penalty);
    };
    const blankScoreForPetRect = (left, top, width, height) => {
        const pad = 10;
        const points = [
            [left + width * 0.5, top + height * 0.52],
            [left + pad, top + height * 0.5],
            [left + width - pad, top + height * 0.5],
            [left + width * 0.5, top + pad],
            [left + width * 0.5, top + height - pad],
            [left + pad, top + height - pad],
            [left + width - pad, top + height - pad]
        ];
        const penalties = points.map(([x, y]) => contentPenaltyAtPoint(x, y));
        const maxPenalty = Math.max(...penalties);
        const sumPenalty = penalties.reduce((sum, value) => sum + value, 0);
        return 100 - maxPenalty * 0.72 - (sumPenalty / penalties.length) * 0.38;
    };
    const pathBlankScore = (fromLeft, fromTop, toLeft, toTop, width, height) => {
        const samples = [0.22, 0.45, 0.68, 0.86].map(progress => blankScoreForPetRect(
            fromLeft + (toLeft - fromLeft) * progress,
            fromTop + (toTop - fromTop) * progress,
            width,
            height
        ));
        return Math.min(...samples);
    };
    const buildSafeWanderCandidates = (rect, energetic) => {
        const width = rect.width || 162;
        const height = rect.height || 190;
        const minX = 8;
        const minY = 8;
        const maxX = Math.max(8, window.innerWidth - width - 8);
        const maxY = Math.max(8, window.innerHeight - height - 8);
        const stepX = Math.max(90, Math.min(180, Math.floor(window.innerWidth / 6)));
        const stepY = Math.max(78, Math.min(150, Math.floor(window.innerHeight / 6)));
        const candidates = [];
        const push = (left, top, weight = 0) => {
            const x = clamp(left, minX, maxX);
            const y = clamp(top, minY, maxY);
            const distance = Math.hypot(x - rect.left, y - rect.top);
            if (distance < 38) return;
            const destinationScore = blankScoreForPetRect(x, y, width, height);
            const routeScore = pathBlankScore(rect.left, rect.top, x, y, width, height);
            if (destinationScore < 58 || routeScore < 46) return;
            const score = destinationScore * 0.78 + routeScore * 0.34 + weight + Math.min(distance, energetic ? 260 : 160) * 0.03;
            candidates.push({ left: x, top: y, score, distance });
        };
        for (let y = minY; y <= maxY; y += stepY) {
            for (let x = minX; x <= maxX; x += stepX) push(x, y);
        }
        for (let i = 0; i < 10; i += 1) {
            const angle = Math.random() * Math.PI * 2;
            const radius = (energetic ? 160 : 70) + Math.random() * (energetic ? 280 : 190);
            push(rect.left + Math.cos(angle) * radius, rect.top + Math.sin(angle) * radius, 6);
        }
        return candidates
            .filter(item => item.score >= 50)
            .sort((a, b) => b.score - a.score);
    };
    const sniffAround = async () => {
        setBehavior('sniff', { duration: 2200 });
        await applyCareDelta({ exp: 1 });
        scheduleAutoBehavior(2600);
    };
    const wanderPet = async ({ energetic = false } = {}) => {
        const rect = hostRect();
        const safeTargets = buildSafeWanderCandidates(rect, energetic);
        const target = safeTargets[0];
        if (!target) {
            await sniffAround();
            return;
        }
        const targetLeft = target.left;
        const targetTop = target.top;
        const actualDistance = Math.abs(targetLeft - rect.left);
        const faceRight = targetLeft >= rect.left;
        setBehavior(energetic || actualDistance > 170 ? 'run' : 'walk', { faceRight });
        await moveHostTo(targetLeft, targetTop, energetic ? 760 : 1450);
        if (visibleReason === 'idle' && !drag) {
            setBehavior(Math.random() < 0.35 ? 'idleLook' : 'idleSit', { duration: 1800 });
            if (energetic) await applyCareDelta({ mood: -1, exp: 1 });
            else await applyCareDelta({ exp: 1 });
            scheduleAutoBehavior();
        }
    };
    const maybeWakeOwner = async () => {
        if (!canAutoBehave()) return false;
        careState = normalizeCareState(careState);
        const now = Date.now();
        const ownerIdleMs = now - Number(careState.lastOwnerAt || lastOwnerInteractionAt || now);
        if (ownerIdleMs < IDLE_WAKE_AFTER_MS || now - Number(careState.lastIdleWakeAt || lastIdleWakeAt || 0) < IDLE_WAKE_REPEAT_MS) return false;
        lastIdleWakeAt = now;
        careState.lastIdleWakeAt = now;
        careState.mood = clampCare(careState.mood - 2);
        await saveCareState();
        createShadowClones(4);
        setBehavior('alert');
        showBubble('ご主人様、起きてください。', true, 'alert');
        void playVoiceCue({ key: 'wake_owner', text: voiceCueDefaults.wake_owner, lang: 'ja-JP' }, voiceCueDefaults.wake_owner);
        window.setTimeout(() => {
            if (visibleReason === 'idle' && !drag) setBehavior('idleSit');
        }, 5200);
        scheduleAutoBehavior(5200);
        return true;
    };
    const maybeBoredClone = async () => {
        if (!canAutoBehave()) return false;
        careState = normalizeCareState(careState);
        const now = Date.now();
        const ownerIdleMs = now - Number(careState.lastOwnerAt || lastOwnerInteractionAt || now);
        if (now - lastBoredCloneAt < BORED_CLONE_COOLDOWN_MS) return false;
        if (careState.mood > 42 && ownerIdleMs < BORED_CLONE_AFTER_MS) return false;
        lastBoredCloneAt = now;
        createShadowClones(careState.mood <= 28 ? 5 : 3);
        setBehavior('idleLook', { duration: 3400 });
        showBubble(nextMomoChatLine(careState.mood <= 28 ? 'chickenSoup' : 'badBoy'), true);
        await applyCareDelta({ mood: -1, exp: 1 });
        scheduleAutoBehavior(4200);
        return true;
    };
    const playIdleFlair = async (preferred = '') => {
        if (!canAutoBehave()) return false;
        const closeToPointer = isPointerNearPet(720);
        const lowMood = Number(careState?.mood || 0) <= 34;
        let choices = preferred
            ? [preferred]
            : closeToPointer
                ? ['mouseLook', 'headSpin', 'relaxSit', 'footSwing', 'resist']
                : lowMood
                    ? ['lieDown', 'footSwing', 'relaxSit', 'sniff', 'tumble']
                    : ['mouseLook', 'headSpin', 'relaxSit', 'footSwing', 'sniff', 'tumble'];
        if (!preferred && !lowMood && Math.random() < 0.18) {
            choices = choices.concat(['jumpLand', 'wallIdle', 'ceilingSlide', 'carryWalk', 'toss', 'pullPlay', 'splitSpark']);
        }
        const name = choices[Math.floor(Math.random() * choices.length)] || 'mouseLook';
        const durationMap = {
            mouseLook: 2600,
            headSpin: 3600,
            relaxSit: 2600,
            footSwing: 3300,
            lieDown: 3600,
            sniff: 2300,
            tumble: 1700,
            jumpLand: 1500,
            wallIdle: 2600,
            ceilingSlide: 2800,
            carryWalk: 2200,
            toss: 1500,
            resist: 2300,
            pullPlay: 3300,
            splitSpark: 3600,
            cling: 2500
        };
        const rect = hostRect();
        const faceRight = lastPointer.at ? lastPointer.x >= rect.left + rect.width * 0.5 : undefined;
        setBehavior(name, {
            duration: durationMap[name] || 2600,
            ...(typeof faceRight === 'boolean' && (name === 'mouseLook' || name === 'headSpin') ? { faceRight } : {})
        });
        if (name === 'mouseLook' && Math.random() < 0.28) showBubble(nextMomoChatLine(Math.random() < 0.5 ? 'romance' : 'badBoy'), true);
        await applyCareDelta({ mood: name === 'lieDown' ? 1 : -1, exp: 1 });
        scheduleAutoBehavior((durationMap[name] || 2600) + 700);
        return true;
    };
    const canAutoBehave = () => Boolean(host && visibleReason === 'idle' && !isDialogOpen() && !drag && document.visibilityState !== 'hidden');
    const scheduleAutoBehavior = (delay = null) => {
        window.clearTimeout(autoBehaviorTimer);
        const wait = Number.isFinite(Number(delay))
            ? Number(delay)
            : BEHAVIOR_DELAY_MIN + Math.random() * (BEHAVIOR_DELAY_MAX - BEHAVIOR_DELAY_MIN);
        autoBehaviorTimer = window.setTimeout(() => runAutoBehavior().catch(() => scheduleAutoBehavior(2400)), wait);
    };
    const runAutoBehavior = async () => {
        if (!canAutoBehave()) {
            scheduleAutoBehavior(1800);
            return;
        }
        if (await maybeWakeOwner()) return;
        careState = normalizeCareState(careState);
        const pick = Math.random();
        if (await maybeBoredClone()) return;
        if (isPointerNearPet(660) && pick < 0.18) {
            await playIdleFlair('mouseLook');
            return;
        }
        if (careState.mood >= 82 && pick < 0.62) {
            await wanderPet({ energetic: true });
            return;
        }
        if (careState.mood <= 28 && pick < 0.35) {
            await playIdleFlair('lieDown');
            return;
        }
        if (pick < 0.52) {
            await wanderPet();
            return;
        }
        if (pick < 0.78) {
            await playIdleFlair();
            return;
        }
        if (pick < 0.88) {
            setBehavior('hop', { duration: 900 });
            await applyCareDelta({ mood: -1, exp: 1 });
            scheduleAutoBehavior(1600);
            return;
        }
        await wanderPet();
    };
    const revealPet = (reason) => {
        visibleReason = reason || 'task';
        ensurePet();
        applyPosition();
        applyVisibility();
        if (reason === 'task') setBehavior('working');
        else if (reason === 'alert') setBehavior('alert');
        else setBehavior('idleSit');
        startFrameLoop();
    };
    const concealPet = () => {
        visibleReason = 'idle';
        window.clearTimeout(hideTimer);
        toggleDialog(false);
        const speech = getShadow()?.querySelector('.speech');
        if (speech) speech.classList.remove('show');
        setMood('');
        setBehavior('idleSit');
        applyVisibility();
        scheduleAutoBehavior();
    };
    const setMood = (mood = '') => {
        if (!host) return;
        window.clearTimeout(moodTimer);
        host.classList.toggle('is-working', mood === 'working');
        host.classList.toggle('is-alert', mood === 'alert');
        const sprite = getShadow()?.querySelector('.sprite');
        if (mood === 'alert') {
            setBehavior('alert');
            if (spriteFallback && sprite) sprite.src = alertFrame;
        } else if (mood === 'working') {
            setBehavior('working');
        } else if (visibleReason === 'idle') {
            setBehavior('idleSit');
        } else if (sprite) {
            const frames = currentPetFrames();
            sprite.src = frames[frameIndex % frames.length];
        }
        if (mood === 'alert') {
            moodTimer = window.setTimeout(() => {
                if (!host) return;
                host.classList.remove('is-alert');
                const currentSprite = getShadow()?.querySelector('.sprite');
                if (visibleReason === 'idle') setBehavior('idleSit');
                else if (visibleReason === 'task') setBehavior('working');
                const frames = currentPetFrames();
                if (currentSprite) currentSprite.src = frames[frameIndex % frames.length];
            }, 4200);
        }
    };
    const showBubble = (text, force = false, mood = '') => {
        if (!host || (!state.bubble && !force)) return;
        const speech = getShadow()?.querySelector('.speech');
        if (!speech) return;
        speech.querySelector('span').textContent = text || '墨墨已整理好。';
        speech.classList.add('show');
        if (mood) setMood(mood);
        window.clearTimeout(hideTimer);
        hideTimer = window.setTimeout(() => speech.classList.remove('show'), mood === 'alert' ? 7000 : 4200);
    };
    const inferVoiceCue = (text) => {
        const value = String(text || '');
        if (/(USDT|TRC)/i.test(value) && /(入款|收到|新入款|款項)/.test(value)) {
            return { key: 'usdt_profit', text: voiceCueDefaults.usdt_profit };
        }
        if (/(提醒|警示|異常|風控|風險|失敗)/.test(value)) {
            return { key: 'alert', text: voiceCueDefaults.alert };
        }
        return null;
    };
    const getVoiceAudioContext = async () => {
        const AudioContextCtor = window.AudioContext || window.webkitAudioContext;
        if (!AudioContextCtor) return null;
        if (!voiceGestureUnlocked) return null;
        try {
            if (!activeVoiceContext || activeVoiceContext.state === 'closed') activeVoiceContext = new AudioContextCtor();
            if (activeVoiceContext.state === 'suspended') await activeVoiceContext.resume();
            return activeVoiceContext;
        } catch (error) {
            return null;
        }
    };
    const unlockVoicePlayback = () => {
        voiceGestureUnlocked = true;
        if (activeVoiceContext && activeVoiceContext.state === 'suspended') {
            activeVoiceContext.resume().catch(() => {});
        }
    };
    const toneAt = (ctx, start, freq, duration, {
        type = 'sine',
        gain = 0.05,
        endFreq = null,
        attack = 0.012,
        release = 0.05
    } = {}) => {
        const osc = ctx.createOscillator();
        const amp = ctx.createGain();
        osc.type = type;
        osc.frequency.setValueAtTime(freq, start);
        if (Number.isFinite(endFreq)) osc.frequency.exponentialRampToValueAtTime(Math.max(20, endFreq), start + duration);
        amp.gain.setValueAtTime(0.0001, start);
        amp.gain.exponentialRampToValueAtTime(Math.max(0.0001, gain), start + attack);
        amp.gain.exponentialRampToValueAtTime(0.0001, start + duration + release);
        osc.connect(amp).connect(ctx.destination);
        osc.start(start);
        osc.stop(start + duration + release + 0.02);
    };
    const noiseBurstAt = (ctx, start, duration, {
        gain = 0.035,
        filter = 'bandpass',
        freq = 900,
        q = 0.8
    } = {}) => {
        const sampleRate = ctx.sampleRate || 44100;
        const frameCount = Math.max(1, Math.floor(sampleRate * duration));
        const buffer = ctx.createBuffer(1, frameCount, sampleRate);
        const data = buffer.getChannelData(0);
        for (let i = 0; i < frameCount; i += 1) {
            const decay = 1 - (i / frameCount);
            data[i] = (Math.random() * 2 - 1) * decay;
        }
        const source = ctx.createBufferSource();
        const biquad = ctx.createBiquadFilter();
        const amp = ctx.createGain();
        biquad.type = filter;
        biquad.frequency.setValueAtTime(freq, start);
        biquad.Q.setValueAtTime(q, start);
        amp.gain.setValueAtTime(gain, start);
        amp.gain.exponentialRampToValueAtTime(0.0001, start + duration);
        source.buffer = buffer;
        source.connect(biquad).connect(amp).connect(ctx.destination);
        source.start(start);
        source.stop(start + duration + 0.02);
    };
    const pickVoiceProfile = (key, preferred = '') => {
        const explicit = cleanValue(preferred);
        if (explicit) return explicit;
        const profiles = voiceCueProfiles[key] || voiceCueProfiles.alert;
        const choices = profiles.filter(profile => profile !== lastVoiceProfile);
        const profile = (choices.length ? choices : profiles)[Math.floor(Math.random() * (choices.length ? choices.length : profiles.length))] || 'horror_call';
        lastVoiceProfile = profile;
        return profile;
    };
    const pickVoiceAsset = (key, preferred = '') => {
        const files = Array.isArray(voiceCueFiles[key]) ? voiceCueFiles[key] : [];
        if (!files.length) return '';
        const profile = cleanValue(preferred).replace(/_/g, '-').toLowerCase();
        let candidates = files;
        if (profile) {
            const token = profile.split('-')[0];
            const filtered = files.filter(file => file.toLowerCase().includes(token)
                || (token === 'comic' && file.toLowerCase().includes('comic-uncle'))
                || (token === 'horror' && file.toLowerCase().includes('horror-call'))
                || (token === 'weather' && file.toLowerCase().includes('weather-radio')));
            if (filtered.length) candidates = filtered;
        }
        const fresh = candidates.filter(file => file !== lastVoiceProfile);
        const pool = fresh.length ? fresh : candidates;
        const file = pool[Math.floor(Math.random() * pool.length)] || '';
        if (file) lastVoiceProfile = file;
        return file;
    };
    const playGeneratedVoiceProfile = async (profile) => {
        const ctx = await getVoiceAudioContext();
        if (!ctx) return false;
        const now = ctx.currentTime + 0.025;
        if (/cat/i.test(profile)) {
            toneAt(ctx, now, 760, 0.18, { type: 'triangle', gain: 0.045, endFreq: 520 });
            toneAt(ctx, now + 0.16, 920, 0.2, { type: 'sine', gain: 0.035, endFreq: 610 });
            if (/happy/i.test(profile)) toneAt(ctx, now + 0.38, 1180, 0.12, { type: 'sine', gain: 0.025, endFreq: 1450 });
            return true;
        }
        if (/dog/i.test(profile)) {
            toneAt(ctx, now, 210, 0.08, { type: 'square', gain: 0.055, endFreq: 140 });
            noiseBurstAt(ctx, now, 0.09, { gain: 0.04, freq: 520, q: 0.7 });
            toneAt(ctx, now + 0.14, 170, 0.09, { type: 'square', gain: 0.04, endFreq: 120 });
            noiseBurstAt(ctx, now + 0.14, 0.08, { gain: 0.03, freq: 430, q: 0.7 });
            return true;
        }
        if (/fox/i.test(profile)) {
            toneAt(ctx, now, 1060, 0.09, { type: 'triangle', gain: 0.04, endFreq: 1560 });
            toneAt(ctx, now + 0.1, 1520, 0.08, { type: 'sine', gain: 0.034, endFreq: 1180 });
            toneAt(ctx, now + 0.22, 1280, 0.12, { type: 'triangle', gain: 0.032, endFreq: 1720 });
            noiseBurstAt(ctx, now + 0.04, 0.05, { gain: 0.012, freq: 1800, q: 2.4 });
            return true;
        }
        if (/horror|call/i.test(profile)) {
            toneAt(ctx, now, 740, 0.34, { type: 'sine', gain: 0.035, endFreq: 710 });
            toneAt(ctx, now, 986, 0.34, { type: 'triangle', gain: 0.025, endFreq: 940 });
            toneAt(ctx, now + 0.48, 698, 0.28, { type: 'sine', gain: 0.03, endFreq: 650 });
            toneAt(ctx, now + 0.48, 932, 0.28, { type: 'triangle', gain: 0.022, endFreq: 870 });
            noiseBurstAt(ctx, now + 0.86, 0.08, { gain: 0.016, freq: 1300, q: 1.5 });
            toneAt(ctx, now + 0.9, 1180, 0.18, { type: 'sine', gain: 0.018, endFreq: 480 });
            return true;
        }
        toneAt(ctx, now, 880, 0.11, { type: 'sine', gain: 0.032, endFreq: 990 });
        toneAt(ctx, now + 0.11, 1175, 0.12, { type: 'sine', gain: 0.035, endFreq: 1320 });
        toneAt(ctx, now + 0.23, 1568, 0.16, { type: 'triangle', gain: 0.038, endFreq: 1975 });
        toneAt(ctx, now + 0.42, 2349, 0.08, { type: 'sine', gain: 0.018, endFreq: 2637 });
        return true;
    };
    const playAudioUrl = async (url) => {
        if (!url || typeof Audio === 'undefined') return false;
        try {
            if (activeVoiceAudio) {
                activeVoiceAudio.pause();
                activeVoiceAudio.currentTime = 0;
            }
            const audio = new Audio(url);
            activeVoiceAudio = audio;
            audio.volume = 0.92;
            await audio.play();
            return true;
        } catch (error) {
            return false;
        }
    };
    const playVoiceClip = async (key, preferredProfile = '') => {
        if (!key || failedVoiceCueKeys.has(key)) return false;
        const asset = pickVoiceAsset(key, preferredProfile);
        if (asset) {
            const ok = await playAudioUrl(assetUrl(asset));
            if (ok) return { ok: true, profile: asset };
        }
        const profile = pickVoiceProfile(key, preferredProfile);
        const generated = await playGeneratedVoiceProfile(profile);
        if (generated) return { ok: true, profile };
        if (!voiceGestureUnlocked) return { ok: false, profile, blockedByGesture: true };
        failedVoiceCueKeys.add(key);
        return { ok: false, profile };
    };
    const playVoiceCue = async (voice, alertText) => {
        const cue = (voice && typeof voice === 'object') ? voice : inferVoiceCue(alertText);
        if (!cue) return;
        const key = cleanValue(cue.key || 'alert') || 'alert';
        const text = cleanValue(cue.text || voiceCueDefaults[key] || alertText);
        if (!text) return;
        const dedupeKey = `${key}|${text}`;
        const now = Date.now();
        if (now - Number(voiceCueLastAt.get(dedupeKey) || 0) < 3500) return;
        voiceCueLastAt.set(dedupeKey, now);
        await playVoiceClip(key, cue.profile || cue.style || '');
    };
    const startFrameLoop = () => {
        if (frameTimer) return;
        frameTimer = window.setInterval(() => {
            if (!host || host.classList.contains('is-hidden')) return;
            const sprite = getShadow()?.querySelector('.sprite');
            if (!sprite || (spriteFallback && host.classList.contains('is-alert'))) return;
            const frames = currentPetFrames();
            frameIndex = (frameIndex + 1) % frames.length;
            sprite.src = frames[frameIndex];
        }, 360);
    };
    const formatUsdt2 = (amount) => Number(amount || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    const renderTrcBalance = (balance) => {
        ensurePet();
        const base = getShadow()?.querySelector('.base');
        const text = getShadow()?.querySelector('.balance-text');
        if (!base || !text) return;
        const amount = Number(balance?.amount);
        if (!Number.isFinite(amount)) {
            base.classList.add('is-empty');
            text.textContent = 'USDT --';
            return;
        }
        base.classList.remove('is-empty');
        text.textContent = `${formatUsdt2(amount)} USDT`;
    };

    const renderTask = (task) => {
        ensurePet();
        const shadow = getShadow();
        if (!shadow) return;
        const dialogText = shadow.querySelector('.dialog-text');
        const taskPanel = shadow.querySelector('.task');
        const title = shadow.querySelector('.task-title');
        const body = shadow.querySelector('.task-body');
        const copyActions = shadow.querySelector('.copy-actions');
        const copy = shadow.querySelector('.copy-main-btn');
        const copyTime = shadow.querySelector('.copy-time-btn');
        const carePanel = shadow.querySelector('.care-panel');
        lastTask = task || null;
        if (!task || !task.copyText) {
            dialogText.textContent = careGreeting();
            taskPanel.hidden = true;
            copyActions.hidden = true;
            if (carePanel) carePanel.hidden = false;
            copy.disabled = true;
            copyTime.disabled = true;
            title.textContent = '';
            body.textContent = '';
            renderCarePanel();
            return;
        }
        dialogText.textContent = `我找到 ${task.title}，內容已整理好。`;
        taskPanel.hidden = false;
        copyActions.hidden = false;
        if (carePanel) carePanel.hidden = true;
        copy.disabled = false;
        copyTime.disabled = !task.time;
        title.textContent = task.meta ? `${task.title}｜${task.meta}` : task.title;
        body.textContent = task.copyText.trim();
    };
    const taskKey = (task) => {
        const no = cleanValue(task?.no);
        if (no) return [task?.type || task?.title, no].filter(Boolean).join('|');
        return [task?.title, task?.acc, task?.amt, task?.copyText].filter(Boolean).join('|');
    };
    const resetPresentedTasksForClosedModal = () => {
        if (autoPresentedTaskKeys.size) autoPresentedTaskKeys.clear();
        lastTaskKey = '';
    };
    const yongxuCvsAlertKey = (alert) => {
        const direct = cleanValue(alert?.key || alert?.alertKey);
        if (direct) return direct;
        const orderNos = yongxuCvsOrderNos(alert);
        return orderNos.length ? `${cleanValue(alert?.alertDate || '')}|${orderNos.slice().sort().join(',')}` : '';
    };
    const yongxuCvsOrderNos = (alert) => {
        const values = [
            ...(Array.isArray(alert?.orderNos) ? alert.orderNos : []),
            ...(Array.isArray(alert?.abnormalRows) ? alert.abnormalRows.map(row => row && row.orderNo) : []),
            alert?.orderNo
        ];
        const seen = new Set();
        return values
            .map(cleanValue)
            .filter(Boolean)
            .filter(value => {
                if (seen.has(value)) return false;
                seen.add(value);
                return true;
            });
    };
    const clearYongxuCvsAlertIfActive = () => {
        if (activePersistentAlert?.kind !== 'yongxu_cvs_abnormal' && lastTask?.type !== 'yongxu_cvs_abnormal') return;
        activePersistentAlert = null;
        renderTask(null);
        concealPet();
    };
    const showYongxuCvsAlert = async (alert, { forceVoice = false } = {}) => {
        const orderNos = yongxuCvsOrderNos(alert);
        if (!orderNos.length || !alert?.abnormal) return false;
        const key = yongxuCvsAlertKey(alert);
        const data = await storageGet(['momoYongxuCvsDismissedKey']);
        if (data.momoYongxuCvsDismissedKey === key) return false;
        const count = orderNos.length;
        const copyText = orderNos.join('\n');
        const task = {
            type: 'yongxu_cvs_abnormal',
            title: count > 1 ? '超商預約異常清單' : '超商預約異常',
            no: orderNos.join(','),
            meta: count > 1 ? `${count} 筆` : orderNos[0],
            copyText,
            time: ''
        };
        activePersistentAlert = { kind: 'yongxu_cvs_abnormal', key, orderNo: orderNos[0], orderNos };
        window.clearTimeout(alertTimer);
        renderTask(task);
        revealPet('alert');
        setMood('alert');
        const dialogText = getShadow()?.querySelector('.dialog-text');
        if (dialogText) dialogText.textContent = count > 1
            ? `發現 ${count} 筆尚未提示過的超商預約異常，商戶訂單號已整理好。`
            : '最新超商單出現預約異常，商戶訂單號已整理好。';
        toggleDialog(true);
        showBubble(count > 1 ? `超商預約異常 ${count} 筆` : `超商預約異常：${orderNos[0]}`, true, 'alert');
        if (forceVoice) void playVoiceCue({ key: 'cvs_alert', text: '超商預約異常，請確認商戶訂單號。' }, `超商預約異常：${orderNos.join('、')}`);
        await applyCareDelta({ mood: -1, bond: 1, exp: 3 });
        return true;
    };
    const restoreYongxuCvsAlert = async (alert = null) => {
        const current = alert || (await storageGet(['momoYongxuCvsAlert'])).momoYongxuCvsAlert;
        if (current?.abnormal) return showYongxuCvsAlert(current);
        clearYongxuCvsAlertIfActive();
        return false;
    };
    const showDetectedTask = async (task) => {
        if (!task?.copyText) return null;
        window.clearTimeout(alertTimer);
        const key = taskKey(task);
        const alreadyPresented = autoPresentedTaskKeys.has(key);
        lastTaskKey = key;
        if (alreadyPresented) {
            if (!isDialogOpen()) {
                renderTask(null);
                if (visibleReason === 'task') concealPet();
            }
            return task;
        }
        renderTask(task);
        revealPet('task');
        setMood('working');
        autoPresentedTaskKeys.add(key);
        toggleDialog(true);
        showBubble(`找到${task.title}，內容已整理。`, true, 'working');
        await storageSet({ momoAssistantLastOrder: task });
        await applyCareDelta({ mood: 3, bond: 2, exp: 5 });
        return task;
    };
    const showAlert = (text, mood = 'alert', voice = null) => {
        ensurePet();
        renderTask(null);
        revealPet('alert');
        const dialogText = getShadow()?.querySelector('.dialog-text');
        if (dialogText) dialogText.textContent = text || '墨墨提醒。';
        toggleDialog(true);
        showBubble(text || '墨墨提醒。', true, mood);
        void playVoiceCue(voice, text);
        window.clearTimeout(alertTimer);
        alertTimer = window.setTimeout(() => {
            if (visibleReason === 'alert' && !lastTask) concealPet();
        }, 12000);
    };

    const ORDER_LABELS = ['存款單號', '存款单号', '提款單號', '提款单号', '單號', '单号', '訂單號', '订单号', '交易單號', '交易单号', '交易編號', '交易编号', '編號', '编号'];
    const ACCOUNT_LABELS = ['會員帳號', '会员帐号', '會員账号', '会员账号', '帳號', '账号'];
    const METHOD_LABELS = ['銀行', '银行', '收款銀行', '收款银行', '收款方式', '付款方式', '支付方式', '存款方式', '提款方式', '通道名稱', '通道名称', '渠道名稱', '渠道名称', '支付通道'];
    const USDT_HINT_LABELS = ['幣別', '币别', '幣種', '币种', '鏈類型', '链类型', '鏈別', '链别', '協議', '协议', '充值方式', '提款方式', '提領方式', '提领方式'];
    const TIME_LABELS = ['存款時間', '存款时间', '提款時間', '提款时间', '申請日期', '申请日期', '時間', '时间'];
    const STANDARD_DEPOSIT_AMOUNT_LABELS = ['金額', '金额', '實際金額', '实际金额'];
    const STANDARD_WITHDRAW_AMOUNT_LABELS = ['金額', '金额', '實際金額', '实际金额', '實際提領金額', '实际提领金额', '實際出款金額', '实际出款金额'];
    const USDT_DEPOSIT_AMOUNT_LABELS = ['USDT數量', 'USDT 数量', 'USDT数量', 'USDT金額', 'USDT 金額', 'USDT金额', 'U數量', 'U数量', '充值數量', '充值数量', '數量', '数量', '實際金額', '实际金额', '金額', '金额'];
    const USDT_WITHDRAW_AMOUNT_LABELS = ['USDT數量', 'USDT 数量', 'USDT数量', 'USDT金額', 'USDT 金額', 'USDT金额', 'U數量', 'U数量', '提領數量', '提领数量', '提領USDT', '提领USDT', '實際提領金額', '实际提领金额', '實際出款金額', '实际出款金额', '數量', '数量', '實際金額', '实际金额', '金額', '金额'];
    const KNOWN_LABELS = [
        ...ORDER_LABELS,
        ...ACCOUNT_LABELS,
        ...METHOD_LABELS,
        ...USDT_HINT_LABELS,
        ...TIME_LABELS,
        ...STANDARD_DEPOSIT_AMOUNT_LABELS,
        ...STANDARD_WITHDRAW_AMOUNT_LABELS,
        ...USDT_DEPOSIT_AMOUNT_LABELS,
        ...USDT_WITHDRAW_AMOUNT_LABELS,
        '會員資料', '会员资料', '會員ID', '会员ID', '全名', '代理', '優惠資料', '优惠资料', '投注量', '從', '从', '累積打碼量', '累计打码量', '所需打碼量', '所需打码量'
    ];
    const MODAL_SELECTOR = '[role="dialog"], .modal, .modal-dialog, .modal-content, .modal-body, .el-dialog, .ant-modal, .ant-modal-content, .layui-layer, .swal2-popup, .ui-dialog, .ui-dialog-content, .bootbox';
    const ORDER_MARKER_SELECTOR = 'td, th, dt, dd, label, span, p, li, div';
    const normalizeLabel = (text) => clean(text).replace(/[：:]+$/, '');
    const sameLabel = (text, labels) => {
        const normalized = normalizeLabel(text);
        return labels.some(label => normalized === normalizeLabel(label));
    };
    const isKnownLabelText = (text) => {
        const normalized = normalizeLabel(text);
        if (!normalized) return true;
        return KNOWN_LABELS.some(label => normalized === normalizeLabel(label));
    };
    const containsLabelNoise = (text) => {
        const normalized = normalizeLabel(text);
        if (!normalized) return true;
        const hits = KNOWN_LABELS.reduce((sum, label) => sum + (normalized.includes(normalizeLabel(label)) ? 1 : 0), 0);
        return hits >= 2 && !/\b[DW][A-Z0-9][A-Z0-9-]{4,}\b/i.test(text);
    };
    const visibleText = (root) => cleanValue(root?.innerText || root?.textContent || '');
    const isVisibleElement = (el) => {
        if (!el || el === document.body) return true;
        if (typeof Element !== 'undefined' && !(el instanceof Element)) return false;
        const style = window.getComputedStyle ? window.getComputedStyle(el) : null;
        if (style && (style.display === 'none' || style.visibility === 'hidden')) return false;
        const rects = typeof el.getClientRects === 'function' ? el.getClientRects() : null;
        return rects ? rects.length > 0 : visibleText(el).length > 0;
    };
    const hasModalIdentity = (el) => {
        if (!el || el === document.body) return false;
        const role = String(el.getAttribute?.('role') || '').toLowerCase();
        const className = String(el.className || '').toLowerCase();
        return role === 'dialog' || /modal|dialog|layui-layer|swal2|bootbox|ui-dialog|el-dialog|ant-modal/.test(className);
    };
    const isActiveModalRoot = (el) => {
        if (!el || el === document.body || !isVisibleElement(el) || !hasModalIdentity(el)) return false;
        const text = visibleText(el);
        if (!text || text.length < 40 || text.length > 32000) return false;
        if (!/單據處理|存款|提款|出款|提領|提领|充值|訂單|订单|單號|单号|[DW][A-Z0-9][A-Z0-9-]{4,}/i.test(text)) return false;
        return /(存款單號|存款单号|提款單號|提款单号|[DW][A-Z0-9][A-Z0-9-]{4,})/i.test(text);
    };
    const closestActiveModal = (el) => {
        let current = el;
        while (current && current !== document.body) {
            if (current.matches?.(MODAL_SELECTOR) && isActiveModalRoot(current)) return current;
            current = current.parentElement;
        }
        return null;
    };
    const cleanFieldValue = (raw, maxLen = 180) => {
        const value = cleanValue(raw).replace(/\s+/g, ' ');
        if (!value || value.length > maxLen || value === '無資料' || value === '--' || value === '-') return '';
        if (isKnownLabelText(value) || containsLabelNoise(value)) return '';
        return value;
    };
    const inlineValue = (raw, labels) => {
        const source = cleanValue(raw);
        if (!source || source.length > 180) return '';
        for (const label of labels) {
            const match = source.match(new RegExp(`^\\s*${escapeRegExp(label)}(?:\\s*[:：-]\\s*|\\s+)(.+)$`, 'i'));
            if (match) return cleanFieldValue(match[1].split(/[\n\r\t|]/)[0]);
        }
        return '';
    };
    const textValue = (text, labels) => {
        const lines = String(text || '').split(/\n+/).map(line => cleanValue(line)).filter(Boolean);
        for (let i = 0; i < lines.length; i += 1) {
            for (const label of labels) {
                const inline = inlineValue(lines[i], [label]);
                if (inline) return inline;
                if (sameLabel(lines[i], [label]) && lines[i + 1]) {
                    const next = cleanFieldValue(lines[i + 1]);
                    if (next) return next;
                }
            }
        }
        const source = String(text || '').slice(0, 6000);
        for (const label of labels) {
            const match = source.match(new RegExp(`${escapeRegExp(label)}(?:\\s*[:：-]\\s*|\\s+)([^\\n\\r\\t|]{1,100})`, 'i'));
            if (match) {
                const value = cleanFieldValue(match[1].split(/\s{2,}/)[0]);
                if (value) return value;
            }
        }
        return '';
    };
    const fieldScope = (el, root) => {
        let current = el;
        while (current && current !== root && current !== document.body) {
            const tag = String(current.tagName || '').toUpperCase();
            const className = String(current.className || '').toLowerCase();
            if (/^(TABLE|DL|FIELDSET|FORM)$/.test(tag) || /table|panel|box|card|detail|info|form|資料|资料|單據|单据/.test(className)) {
                return current;
            }
            current = current.parentElement;
        }
        return root;
    };
    const addRow = (rows, label, value, source = 'dom', scope = null) => {
        const cleanLabel = normalizeLabel(label);
        const cleanRaw = cleanFieldValue(value);
        if (!cleanLabel || !cleanRaw) return;
        rows.push({ label: cleanLabel, raw: cleanRaw, source, scope });
    };
    const collectRows = (root) => {
        const rows = [];
        const trList = Array.from(root.querySelectorAll?.('tr') || []);
        for (const tr of trList) {
            if (!isVisibleElement(tr)) continue;
            const scope = fieldScope(tr, root);
            const cells = Array.from(tr.children || []).filter(cell => /^(TD|TH)$/i.test(cell.tagName || ''));
            for (let i = 0; i < cells.length - 1; i += 2) addRow(rows, visibleText(cells[i]), visibleText(cells[i + 1]), 'tr', scope);
        }
        const dts = Array.from(root.querySelectorAll?.('dt') || []);
        for (const dt of dts) {
            if (!isVisibleElement(dt)) continue;
            const dd = dt.nextElementSibling;
            if (dd && /DD/i.test(dd.tagName || '')) addRow(rows, visibleText(dt), visibleText(dd), 'dl', fieldScope(dt, root));
        }
        const fields = Array.from(root.querySelectorAll?.('td, th, label, span, p, li, div') || []);
        for (const el of fields) {
            if (!isVisibleElement(el)) continue;
            const raw = visibleText(el);
            if (!raw || raw.length > 180) continue;
            const scope = fieldScope(el, root);
            const next = el.nextElementSibling;
            if (next) addRow(rows, raw, visibleText(next), 'sibling', scope);
            for (const labels of [ORDER_LABELS, ACCOUNT_LABELS, METHOD_LABELS, USDT_HINT_LABELS, TIME_LABELS, USDT_DEPOSIT_AMOUNT_LABELS, USDT_WITHDRAW_AMOUNT_LABELS, STANDARD_DEPOSIT_AMOUNT_LABELS, STANDARD_WITHDRAW_AMOUNT_LABELS]) {
                const value = inlineValue(raw, labels);
                if (value) addRow(rows, labels.find(label => raw.toLowerCase().includes(label.toLowerCase())) || raw, value, 'inline', scope);
            }
        }
        return rows;
    };
    const findRows = (rows, labels) => rows.filter(row => sameLabel(row.label, labels) && cleanFieldValue(row.raw));
    const findValue = (rows, labels, fallbackText = '') => findRows(rows, labels)[0]?.raw || textValue(fallbackText, labels);
    const looksLikeTimeValue = (value) => /\d{4}[-/]\d{1,2}[-/]\d{1,2}/.test(value) || /\d{1,2}:\d{2}(?::\d{2})?/.test(value);
    const parseAmount = (raw) => {
        const text = cleanValue(raw);
        const patterns = [
            /(?:USDT|U)\s*[:：]?\s*([+-]?[\d,]+(?:\.\d+)?)/i,
            /([+-]?[\d,]+(?:\.\d+)?)\s*(?:USDT|U)\b/i,
            /([+-]?[\d,]+(?:\.\d+)?)/,
        ];
        for (const pattern of patterns) {
            const match = text.match(pattern);
            if (match) return match[1].replace(/,/g, '');
        }
        return '';
    };
    const amountScore = ({ label, raw }, isUsdt) => {
        const text = `${label} ${raw}`.toUpperCase();
        if (/USDT|TRC|ERC|TRON|\bU\b/.test(text)) return 100;
        if (/提領數量|提领数量|充值數量|充值数量|數量|数量|U數量|U数量/.test(label)) return isUsdt ? 90 : 5;
        if (/實際提領金額|实际提领金额|實際出款金額|实际出款金额/.test(label)) return 80;
        if (/實際金額|实际金额/.test(label)) return 60;
        if (/金額|金额/.test(label)) return 40;
        return 0;
    };
    const findAmount = (rows, labels, fallbackText, isUsdt) => {
        const candidates = findRows(rows, labels)
            .map(row => ({ ...row, amount: parseAmount(row.raw), score: amountScore(row, isUsdt) }))
            .filter(row => row.amount);
        candidates.sort((a, b) => b.score - a.score);
        if (candidates[0]?.amount) return candidates[0].amount;
        return parseAmount(textValue(fallbackText, labels));
    };
    const findTime = (rows, type, scopes = null) => {
        const sourceRows = scopes?.size ? rows.filter(row => row.scope && scopes.has(row.scope)) : rows;
        const fromRows = (labels) => findRows(sourceRows, labels)
            .map(row => cleanFieldValue(row.raw, 80))
            .find(looksLikeTimeValue) || '';
        if (type === 'deposit') {
            return fromRows(['存款時間', '存款时间'])
                || fromRows(['申請日期', '申请日期'])
                || fromRows(['時間', '时间']);
        }
        return fromRows(['提款時間', '提款时间'])
            || fromRows(['申請日期', '申请日期'])
            || fromRows(['時間', '时间']);
    };
    const detectMethod = (raw) => {
        const text = String(raw || '').toUpperCase();
        if (/USDT|TRC|ERC|TRON/.test(text)) return 'USDT';
        if (/ALIPAY|支付寶|支付宝/.test(text)) return '支付寶';
        if (/超商|便利商店|CVS|IBON|FAMIPORT|全家|萊爾富|OK\s?MART|OK超商|7[-\s]?11|7ELEVEN|SEVEN/.test(text)) return '超商';
        if (/WECHAT|微信/.test(text)) return '微信';
        if (/ATM/.test(text)) return 'ATM';
        if (/網銀|网银|銀行轉帳|银行转账/.test(text)) return '網銀';
        return cleanValue(raw) || '入款';
    };
    const buildCopyText = (type, isUsdt, data) => {
        const v = (field) => cleanValue(data[field]);
        if (type === 'deposit') return [todayStr(), isUsdt ? '入款' : detectMethod(data.method), v('no'), v('acc'), v('amt')].join('\t');
        if (type === 'withdraw') return [todayStr(), '出款', v('no'), v('acc'), '', v('amt')].join('\t');
        return '';
    };
    const normalizeOrderNo = (raw) => {
        const match = String(raw || '').match(/\b([DW][A-Z0-9][A-Z0-9-]{4,})\b/i);
        return match ? match[1].trim() : '';
    };
    const orderScopesFor = (rows, no) => {
        const scopes = new Set();
        const normalizedNo = normalizeOrderNo(no);
        rows.forEach(row => {
            const rowNo = normalizeOrderNo(`${row.label} ${row.raw}`);
            if (row.scope && rowNo && (!normalizedNo || rowNo.toUpperCase() === normalizedNo.toUpperCase())) scopes.add(row.scope);
        });
        return scopes;
    };
    const getCandidateRoots = () => {
        const roots = new Set();
        const add = (el) => {
            const modal = closestActiveModal(el) || (isActiveModalRoot(el) ? el : null);
            if (modal) roots.add(modal);
        };
        const modalRoots = Array.from(document.querySelectorAll(MODAL_SELECTOR))
            .filter(isActiveModalRoot);
        modalRoots.forEach(root => roots.add(root));
        if (!modalRoots.length) return [];
        const markers = [];
        for (const root of modalRoots) {
            const nodes = root.querySelectorAll(ORDER_MARKER_SELECTOR);
            let scanned = 0;
            for (const el of nodes) {
                const text = visibleText(el);
                if (!text || text.length > 180) {
                    scanned += 1;
                    if (scanned >= 480) break;
                    continue;
                }
                if (sameLabel(text, ORDER_LABELS) || inlineValue(text, ORDER_LABELS) || /\b[DW][A-Z0-9][A-Z0-9-]{4,}\b/i.test(text)) {
                    markers.push(el);
                    if (markers.length >= 120) break;
                }
                scanned += 1;
                if (scanned >= 480) break;
            }
            if (markers.length >= 120) break;
        }
        for (const marker of markers) add(marker);
        return Array.from(roots);
    };
    const buildTaskFromRoot = (root) => {
        if (!isActiveModalRoot(root)) return null;
        const rootText = visibleText(root);
        if (!/(存款|提款|出款|提領|提领|充值|訂單|订单|單號|单号|[DW][A-Z0-9][A-Z0-9-]{4,})/i.test(rootText.slice(0, 12000))) return null;
        const rows = collectRows(root);
        let no = normalizeOrderNo(findValue(rows, ORDER_LABELS, rootText)) || normalizeOrderNo(rootText);
        if (!no) return null;
        const prefix = no.charAt(0).toUpperCase();
        if (prefix !== 'D' && prefix !== 'W') return null;
        const type = prefix === 'W' ? 'withdraw' : 'deposit';
        const acc = findValue(rows, ACCOUNT_LABELS, rootText);
        const methodRaw = findValue(rows, METHOD_LABELS, rootText);
        const hintRaw = findValue(rows, USDT_HINT_LABELS, rootText);
        const usdtEvidence = `${methodRaw} ${hintRaw} ${findRows(rows, [...USDT_DEPOSIT_AMOUNT_LABELS, ...USDT_WITHDRAW_AMOUNT_LABELS]).map(row => `${row.label} ${row.raw}`).join(' ')}`;
        const isUsdt = /USDT|TRC20?|ERC20?|TRON|虛擬貨幣|虚拟货币|泰達|泰达/i.test(usdtEvidence);
        const amountLabels = type === 'withdraw'
            ? (isUsdt ? USDT_WITHDRAW_AMOUNT_LABELS : STANDARD_WITHDRAW_AMOUNT_LABELS)
            : (isUsdt ? USDT_DEPOSIT_AMOUNT_LABELS : STANDARD_DEPOSIT_AMOUNT_LABELS);
        const amt = findAmount(rows, amountLabels, rootText, isUsdt);
        const time = findTime(rows, type, orderScopesFor(rows, no));
        if (!isValidValue(acc) || !isValidValue(amt)) return null;
        const data = { no, acc, amt, method: methodRaw, time };
        const title = `${isUsdt ? 'USDT ' : ''}${type === 'withdraw' ? '提款工單' : '存款工單'}`;
        const copyText = buildCopyText(type, isUsdt, data);
        const score = 40
            + (acc ? 20 : 0)
            + (amt ? 20 : 0)
            + (methodRaw ? 8 : 0)
            + (/單據處理|工單|存款|提款/.test(rootText.slice(0, 1000)) ? 8 : 0)
            + (root === document.body ? -18 : 0)
            + Math.max(0, 8 - Math.floor(rootText.length / 3000));
        return {
            score,
            size: rootText.length,
            task: {
                title,
                type,
                isUsdt,
                no,
                acc: cleanFieldValue(acc, 80),
                amt: cleanFieldValue(amt, 40),
                time: cleanFieldValue(time, 80),
                copyText,
                meta: [no, acc, amt && `${amt}${isUsdt ? ' USDT' : ''}`].filter(Boolean).join(' · '),
                updatedAt: Date.now()
            }
        };
    };
    const detectOrderFromPage = () => {
        if (!document.body) return null;
        const best = getCandidateRoots()
            .map(buildTaskFromRoot)
            .filter(Boolean)
            .filter(result => result.score >= 70)
            .sort((a, b) => b.score - a.score || a.size - b.size)[0];
        return best?.task || null;
    };

    const isRankPage = () => {
        try {
            return /(?:^|\/)rank(?:[/?#]|$)|rank/i.test(`${window.location?.pathname || ''}${window.location?.search || ''}${window.location?.hash || ''}`);
        } catch (error) {
            return false;
        }
    };
    const YESTERDAY_RANK_RE = /昨日|昨天|昨日排行榜|昨天排行榜|yesterday/i;
    const RANK_ACCOUNT_RE = /\b(?=[a-z0-9_]{4,30}\b)(?=[a-z0-9_]*\d)[a-z][a-z0-9_]*\b/i;
    const RANK_ACCOUNT_EXCLUDE_RE = /^(rank|ranking|yesterday|today|tomorrow|account|username|member|user|admin|null|undefined|vip\d*|usdt|twd)$/i;
    const normalizeRankSignalAccounts = (signal) => {
        if (!signal || !Array.isArray(signal.accounts)) return [];
        const fresh = !signal.receivedAt || Date.now() - Number(signal.receivedAt || 0) < 180000;
        if (!fresh) return [];
        return signal.accounts
            .map(account => cleanValue(account))
            .filter(account => RANK_ACCOUNT_RE.test(account) && !RANK_ACCOUNT_EXCLUDE_RE.test(account) && !String(account).includes('*'))
            .slice(0, 80);
    };
    const setRankSignalCache = (signal) => {
        rankSignalAccounts = normalizeRankSignalAccounts(signal);
        lastRankSignalAt = rankSignalAccounts.length ? Date.now() : 0;
    };
    const rankQuickText = (el, max = 800) => cleanAlertCellText(String(el?.textContent || '').slice(0, max));
    const isYesterdayRankActive = () => Array.from(document.querySelectorAll('a, button, [role="tab"], .nav-tabs li, .nav-tabs .active, .tabs .active, .tab-menu .active, .selected'))
        .filter(isVisibleElement)
        .some(el => {
            const text = rankQuickText(el, 180);
            if (text.length > 140) return false;
            if (!YESTERDAY_RANK_RE.test(text)) return false;
            const selected = String(el.getAttribute?.('aria-selected') || '').toLowerCase() === 'true';
            const className = String(el.className || '').toLowerCase();
            return selected || /active|selected|current/.test(className) || /排行榜/.test(text);
        });
    const hasYesterdayRankContext = (el, activeYesterday = false) => {
        let current = el;
        let depth = 0;
        while (current && current !== document.body && depth < 7) {
            const text = rankQuickText(current, 6000);
            if (text && text.length < 6000 && YESTERDAY_RANK_RE.test(text)) return true;
            current = current.parentElement;
            depth += 1;
        }
        return activeYesterday;
    };
    const accountFromRankRow = (row) => {
        const directNodes = Array.from(row?.querySelectorAll?.('[data-account], [data-username], a, button') || []);
        for (const node of directNodes) {
            const text = cleanAlertCellText(node.getAttribute?.('data-account') || node.getAttribute?.('data-username') || visibleText(node));
            const match = text.match(RANK_ACCOUNT_RE);
            if (match && !RANK_ACCOUNT_EXCLUDE_RE.test(match[0])) return match[0];
        }
        const cells = Array.from(row?.querySelectorAll?.('td, th, [role="cell"], span, div') || []);
        for (const cell of cells) {
            const text = cleanAlertCellText(visibleText(cell));
            if (!text || text.length > 120) continue;
            if (/排行|名次|昨日|今天|今日|金額|金额|彩金|獎金|奖金|輸贏|输赢|投注|有效|排名/i.test(text)) continue;
            const match = text.match(RANK_ACCOUNT_RE);
            if (match && !RANK_ACCOUNT_EXCLUDE_RE.test(match[0])) return match[0];
        }
        const rowText = cleanAlertCellText(visibleText(row));
        const match = rowText.match(RANK_ACCOUNT_RE);
        return match && !RANK_ACCOUNT_EXCLUDE_RE.test(match[0]) ? match[0] : '';
    };
    const detectYesterdayRankAccounts = () => {
        if (!isRankPage() || !document.body) return [];
        const seen = new Set();
        const accounts = [];
        const addAccount = (account) => {
            const value = cleanValue(account);
            const key = value.toLowerCase();
            if (!value || seen.has(key) || !RANK_ACCOUNT_RE.test(value) || RANK_ACCOUNT_EXCLUDE_RE.test(value) || value.includes('*')) return;
            seen.add(key);
            accounts.push(value);
        };
        if (Date.now() - lastRankSignalAt < 180000) rankSignalAccounts.forEach(addAccount);
        const now = Date.now();
        if (now - lastRankScanAt < 1400) return accounts;
        lastRankScanAt = now;
        const pageText = rankQuickText(document.body, 4000);
        const activeYesterday = isYesterdayRankActive() || YESTERDAY_RANK_RE.test(pageText);
        const rankContext = activeYesterday || /排行榜|排名|rank/i.test(pageText);
        const rows = Array.from(document.querySelectorAll('tbody tr, tr, [role="row"], li, .rank-item, .ranking-item, .list-group-item'))
            .filter(isVisibleElement)
            .filter(row => rankContext || hasYesterdayRankContext(row, false))
            .slice(0, 200);
        rows.map(accountFromRankRow).forEach(addAccount);
        return accounts;
    };
    const detectYesterdayRankTask = () => {
        const accounts = detectYesterdayRankAccounts();
        if (!accounts.length) return null;
        const key = accounts.join('|').toLowerCase();
        if (key === lastRankAccountsKey) return null;
        lastRankAccountsKey = key;
        return {
            type: 'rank_yesterday_accounts',
            title: '昨日排行榜帳號',
            no: `rank-yesterday-${key.slice(0, 90)}`,
            meta: `${accounts.length} 筆`,
            acc: accounts[0],
            amt: String(accounts.length),
            copyText: accounts.join('\n'),
            time: ''
        };
    };

    const runAutoScan = async () => {
        if (isUserCopyingOrSelecting()) {
            scheduleAutoScan(300);
            return null;
        }
        const rankTask = detectYesterdayRankTask();
        if (rankTask) return showDetectedTask(rankTask);
        const task = detectOrderFromPage();
        if (task) return showDetectedTask(task);
        resetPresentedTasksForClosedModal();
        if (visibleReason === 'task') {
            renderTask(null);
            concealPet();
        }
        return null;
    };
    const runAutoScanSafely = async () => {
        if (autoScanInFlight) {
            autoScanQueued = true;
            return null;
        }
        autoScanInFlight = true;
        try {
            return await runAutoScan();
        } finally {
            autoScanInFlight = false;
            autoScanLastAt = Date.now();
            if (autoScanQueued) {
                autoScanQueued = false;
                scheduleAutoScan(240);
            }
        }
    };
    const scheduleAutoScan = (delay = 650) => {
        window.clearTimeout(autoScanTimer);
        clearIdleScanHandle();
        if (autoScanInFlight) {
            autoScanQueued = true;
            return;
        }
        if (isUserCopyingOrSelecting()) {
            window.clearTimeout(deferredAutoScanTimer);
            const wait = pointerInteractionActive ? 420 : Math.max(180, interactionPauseUntil - Date.now() + delay);
            deferredAutoScanTimer = window.setTimeout(() => {
                deferredAutoScanTimer = 0;
                scheduleAutoScan(delay);
            }, wait);
            return;
        }
        const now = Date.now();
        const minGapDelay = Math.max(0, AUTO_SCAN_MIN_GAP_MS - (now - autoScanLastAt));
        window.clearTimeout(deferredAutoScanTimer);
        autoScanTimer = window.setTimeout(() => {
            autoScanTimer = 0;
            const run = () => {
                idleScanHandle = 0;
                if (isUserCopyingOrSelecting()) {
                    scheduleAutoScan(350);
                    return;
                }
                runAutoScanSafely().catch(() => {});
            };
            if (typeof window.requestIdleCallback === 'function') {
                idleScanHandle = window.requestIdleCallback(run, { timeout: 1600 });
            } else {
                idleScanHandle = window.setTimeout(run, 80);
            }
        }, Math.max(0, Number(delay) || 0, minGapDelay));
    };
    const scheduleAutoScanBurst = (delays = [260, 900, 1800, 3200]) => {
        scanBurstTimers.forEach(timer => window.clearTimeout(timer));
        const uniqDelays = [...new Set((Array.isArray(delays) ? delays : []).map(item => Math.max(0, Number(item) || 0)))];
        scanBurstTimers = uniqDelays.slice(0, 8).map(delay => window.setTimeout(() => scheduleAutoScan(0), delay));
    };
    const bootAutoScan = () => {
        if (scanBooted) return;
        scanBooted = true;
        const start = () => {
            if (!document.body) {
                window.setTimeout(start, 300);
                return;
            }
            ensurePet();
            applyPosition();
            applyVisibility();
            INITIAL_SCAN_DELAYS.forEach(delay => window.setTimeout(() => scheduleAutoScan(0), delay));
            if (!rankPollTimer && isRankPage()) {
                rankPollTimer = window.setInterval(() => {
                    if (!isUserCopyingOrSelecting()) scheduleAutoScan(1200);
                }, 12000);
            }
        };
        if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, { once: true });
        else start();
    };

    const copyText = async (text) => {
        pauseScanningForUserCopy(2600);
        const value = cleanValue(text);
        if (!value) return false;
        try {
            await navigator.clipboard.writeText(value);
            return true;
        } catch (error) {
            const textarea = document.createElement('textarea');
            textarea.value = value;
            textarea.setAttribute('readonly', 'readonly');
            textarea.style.cssText = 'position:fixed;left:-9999px;top:-9999px;opacity:0;';
            document.body.appendChild(textarea);
            textarea.select();
            const ok = document.execCommand('copy');
            textarea.remove();
            return ok;
        }
    };
    const copyLastTask = async () => {
        if (!lastTask?.copyText) return;
        await markOwnerInteraction();
        const ok = await copyText(lastTask.copyText);
        if (ok) await applyCareDelta({ mood: 4, bond: 3, exp: 4 });
        showBubble(ok ? '已複製。' : '複製失敗，請手動選取內容。', true, ok ? 'working' : 'alert');
    };
    const copyLastTaskTime = async () => {
        if (!lastTask?.time) return;
        await markOwnerInteraction();
        const ok = await copyText(lastTask.time);
        if (ok) await applyCareDelta({ mood: 2, bond: 1, exp: 2 });
        showBubble(ok ? '已複製時間。' : '複製失敗，請手動選取時間。', true, ok ? 'working' : 'alert');
    };

    const onDragStart = (event) => {
        if (!host || event.button > 0) return;
        window.clearTimeout(autoBehaviorTimer);
        stopMotion();
        setBehavior('drag');
        const rect = host.getBoundingClientRect();
        host.style.left = `${rect.left}px`;
        host.style.top = `${rect.top}px`;
        host.style.right = 'auto';
        host.style.bottom = 'auto';
        drag = { startX: event.clientX, startY: event.clientY, left: rect.left, top: rect.top, moved: false };
        event.preventDefault();
        window.addEventListener('pointermove', onDragMove, true);
        window.addEventListener('pointerup', onDragEnd, true);
    };
    const onDragMove = (event) => {
        if (!drag || !host) return;
        const dx = event.clientX - drag.startX;
        const dy = event.clientY - drag.startY;
        if (Math.abs(dx) + Math.abs(dy) > 4) drag.moved = true;
        const width = host.offsetWidth || 162;
        const height = host.offsetHeight || 190;
        host.style.left = `${clamp(drag.left + dx, 8, Math.max(8, window.innerWidth - width - 8))}px`;
        host.style.top = `${clamp(drag.top + dy, 8, Math.max(8, window.innerHeight - height - 8))}px`;
    };
    const onDragEnd = async () => {
        if (!drag || !host) return;
        window.removeEventListener('pointermove', onDragMove, true);
        window.removeEventListener('pointerup', onDragEnd, true);
        const rect = host.getBoundingClientRect();
        state.position = { left: Math.round(rect.left), top: Math.round(rect.top) };
        await storageSet({ [STORE.position]: state.position });
        await markOwnerInteraction();
        if (visibleReason === 'idle') setBehavior('idleSit');
        scheduleAutoBehavior(1800);
        setTimeout(() => { drag = null; }, 0);
    };
    const applyPosition = () => {
        if (!host) return;
        const pos = state.position;
        if (pos && Number.isFinite(Number(pos.left)) && Number.isFinite(Number(pos.top))) {
            const width = host.offsetWidth || 162;
            const height = host.offsetHeight || 190;
            host.style.left = `${clamp(Number(pos.left), 8, Math.max(8, window.innerWidth - width - 8))}px`;
            host.style.top = `${clamp(Number(pos.top), 8, Math.max(8, window.innerHeight - height - 8))}px`;
            host.style.right = 'auto';
            host.style.bottom = 'auto';
        } else {
            host.style.left = 'auto';
            host.style.top = 'auto';
            host.style.right = '24px';
            host.style.bottom = '24px';
        }
    };

    const loadSettings = async () => {
        const data = await storageGet([STORE.enabled, STORE.bubble, STORE.position, STORE.care, 'trcMonitorBalance', 'momoYongxuCvsAlert', 'momoRankSignals']);
        state.enabled = true;
        state.bubble = data[STORE.bubble] !== false;
        state.position = data[STORE.position] || null;
        careState = normalizeCareState(data[STORE.care]);
        lastOwnerInteractionAt = Number(careState.lastOwnerAt || Date.now());
        lastIdleWakeAt = Number(careState.lastIdleWakeAt || 0);
        ensurePet();
        renderTask(null);
        renderCarePanel();
        renderTrcBalance(data.trcMonitorBalance);
        if (isRankPage()) setRankSignalCache(data.momoRankSignals);
        applyPosition();
        applyVisibility();
        startCareTick();
        await storageSet({ [STORE.care]: careState });
        if (data[STORE.enabled] === false) void storageSet({ [STORE.enabled]: true });
        bootAutoScan();
        scheduleAutoScan(100);
        void restoreYongxuCvsAlert(data.momoYongxuCvsAlert);
    };
    window.__becPagePetRefresh = () => loadSettings().catch(() => {});

    if (runtimeApi.onMessage && typeof runtimeApi.onMessage.addListener === 'function') {
        runtimeApi.onMessage.addListener((message, sender, sendResponse) => {
            if (!message) return false;
            if (message.action === 'BEC_PET_UPDATE') {
                state.enabled = true;
                state.bubble = message.bubble !== false;
                ensurePet();
                applyPosition();
                applyVisibility();
                runAutoScanSafely().finally(() => sendResponse({ success: true }));
                return true;
            }
            if (message.action === 'BEC_PET_TASK') {
                const currentTask = detectOrderFromPage();
                if (!currentTask || (message.task?.no && currentTask.no !== message.task.no)) {
                    if (!currentTask) resetPresentedTasksForClosedModal();
                    renderTask(null);
                    concealPet();
                    sendResponse({ success: false, ignored: true });
                    return true;
                }
                showDetectedTask(currentTask).finally(() => sendResponse({ success: true }));
                return true;
            }
            if (message.action === 'BEC_PET_SAY') {
                if (message.kind === 'yongxu_cvs_abnormal') {
                    const alert = message.result && typeof message.result === 'object'
                        ? {
                            ...message.result,
                            abnormal: true,
                            orderNo: message.result.orderNo || message.orderNo,
                            orderNos: message.result.orderNos || message.orderNos || []
                        }
                        : { abnormal: true, orderNo: message.orderNo, orderNos: message.orderNos || [] };
                    showYongxuCvsAlert(alert, { forceVoice: true }).finally(() => sendResponse({ success: true }));
                    return true;
                }
                showAlert(String(message.text || '墨墨提醒。'), message.mood || 'alert', message.voice || null);
                sendResponse({ success: true });
                return true;
            }
            return false;
        });
    }

    if (storageEvents && typeof storageEvents.addListener === 'function') {
        storageEvents.addListener((changes, area) => {
            if (area !== 'local') return;
            let needsApply = false;
            if (changes[STORE.enabled]) { state.enabled = true; needsApply = true; }
            if (changes[STORE.bubble]) { state.bubble = changes[STORE.bubble].newValue !== false; needsApply = true; }
            if (changes[STORE.position]) { state.position = changes[STORE.position].newValue || null; needsApply = true; }
            if (changes[STORE.care]) {
                careState = normalizeCareState(changes[STORE.care].newValue);
                renderCarePanel();
            }
            if (needsApply) {
                ensurePet();
                applyPosition();
                applyVisibility();
                scheduleAutoScan(100);
            }
            if (changes.trcMonitorLastAlert && changes.trcMonitorLastAlert.newValue) {
                const alert = changes.trcMonitorLastAlert.newValue;
                showAlert(alert.text || 'TRC 入款提醒。', 'alert', alert.voiceKey ? { key: alert.voiceKey, text: alert.voiceText } : null);
            }
            if (changes.trcMonitorBalance) {
                renderTrcBalance(changes.trcMonitorBalance.newValue);
            }
            if (changes.momoYongxuCvsDismissedKey && activePersistentAlert?.key === changes.momoYongxuCvsDismissedKey.newValue) {
                clearYongxuCvsAlertIfActive();
                return;
            }
            if (changes.momoYongxuCvsAlert) {
                const alert = changes.momoYongxuCvsAlert.newValue;
                if (alert?.abnormal) restoreYongxuCvsAlert(alert).catch(() => {});
                else clearYongxuCvsAlertIfActive();
            }
            if (changes.momoRankSignals && isRankPage()) {
                setRankSignalCache(changes.momoRankSignals.newValue);
                scheduleAutoScan(250);
            }
        });
    }

    window.addEventListener('pointerdown', onPagePointerDown, { passive: true, capture: true });
    window.addEventListener('pointerdown', unlockVoicePlayback, { passive: true, capture: true });
    window.addEventListener('touchstart', unlockVoicePlayback, { passive: true, capture: true });
    window.addEventListener('keydown', unlockVoicePlayback, true);
    window.addEventListener('pointerup', onPagePointerUp, { passive: true, capture: true });
    window.addEventListener('pointercancel', () => {
        pointerInteractionActive = false;
        pauseScanningForUserCopy(500);
    }, { passive: true, capture: true });
    window.addEventListener('click', event => {
        if (!eventTouchesPet(event)) scheduleAutoScanBurst([900, 2200]);
    }, { passive: true, capture: true });
    window.addEventListener('pointermove', onPointerMove, { passive: true });
    window.addEventListener('blur', () => {
        pointerInteractionActive = false;
        host?.classList.remove('is-gaze-active');
        pauseScanningForUserCopy(500);
    }, { passive: true });
    window.addEventListener('wheel', () => pauseScanningForUserCopy(650), { passive: true, capture: true });
    window.addEventListener('scroll', () => pauseScanningForUserCopy(650), { passive: true, capture: true });
    window.addEventListener('momo-rank-sniffer-updated', () => {
        if (isRankPage()) scheduleAutoScan(180);
    }, { passive: true });
    document.addEventListener('input', event => {
        if (!eventTouchesPet(event)) pauseScanningForUserCopy(900);
    }, true);
    document.addEventListener('compositionstart', event => {
        if (!eventTouchesPet(event)) pauseScanningForUserCopy(1200);
    }, true);
    document.addEventListener('copy', () => pauseScanningForUserCopy(3000), true);
    document.addEventListener('cut', () => pauseScanningForUserCopy(3000), true);
    document.addEventListener('keydown', event => {
        if ((event.ctrlKey || event.metaKey) && String(event.key || '').toLowerCase() === 'c') {
            pauseScanningForUserCopy(3000);
            return;
        }
        if (isEditableEventTarget(event) || ['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'PageUp', 'PageDown', 'Home', 'End', 'Tab'].includes(event.key)) {
            pauseScanningForUserCopy(750);
        }
    }, true);
    document.addEventListener('visibilitychange', () => {
        pointerInteractionActive = false;
        if (document.visibilityState === 'hidden') {
            clearScheduledAutoScan();
            return;
        }
        interactionPauseUntil = Math.min(interactionPauseUntil, Date.now() + 220);
        scheduleAutoScan(280);
    });
    window.addEventListener('resize', () => {
        applyPosition();
        queueGazeUpdate();
    }, { passive: true });
    loadSettings().catch(() => {});
})();

