(() => {
    'use strict';

    const CVS_URL_RE = /^https:\/\/(?:www\.)?yongxu-pay\.com\/merchant\/query\/cvs(?:[/?#]|$)/i;
    if (!CVS_URL_RE.test(String(location.href || ''))) return;
    if (window.__momoYongxuCvsLoaded) return;
    window.__momoYongxuCvsLoaded = true;

    const STORE_LAST = 'momoYongxuCvsLast';
    const AFTER_REFRESH_SCAN_MS = 1400;
    const WAIT_TIMEOUT_MS = 8000;
    const REFRESH_TEXT_RE = /查詢|查询|搜尋|搜索|Search|Refresh|Reload|Query|刷新|更新|重新整理/i;
    const BAD_REFRESH_TEXT_RE = /匯出|导出|下載|下载|新增|创建|刪除|删除|修改|編輯|编辑|重置|Excel|Export|Download|Create|Delete|Edit|Reset/i;
    const ORDER_PATTERNS = [
        /\b7VSLCX[A-Z0-9]*\d{5,}\b/i,
        /\b[A-Z0-9]{4,}D\d{5,}\b/i,
        /\b[A-Z0-9]{8,}\d{5,}\b/i
    ];

    const clean = (value) => String(value || '').replace(/\s+/g, ' ').trim();
    const compact = (value) => clean(value).replace(/\s+/g, '');
    const sleep = (ms) => new Promise(resolve => window.setTimeout(resolve, ms));

    const storageSet = (payload) => new Promise(resolve => {
        try {
            chrome.storage.local.set(payload, () => {
                void chrome.runtime.lastError;
                resolve();
            });
        } catch (error) {
            resolve();
        }
    });

    const sendRuntimeMessage = (message) => new Promise(resolve => {
        try {
            chrome.runtime.sendMessage(message, response => {
                void chrome.runtime.lastError;
                resolve(response || {});
            });
        } catch (error) {
            resolve({});
        }
    });

    const isVisible = (el) => {
        if (!el || typeof el.getBoundingClientRect !== 'function') return false;
        const rect = el.getBoundingClientRect();
        const style = getComputedStyle(el);
        return rect.width > 0 && rect.height > 0 && style.display !== 'none' && style.visibility !== 'hidden';
    };

    const extractOrderNo = (text) => {
        const source = compact(text);
        for (const pattern of ORDER_PATTERNS) {
            const match = source.match(pattern);
            if (match && !/^FUN/i.test(match[0])) return match[0].toUpperCase();
        }
        return '';
    };

    const waitForCvsRows = (timeoutMs = WAIT_TIMEOUT_MS) => new Promise(resolve => {
        const startedAt = Date.now();
        let observer = null;
        let timer = 0;

        const finish = (ok) => {
            if (observer) observer.disconnect();
            window.clearTimeout(timer);
            resolve(Boolean(ok));
        };
        const hasRows = () => parseRows().length > 0;
        if (hasRows()) return finish(true);

        const root = document.querySelector('main, [role="main"], .app, #app, table') || document.body || document.documentElement;
        if (!root || typeof MutationObserver !== 'function') {
            timer = window.setTimeout(() => finish(hasRows()), Math.min(timeoutMs, 1500));
            return;
        }
        observer = new MutationObserver(() => {
            if (hasRows()) finish(true);
            else if (Date.now() - startedAt >= timeoutMs) finish(false);
        });
        observer.observe(root, { childList: true, subtree: true });
        timer = window.setTimeout(() => finish(hasRows()), timeoutMs);
    });

    const controlText = (el) => clean([
        el?.textContent || '',
        el?.value || '',
        el?.getAttribute?.('aria-label') || '',
        el?.getAttribute?.('title') || '',
        el?.getAttribute?.('placeholder') || ''
    ].join(' '));

    const isDisabledControl = (el) => {
        if (!el) return true;
        if (el.disabled || el.getAttribute?.('disabled') !== null || el.getAttribute?.('aria-disabled') === 'true') return true;
        return /\bdisabled\b|cursor-not-allowed|opacity-50/i.test(String(el.className || ''));
    };

    const findRefreshControl = () => {
        const controls = Array.from(document.querySelectorAll('button, a, [role="button"], input[type="button"], input[type="submit"]'))
            .filter(isVisible)
            .filter(el => !isDisabledControl(el))
            .map(el => {
                const text = controlText(el);
                if (!REFRESH_TEXT_RE.test(text) || BAD_REFRESH_TEXT_RE.test(text)) return null;
                let score = 1;
                if (/查詢|查询|Search|Query/i.test(text)) score += 3;
                if (/刷新|更新|重新整理|Refresh|Reload/i.test(text)) score += 2;
                if (el.closest?.('form')) score += 1;
                return { el, score };
            })
            .filter(Boolean)
            .sort((a, b) => b.score - a.score);
        return controls[0]?.el || null;
    };

    const headerIndexMap = (table) => {
        const headers = Array.from(table?.querySelectorAll('thead th, thead [role="columnheader"]') || []).map(th => clean(th.textContent));
        const find = (label) => headers.findIndex(text => text.includes(label));
        return {
            order: find('商戶訂單號'),
            system: find('系統訂單號'),
            created: find('建立時間'),
            amount: find('金額'),
            status: find('狀態')
        };
    };

    const tableRows = () => {
        const picked = [];
        const tables = Array.from(document.querySelectorAll('table')).filter(isVisible);
        for (const table of tables) {
            const rows = Array.from(table.querySelectorAll('tbody tr')).filter(isVisible);
            rows.filter(row => extractOrderNo(row.textContent)).forEach(row => picked.push({ table, row }));
        }
        return picked;
    };

    const fallbackRows = () => {
        const rows = Array.from(document.querySelectorAll('[role="row"], tr, .table-row, .grid-row'))
            .filter(isVisible)
            .filter(el => extractOrderNo(el.textContent));
        return rows.map(row => ({ table: row.closest('table'), row }));
    };

    const cellText = (cells, index) => index >= 0 && cells[index] ? clean(cells[index].textContent) : '';
    const parsePickedRow = (picked) => {
        const { table, row } = picked;
        const cells = Array.from(row.querySelectorAll('td, [role="cell"]')).filter(isVisible);
        const index = headerIndexMap(table);
        const rowText = clean(row.textContent);
        const orderText = cellText(cells, index.order) || cellText(cells, 4) || rowText;
        const orderNo = extractOrderNo(orderText);
        if (!orderNo) return null;
        const statusText = cellText(cells, index.status) || rowText;
        return {
            orderNo,
            systemOrderNo: extractOrderNo(cellText(cells, index.system)) || cellText(cells, index.system),
            createdAtText: cellText(cells, index.created) || cellText(cells, 1),
            amountText: cellText(cells, index.amount) || cellText(cells, 5),
            statusText,
            abnormal: /預約異常|abnormal/i.test(statusText) || /預約異常|abnormal/i.test(rowText),
            rowText,
            pageUrl: location.href,
            detectedAt: Date.now()
        };
    };

    function parseRows() {
        const pickedRows = tableRows();
        const fallback = pickedRows.length ? [] : fallbackRows();
        const seen = new Set();
        return [...pickedRows, ...fallback]
            .map(parsePickedRow)
            .filter(Boolean)
            .filter(row => {
                if (seen.has(row.orderNo)) return false;
                seen.add(row.orderNo);
                return true;
            });
    }

    const parseScanResult = () => {
        const rows = parseRows();
        if (!rows.length) return null;
        const latest = rows[0];
        const abnormalRows = rows.filter(row => row.abnormal);
        return {
            ...latest,
            rows,
            abnormalRows,
            abnormalCount: abnormalRows.length,
            orderNos: abnormalRows.map(row => row.orderNo),
            abnormal: abnormalRows.length > 0,
            detectedAt: Date.now()
        };
    };

    const scanNow = async (force = false) => {
        if (!document.body) return { success: false, error: 'DOCUMENT_NOT_READY' };
        if (!force) await waitForCvsRows(2500);
        const result = parseScanResult();
        if (!result) return { success: false, error: 'NO_LATEST_ROW' };
        await storageSet({ [STORE_LAST]: result });
        await sendRuntimeMessage({ action: 'YONGXU_CVS_SCAN_RESULT', result });
        return { success: true, result };
    };

    const triggerPageRefresh = async () => {
        if (document.visibilityState === 'hidden') return { refreshed: false, reason: 'HIDDEN' };
        const control = findRefreshControl();
        if (!control) return { refreshed: false, reason: 'NO_REFRESH_CONTROL' };
        control.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, view: window }));
        control.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true, view: window }));
        control.click();
        return { refreshed: true, text: controlText(control) };
    };

    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        if (!message || message.action !== 'YONGXU_CVS_SCAN_NOW') return false;
        (async () => {
            const refresh = await triggerPageRefresh().catch(error => ({
                refreshed: false,
                error: error && error.message || String(error)
            }));
            if (refresh.refreshed) {
                await sleep(AFTER_REFRESH_SCAN_MS);
                await waitForCvsRows(WAIT_TIMEOUT_MS);
            }
            const scanned = await scanNow(true);
            sendResponse({ ...scanned, refresh });
        })().catch(error => sendResponse({ success: false, error: error && error.message || String(error) }));
        return true;
    });

    const boot = () => {
        waitForCvsRows(WAIT_TIMEOUT_MS)
            .then(() => scanNow(false))
            .catch(() => {});
    };

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot, { once: true });
    else boot();
})();
