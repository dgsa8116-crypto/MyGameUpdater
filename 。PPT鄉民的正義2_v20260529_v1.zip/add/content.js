/**
 * content.js (Optimized)
 *
 * Per-tab worker script that drives the BEC member-info workflow:
 *   - SEARCH step: locate account, click "修改" to open detail page
 *   - EXTRACT step: read balance + payout, check limits, optionally disable account
 *
 * Key optimizations vs. original:
 *  - waitFor now uses MutationObserver (immediate response) + polling fallback
 *  - isVisible is cached per element via WeakMap during a single tick
 *  - Repeated DOM queries are cached (querySelectorAll batched per scan)
 *  - Removed dead `alreadyDisabled` declarations (line 326 + line 655 in original)
 *  - Single chrome.storage.local.get for full state (no double-read)
 *  - Pre-compiled regex constants pulled out of hot paths
 *  - Defensive try/catch around every external call boundary
 *  - Adaptive delay only persisted when material change (≥50ms)
 *  - All log() calls are fire-and-forget without awaiting
 */
(async function () {
    'use strict';
    if (window.hasRun) return;
    window.hasRun = true;

    /* ------------------------------------------------------------------ */
    /* Constants & utilities                                              */
    /* ------------------------------------------------------------------ */
    const MONEY_RE        = /^-?\s*[\d,]+(?:\.\d+)?$/;
    const NEGATIVE_WORD_RE = /輸|亏|虧|負|负/;
    const DATE_PREFIX_RE  = /^\d{4}[-/]\d{2}[-/]\d{2}/;
    const HREF_FROM_ONCLICK_RE = /location\.href\s*=\s*['"]([^'"]+)['"]/i;
    const WHITESPACE_RE   = /\s+/g;
    const DEFAULT_ADAPTIVE_DELAY = 800;
    const ADAPTIVE_DELAY_MIN  = 300;
    const ADAPTIVE_DELAY_MAX  = 2500;
    const ADAPTIVE_DELAY_CHANGE_THRESHOLD = 50;

    const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

    const now = () => new Date().toLocaleTimeString('zh-TW', { hour12: false });

    const log = (text) => {
        try {
            chrome.runtime.sendMessage({ action: 'DEBUG_LOG', text }).catch(() => {});
        } catch (_) {}
    };

    /* ------------------------------------------------------------------ */
    /* waitFor: MutationObserver-driven with poll fallback                */
    /* ------------------------------------------------------------------ */
    const STORAGE_STATE = await new Promise((resolve) => {
        try {
            chrome.storage.local.get(['adaptiveDelay'], (v) => {
                void chrome.runtime.lastError;
                resolve(v || {});
            });
        } catch (_) { resolve({}); }
    });
    let adaptiveDelay = Number(STORAGE_STATE.adaptiveDelay) || DEFAULT_ADAPTIVE_DELAY;

    const updateAdaptiveDelay = (elapsed) => {
        const newDelay = Math.max(
            ADAPTIVE_DELAY_MIN,
            Math.min(
                ADAPTIVE_DELAY_MAX,
                Math.floor(adaptiveDelay * 0.7 + Math.min(elapsed, ADAPTIVE_DELAY_MAX) * 0.3)
            )
        );
        if (Math.abs(newDelay - adaptiveDelay) > ADAPTIVE_DELAY_CHANGE_THRESHOLD) {
            adaptiveDelay = newDelay;
            try {
                chrome.storage.local.set({ adaptiveDelay: newDelay });
            } catch (_) {}
        }
    };

    const waitFor = (findFn, timeout = 12000) => new Promise((resolve) => {
        let done = false;
        let observer = null;
        let pollId = 0;
        let timeoutId = 0;
        const start = Date.now();

        const finish = (el) => {
            if (done) return;
            done = true;
            if (observer) { try { observer.disconnect(); } catch (_) {} }
            if (pollId)    clearInterval(pollId);
            if (timeoutId) clearTimeout(timeoutId);
            if (el) updateAdaptiveDelay(Date.now() - start);
            resolve(el || null);
        };

        // 1) Immediate check
        try {
            const el = findFn();
            if (el) return finish(el);
        } catch (_) { /* findFn may throw before DOM is ready */ }

        // 2) MutationObserver for fast reaction to DOM changes
        try {
            const root = document.body || document.documentElement;
            if (typeof MutationObserver === 'function' && root) {
                observer = new MutationObserver(() => {
                    try {
                        const el = findFn();
                        if (el) finish(el);
                    } catch (_) {}
                });
                observer.observe(root, {
                    childList: true,
                    subtree: true
                });
            }
        } catch (_) {}

        // 3) Poll fallback (covers cases where observer misses, e.g. style flips)
        pollId = setInterval(() => {
            try {
                const el = findFn();
                if (el) finish(el);
            } catch (_) {}
        }, 200);

        // 4) Overall timeout
        timeoutId = setTimeout(() => finish(null), timeout);
    });

    /* ------------------------------------------------------------------ */
    /* DOM helpers                                                        */
    /* ------------------------------------------------------------------ */
    const triggerNativeEvent = (el, type) => {
        if (!el) return;
        try { el.dispatchEvent(new Event(type, { bubbles: true, cancelable: true })); } catch (_) {}
    };

    // Visibility cache invalidates on each microtask (small window only)
    let visibilityCache = new WeakMap();
    let visibilityTick = 0;
    const ensureVisibilityCacheFresh = () => {
        const tick = (typeof performance !== 'undefined' && performance.now) ? Math.floor(performance.now() / 50) : Date.now();
        if (tick !== visibilityTick) {
            visibilityCache = new WeakMap();
            visibilityTick = tick;
        }
    };

    const isVisible = (el) => {
        if (!el) return false;
        ensureVisibilityCacheFresh();
        const cached = visibilityCache.get(el);
        if (cached !== undefined) return cached;

        // Walk up ancestors checking display/visibility
        let cur = el;
        let visible = true;
        while (cur && cur.nodeType === 1 && cur !== document.body) {
            const style = window.getComputedStyle(cur);
            if (style.display === 'none' || style.visibility === 'hidden') {
                visible = false;
                break;
            }
            cur = cur.parentElement;
        }
        if (visible) {
            const rect = el.getBoundingClientRect();
            visible = rect.width > 0 && rect.height > 0;
        }
        visibilityCache.set(el, visible);
        return visible;
    };

    const cleanText = (el) =>
        String((el && (el.innerText || el.textContent)) || '').replace(WHITESPACE_RE, ' ').trim();

    const looksLikeMoney = (text) =>
        MONEY_RE.test(String(text == null ? '' : text).trim());

    /* ------------------------------------------------------------------ */
    /* Result parsing                                                     */
    /* ------------------------------------------------------------------ */
    const parseMoney = (raw) => {
        if (raw === null || raw === undefined) return NaN;
        const text = String(raw).trim();
        const n = parseFloat(text.replace(/,/g, '').replace(/[^\d.-]/g, ''));
        if (!Number.isFinite(n)) return NaN;
        if (NEGATIVE_WORD_RE.test(text) && n > 0 && text.indexOf('-') === -1) return -n;
        return n;
    };

    const getLimitHit = (value, winLimitRaw, lossLimitRaw) => {
        const amount = Number(value);
        if (!Number.isFinite(amount) || amount === 0) return { hit: false, direction: '', limit: null, amount };
        const winLimit  = Number(winLimitRaw);
        const lossLimit = Number(lossLimitRaw);
        if (amount > 0 && Number.isFinite(winLimit) && winLimit > 0 && amount >= winLimit) {
            return { hit: true, direction: '贏', limit: winLimit, amount };
        }
        if (amount < 0 && Number.isFinite(lossLimit) && lossLimit > 0 && Math.abs(amount) >= lossLimit) {
            return { hit: true, direction: '輸', limit: lossLimit, amount };
        }
        return { hit: false, direction: '', limit: null, amount };
    };

    const limitHitText = (hit) =>
        hit && hit.hit
            ? String(hit.direction || '') + '達上限 ' + Number(hit.limit).toLocaleString()
            : '達上限';

    const updateResult = (resArr, acc, bal, pay, isExceeded = false, meta = {}) => {
        const t = now();
        const patch = { balance: bal, payout: pay, time: t, exceeded: isExceeded, ...meta };
        const idx = resArr.findIndex((r) => r.account === acc);
        if (idx !== -1) {
            resArr[idx] = { ...resArr[idx], ...patch };
        } else {
            resArr.push({ id: resArr.length + 1, account: acc, ...patch });
        }
        return resArr;
    };

    const findPayoutResult = () => {
        // Quick "no data" check (single scan over candidates)
        const candidatesForNoData = document.querySelectorAll('td, div, span');
        for (let i = 0; i < candidatesForNoData.length; i++) {
            const el = candidatesForNoData[i];
            if (cleanText(el).includes('查無資料') && isVisible(el)) {
                return { type: 'nodata', val: '查無資料' };
            }
        }

        const candidates = [];
        const tablesAll = document.querySelectorAll('table');
        for (let t = 0; t < tablesAll.length; t++) {
            const table = tablesAll[t];
            if (!isVisible(table)) continue;

            const rowsAll = table.querySelectorAll('tr');
            const rows = [];
            for (let r = 0; r < rowsAll.length; r++) {
                if (isVisible(rowsAll[r])) rows.push(rowsAll[r]);
            }
            if (!rows.length) continue;

            // Locate "輸贏" column
            let winLoseIdx = -1;
            for (let r = 0; r < rows.length && winLoseIdx < 0; r++) {
                const headerCells = rows[r].querySelectorAll('th,td');
                for (let c = 0; c < headerCells.length; c++) {
                    if (!isVisible(headerCells[c])) continue;
                    if (cleanText(headerCells[c]).includes('輸贏')) {
                        winLoseIdx = c;
                        break;
                    }
                }
            }

            const tableText = cleanText(table);
            const nearBox = table.closest('.panel, .box, .card, .tab-pane, .table-responsive, .content')
                            || table.parentElement;
            const nearText = cleanText(nearBox);
            const baseScore =
                (nearText.includes('派彩統計') ? 100 : 0) +
                (tableText.includes('總有效投注') ? 25 : 0) +
                (tableText.includes('派彩') ? 15 : 0);

            for (let r = 0; r < rows.length; r++) {
                const row = rows[r];
                const rowText = cleanText(row);
                if (!rowText.includes('總計')) continue;

                const cellNodes = row.querySelectorAll('td,th');
                const cells = [];
                const cellTexts = [];
                for (let i = 0; i < cellNodes.length; i++) {
                    if (!isVisible(cellNodes[i])) continue;
                    cells.push(cellNodes[i]);
                    cellTexts.push(cleanText(cellNodes[i]));
                }
                let val = '';
                if (winLoseIdx >= 0 && cellTexts[winLoseIdx]) {
                    val = cellTexts[winLoseIdx];
                } else if (cellTexts.length >= 5 && tableText.includes('總有效投注') && tableText.includes('派彩')) {
                    val = cellTexts[4];
                } else {
                    val = cellTexts[cellTexts.length - 1] || '';
                }
                if (looksLikeMoney(val)) {
                    candidates.push({ type: 'data', val, score: baseScore + (winLoseIdx >= 0 ? 30 : 0) });
                }
            }
        }

        if (!candidates.length) return null;
        candidates.sort((a, b) => b.score - a.score);
        return candidates[0];
    };

    /* ------------------------------------------------------------------ */
    /* Date / period helpers                                              */
    /* ------------------------------------------------------------------ */
    const normalizeDateRangeText = (raw) =>
        String(raw == null ? '' : raw).trim().replace('T', ' ');

    const readQueryDateRange = () => {
        const inputs = document.querySelectorAll('input');
        const dateInputs = [];
        for (let i = 0; i < inputs.length; i++) {
            const input = inputs[i];
            if (!isVisible(input)) continue;
            const key = String((input.name || '') + ' ' + (input.id || '') + ' ' + (input.className || '')).toLowerCase();
            const value = normalizeDateRangeText(input.value);
            if (key.includes('date') || DATE_PREFIX_RE.test(value)) {
                dateInputs.push(input);
            }
        }

        const findByKey = (patterns) => {
            for (let i = 0; i < dateInputs.length; i++) {
                const input = dateInputs[i];
                const key = String(
                    (input.name || '') + ' ' +
                    (input.id || '') + ' ' +
                    (input.placeholder || '') + ' ' +
                    (input.className || '')
                ).toLowerCase();
                for (let p = 0; p < patterns.length; p++) {
                    if (key.includes(patterns[p])) return input;
                }
            }
            return null;
        };

        const startInput = findByKey(['start', 'from', 'begin']) || dateInputs[0] || null;
        const endInput   = findByKey(['end', 'to', 'finish']) ||
                           dateInputs.find((input) => input !== startInput) || null;
        const start = normalizeDateRangeText(startInput && startInput.value);
        const end   = normalizeDateRangeText(endInput && endInput.value);
        return {
            start,
            end,
            label: start && end ? start + ' ~ ' + end : start ? start + ' ~ 目前' : ''
        };
    };

    const pad2 = (n) => String(n).padStart(2, '0');
    const toDateKey  = (d) => d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate());
    const toDateTimeLocal  = (d) => toDateKey(d) + ' ' + pad2(d.getHours()) + ':' + pad2(d.getMinutes());
    const toDateTimeSearch = (d) => toDateKey(d) + ' ' + pad2(d.getHours()) + ':' + pad2(d.getMinutes()) + ':00';

    const getCurrentPeriodStart = (resetRule) => {
        const anchorRaw = resetRule && resetRule.anchor;
        if (!anchorRaw) return null;
        const anchorDate = new Date(anchorRaw);
        if (Number.isNaN(anchorDate.getTime())) return null;
        const repeatWeekly = resetRule.repeatWeekly !== false;
        if (!repeatWeekly) return anchorDate;
        const nowDate = new Date();
        if (nowDate < anchorDate) return anchorDate;
        const stepMs = 7 * 24 * 60 * 60 * 1000;
        const diffMs = nowDate.getTime() - anchorDate.getTime();
        const weeks = Math.floor(diffMs / stepMs);
        return new Date(anchorDate.getTime() + weeks * stepMs);
    };

    const getPeriodKey = (periodStart, repeatWeekly) => {
        if (!periodStart) return 'default';
        return (repeatWeekly ? 'W:' : 'F:') + toDateKey(periodStart);
    };

    const normalizePoolId = (raw) =>
        String(raw == null ? '' : raw).trim().toUpperCase().replace(WHITESPACE_RE, '-');
    const accountKey = (name) => String(name == null ? '' : name).trim().toLowerCase();

    /* ------------------------------------------------------------------ */
    /* Account flow control                                               */
    /* ------------------------------------------------------------------ */
    const nextAccount = async (state, results, opts) => {
        const isForceTask = !!(opts && opts.isForceTask);

        if (state.parallelAuto) {
            const currentAccount =
                state.currentTaskAccount ||
                (state.accounts && state.accounts[0] && state.accounts[0].name) ||
                '';
            const currentKey = accountKey(currentAccount);

            // Find latest row for this account in the in-memory results
            let currentRow = null;
            if (Array.isArray(results)) {
                for (let i = results.length - 1; i >= 0; i--) {
                    if (accountKey(results[i] && results[i].account) === currentKey) {
                        currentRow = results[i];
                        break;
                    }
                }
            }

            const stored = await new Promise((resolve) => {
                try {
                    chrome.storage.local.get(['results'], (v) => resolve(v || {}));
                } catch (_) { resolve({}); }
            });
            const merged = Array.isArray(stored.results) ? stored.results.slice() : [];
            if (currentRow) {
                const idx = merged.findIndex((row) => accountKey(row && row.account) === currentKey);
                if (idx >= 0) merged[idx] = { ...merged[idx], ...currentRow };
                else merged.push(currentRow);
            }
            try {
                await new Promise((resolve) => {
                    chrome.storage.local.set({ results: merged, step: 'SEARCH' }, resolve);
                });
            } catch (_) {}

            try { sessionStorage.removeItem('BEC_AUTO_TASK'); } catch (_) {}
            try { sessionStorage.removeItem('BEC_AUTO_STEP'); } catch (_) {}

            try {
                chrome.runtime.sendMessage({
                    action: 'AUTO_TASK_DONE',
                    taskId: state.currentTaskId || '',
                    account: currentAccount
                }).catch(() => {});
            } catch (_) {}
            return;
        }

        const patch = { results, step: 'SEARCH' };
        if (isForceTask) {
            const queueState = await new Promise((resolve) => {
                try { chrome.storage.local.get(['forceDisableQueue'], (v) => resolve(v || {})); }
                catch (_) { resolve({}); }
            });
            const queue = Array.isArray(queueState.forceDisableQueue) ? queueState.forceDisableQueue.slice() : [];
            if (queue.length > 0) queue.shift();
            patch.forceDisableQueue = queue;
        } else {
            patch.currentIndex = (state.currentIndex || 0) + 1;
        }
        await new Promise((resolve) => {
            try { chrome.storage.local.set(patch, resolve); } catch (_) { resolve(); }
        });

        const currentUrlBase = window.location.href.split('?')[0];
        const targetUrlBase  = String(state.startUrl || '').split('?')[0];
        if (currentUrlBase === targetUrlBase) {
            window.location.reload();
        } else {
            window.location.href = state.startUrl;
        }
    };

    /* ------------------------------------------------------------------ */
    /* Main flow                                                          */
    /* ------------------------------------------------------------------ */
    const initialState = await new Promise((resolve) => {
        try { chrome.storage.local.get(null, (v) => resolve(v || {})); }
        catch (_) { resolve({}); }
    });

    let state = initialState;

    if (state.parallelAuto) {
        let task = null;
        try {
            task = JSON.parse(sessionStorage.getItem('BEC_AUTO_TASK') || 'null');
        } catch (_) { task = null; }

        if (!task || !task.account || !task.account.name) {
            const claim = await new Promise((resolve) => {
                try {
                    chrome.runtime.sendMessage({ action: 'CLAIM_AUTO_TASK' }, (response) => {
                        void chrome.runtime.lastError;
                        resolve(response || null);
                    });
                } catch (_) { resolve(null); }
            });
            if (!claim || !claim.success || !claim.account) return;

            task = {
                taskId: claim.taskId,
                account: claim.account,
                startUrl: claim.startUrl,
                autoConfig: claim.autoConfig
            };
            try {
                sessionStorage.setItem('BEC_AUTO_TASK', JSON.stringify(task));
                sessionStorage.setItem('BEC_AUTO_STEP', 'SEARCH');
            } catch (_) {}
        }

        state = {
            ...state,
            currentTaskId: task.taskId,
            currentTaskAccount: task.account.name,
            accounts: [task.account],
            currentIndex: 0,
            step: sessionStorage.getItem('BEC_AUTO_STEP') || 'SEARCH',
            startUrl: task.startUrl || state.startUrl || window.location.origin + '/index/user_info',
            autoConfig: task.autoConfig || state.autoConfig || {},
            forceDisableQueue: []
        };
    }

    const forceDisableQueue = Array.isArray(state.forceDisableQueue) ? state.forceDisableQueue : [];
    const normalDone =
        state.parallelAuto ? false : (state.currentIndex || 0) >= ((state.accounts && state.accounts.length) || 0);
    const hasForceTask = !state.parallelAuto && forceDisableQueue.length > 0;

    if (!state.isRunning || !state.accounts || (normalDone && !hasForceTask)) {
        if (state.isRunning && normalDone && !hasForceTask) {
            if (state.intervalMin > 0 && !state.isWaiting) {
                log('WAIT_' + state.intervalMin);
                try {
                    await new Promise((resolve) => chrome.storage.local.set({ isWaiting: true }, resolve));
                } catch (_) {}
                try {
                    chrome.runtime.sendMessage({ action: 'START_INTERVAL', minutes: state.intervalMin }).catch(() => {});
                } catch (_) {}
            } else if (!state.intervalMin && !state.isWaiting) {
                try { chrome.storage.local.set({ isRunning: false }); } catch (_) {}
                log('FINISH');
            }
        }
        return;
    }

    const isForceTask = state.parallelAuto
        ? !!(state.accounts && state.accounts[0] && state.accounts[0].forceDisableOnly)
        : hasForceTask;
    const accountObj = state.parallelAuto
        ? state.accounts[0]
        : (isForceTask ? forceDisableQueue[0] : state.accounts[state.currentIndex]);

    if (!accountObj || !accountObj.name) {
        await nextAccount(state, state.results || [], { isForceTask });
        return;
    }

    let results = state.results || [];
    const currentHref = window.location.href;
    const autoConfig = state.autoConfig || {};
    const fallbackAnchor =
        (autoConfig && autoConfig.resetRule && autoConfig.resetRule.anchor) || '';
    const effectiveAnchor = accountObj.resetAt || (accountObj.poolId ? fallbackAnchor : '') || '';
    const effectiveRepeatWeekly = accountObj.repeatWeekly !== false;
    const periodStart = effectiveAnchor
        ? getCurrentPeriodStart({ anchor: effectiveAnchor, repeatWeekly: effectiveRepeatWeekly })
        : null;
    const periodKey = getPeriodKey(periodStart, effectiveRepeatWeekly);
    const queryDate = periodStart ? toDateTimeSearch(periodStart) : (accountObj.date || '0');

    log('[' + accountObj.name + '] | ' + state.step + ' | ' +
        (periodStart ? toDateTimeLocal(periodStart) : '本週快捷(無重製時間)'));

    await waitFor(() => document.body);
    await sleep(adaptiveDelay);

    try {
        /* -------------- HOME page redirect to /index/user_info -------------- */
        if (currentHref.toLowerCase().includes('/index/home')) {
            let manageBtn = await waitFor(() => {
                const btn = document.querySelector('a[href="/index/user_info"]');
                return (btn && btn.offsetWidth > 0) ? btn : null;
            }, 3000);

            if (!manageBtn) {
                const memberMenu = await waitFor(() => {
                    const anchors = document.querySelectorAll('a[href="#"]');
                    for (let i = 0; i < anchors.length; i++) {
                        const txt = anchors[i].innerText || '';
                        if (txt.includes('會員') && !txt.includes('管理')) return anchors[i];
                    }
                    const icon = document.querySelector('i.fa-users');
                    return icon ? icon.closest('a') : null;
                }, 3000);

                if (memberMenu) {
                    memberMenu.click();
                    await waitFor(() => document.querySelector('a[href="/index/user_info"]'), 2000);
                }
                manageBtn = document.querySelector('a[href="/index/user_info"]');
            }

            const nextUrl = manageBtn
                ? (manageBtn.href || window.location.origin + '/index/user_info')
                : window.location.origin + '/index/user_info';
            try {
                await new Promise((resolve) => chrome.storage.local.set({ startUrl: nextUrl }, resolve));
            } catch (_) {}

            if (manageBtn) {
                manageBtn.click();
                const urlChanged = await waitFor(
                    () => !window.location.href.toLowerCase().includes('/index/home'),
                    2000
                );
                if (!urlChanged) window.location.href = nextUrl;
            } else {
                window.location.href = nextUrl;
            }
            return;
        }

        const isKnownPage =
            currentHref.toLowerCase().includes('/index/user_info') || state.step === 'EXTRACT';

        if (!isKnownPage) {
            log('[' + accountObj.name + '] SKIP_PAGE_ERR');
            await nextAccount(state, results, { isForceTask });
            return;
        }

        /* -------------- STEP: SEARCH -------------- */
        if (state.step === 'SEARCH') {
            const input     = await waitFor(() => document.querySelector('#UserAccount'));
            const searchBtn = await waitFor(() => document.querySelector('#ulbtn'));
            if (!input || !searchBtn) throw new Error('UI_ERR');

            input.value = accountObj.name;
            triggerNativeEvent(input, 'input');
            triggerNativeEvent(input, 'change');
            triggerNativeEvent(input, 'keyup');
            searchBtn.click();

            const accountNameLower = String(accountObj.name).toLowerCase();
            const modifyBtn = await waitFor(() => {
                const btns = document.querySelectorAll('button');
                for (let i = 0; i < btns.length; i++) {
                    const btn = btns[i];
                    const text = (btn.innerText || '').trim();
                    if (text !== '修改') continue;
                    const onclick = btn.getAttribute('onclick') || '';
                    if (onclick.indexOf('user_info') === -1) continue;
                    if (onclick.toLowerCase().indexOf(accountNameLower) === -1) continue;
                    return btn;
                }
                return null;
            }, 10000);

            if (modifyBtn) {
                if (state.parallelAuto) {
                    try { sessionStorage.setItem('BEC_AUTO_STEP', 'EXTRACT'); } catch (_) {}
                } else {
                    try {
                        await new Promise((resolve) => chrome.storage.local.set({ step: 'EXTRACT' }, resolve));
                    } catch (_) {}
                }
                const match = (modifyBtn.getAttribute('onclick') || '').match(HREF_FROM_ONCLICK_RE);
                if (match && match[1]) {
                    window.location.href = match[1].replace(/&amp;/g, '&');
                } else {
                    modifyBtn.click();
                }
            } else {
                log('[' + accountObj.name + '] NOT_FOUND');
                await nextAccount(state, results, { isForceTask });
            }
            return;
        }

        /* -------------- STEP: EXTRACT -------------- */
        if (state.step === 'EXTRACT') {
            let balanceStr = '0.00';
            let payoutStr  = '0';
            let hasData = false;
            let resultChecked = false;
            let queryRangeInfo = { start: '', end: '', label: '' };
            let weeklyPayoutStr = '';
            let weeklyPayoutNumber = null;
            let weeklyQueryRangeInfo = { start: '', end: '', label: '' };

            const accTab = await waitFor(() => document.querySelector('a[href="#account"]'));
            if (accTab) {
                accTab.click();
                const balEl = await waitFor(() => {
                    const el = document.querySelector('#totalBalanceValue');
                    return el && el.innerText && el.innerText.trim() !== '' ? el : null;
                }, 3000);
                if (balEl) balanceStr = balEl.innerText.trim();
            }

            const resTab = await waitFor(() => document.querySelector('a[href="#Result"]'));
            if (resTab) {
                resTab.click();

                await waitFor(() => {
                    if (document.querySelector('input[name="startDate"]')) return true;
                    const btns = document.querySelectorAll('button');
                    for (let i = 0; i < btns.length; i++) {
                        if ((btns[i].innerText || '').includes('本週')) return true;
                    }
                    return null;
                }, 3000);

                if (!queryDate || queryDate === '0') {
                    const weekBtn = await waitFor(() => {
                        const btns = document.querySelectorAll('button');
                        for (let i = 0; i < btns.length; i++) {
                            const b = btns[i];
                            if ((b.innerText || '').includes('本週') &&
                                (b.getAttribute('onclick') || '').includes('setDate')) return b;
                        }
                        return null;
                    }, 3000);
                    if (weekBtn) weekBtn.click();
                } else {
                    const dateInput = await waitFor(() => document.querySelector('input[name="startDate"]'), 3000);
                    const queryBtn  = await waitFor(() => document.querySelector('button.btn-submit[onclick*="uTResult"]'), 3000);
                    if (dateInput && queryBtn) {
                        dateInput.value = queryDate;
                        triggerNativeEvent(dateInput, 'input');
                        triggerNativeEvent(dateInput, 'change');
                        try {
                            dateInput.dispatchEvent(new KeyboardEvent('keydown', {
                                key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true
                            }));
                        } catch (_) {}
                        queryBtn.click();
                    }
                }

                await sleep(1200);
                queryRangeInfo = readQueryDateRange();
                const resultFound = await waitFor(() => findPayoutResult(), 10000);
                if (resultFound) {
                    resultChecked = true;
                    payoutStr = resultFound.val;
                    if (resultFound.type === 'data') hasData = true;
                }
            }

            const needsWeeklySnapshot =
                !!periodStart && !String(accountObj.poolId || '').trim() && !!accountObj.resetAt;
            if (needsWeeklySnapshot && hasData) {
                const weekBtn = await waitFor(() => {
                    const btns = document.querySelectorAll('button');
                    for (let i = 0; i < btns.length; i++) {
                        const b = btns[i];
                        if ((b.innerText || '').includes('本週') &&
                            (b.getAttribute('onclick') || '').includes('setDate')) return b;
                    }
                    return null;
                }, 3000);
                if (weekBtn) {
                    weekBtn.click();
                    await sleep(1200);
                    weeklyQueryRangeInfo = readQueryDateRange();
                    const weeklyFound = await waitFor(() => findPayoutResult(), 10000);
                    if (weeklyFound && weeklyFound.type === 'data') {
                        weeklyPayoutStr = weeklyFound.val;
                        const n = parseMoney(weeklyPayoutStr);
                        weeklyPayoutNumber = Number.isFinite(n) ? n : null;
                    }
                }
            }

            const payoutNum = parseMoney(payoutStr);
            const individualWinLimit  = Number(accountObj.winLimit ?? accountObj.limit);
            const individualLossLimit = Number(accountObj.lossLimit ?? accountObj.limit);
            const individualHit = getLimitHit(payoutNum, individualWinLimit, individualLossLimit);
            const individualExceeded = individualHit.hit;

            let poolExceeded = false;
            let poolSingleExceeded = false;
            let poolAlertText = '';
            let poolSingleAlertText = '';
            const poolId = normalizePoolId(accountObj.poolId);
            const poolWinLimit  = Number(accountObj.poolWinLimit ?? accountObj.poolLimit);
            const poolLossLimit = Number(accountObj.poolLossLimit ?? accountObj.poolLimit);
            const poolLimit = Math.max(
                Number.isFinite(poolWinLimit) ? poolWinLimit : 0,
                Number.isFinite(poolLossLimit) ? poolLossLimit : 0
            );
            const hasPoolLimit =
                (Number.isFinite(poolWinLimit)  && poolWinLimit  > 0) ||
                (Number.isFinite(poolLossLimit) && poolLossLimit > 0);
            const poolMode = accountObj.poolMode === 'hybrid' ? 'hybrid' : 'total';

            let nextPoolStatus = state.poolStatus || {};
            let nextForceMap = (state.poolForceMembers && typeof state.poolForceMembers === 'object')
                ? { ...state.poolForceMembers } : {};
            let nextForceQueue = Array.isArray(state.forceDisableQueue)
                ? state.forceDisableQueue.slice() : [];
            let forceChanged = false;

            const poolSingleHit = getLimitHit(payoutNum, poolWinLimit, poolLossLimit);
            if (poolId && poolMode === 'hybrid' && resultChecked && poolSingleHit.hit) {
                poolSingleExceeded = true;
                poolSingleAlertText = '共用池 ' + poolId + ' 方式1：單帳' + limitHitText(poolSingleHit);
            }

            if (!state.parallelAuto && poolId && hasPoolLimit && resultChecked) {
                const prevPool = nextPoolStatus[poolId];
                const members = (prevPool && prevPool.periodKey === periodKey &&
                                 prevPool.members && typeof prevPool.members === 'object')
                    ? { ...prevPool.members } : {};
                members[accountObj.name] = Number.isFinite(payoutNum) ? payoutNum : 0;

                const memberAccounts = (state.accounts || []).filter((acc) => {
                    const pid = normalizePoolId(acc && acc.poolId);
                    return pid === poolId && String((acc && acc.name) || '').trim();
                });
                const queriedMemberKeys = new Set(Object.keys(members).map(accountKey));
                const allPoolMembersQueried =
                    memberAccounts.length > 0 &&
                    memberAccounts.every((acc) => queriedMemberKeys.has(accountKey(acc && acc.name)));

                let total = 0;
                for (const v of Object.values(members)) {
                    const n = Number(v);
                    if (Number.isFinite(n)) total += n;
                }
                const poolTotalHit = getLimitHit(total, poolWinLimit, poolLossLimit);

                nextPoolStatus = {
                    ...nextPoolStatus,
                    [poolId]: {
                        periodKey, limit: poolLimit,
                        winLimit: poolWinLimit, lossLimit: poolLossLimit,
                        total, allQueried: allPoolMembersQueried,
                        mode: poolMode, members
                    }
                };

                poolExceeded = allPoolMembersQueried && poolTotalHit.hit;
                if (poolExceeded) {
                    poolAlertText = '共用池 ' + poolId + ' 全部查完，總和' +
                        limitHitText(poolTotalHit) + '，目前總和 ' + total.toLocaleString();

                    const queueKeySet = new Set(nextForceQueue.map((it) => accountKey(it && it.name)));
                    for (let i = 0; i < memberAccounts.length; i++) {
                        const memberAcc = memberAccounts[i];
                        const memberName = String((memberAcc && memberAcc.name) || '').trim();
                        if (!memberName) continue;
                        const key = accountKey(memberName);
                        if (!nextForceMap[key]) {
                            nextForceMap[key] = { poolId, reason: poolAlertText };
                            forceChanged = true;
                        }
                        if (memberName !== accountObj.name && !queueKeySet.has(key)) {
                            nextForceQueue.push({ ...memberAcc, forceDisableOnly: true });
                            queueKeySet.add(key);
                            forceChanged = true;
                        }
                    }
                } else if (!allPoolMembersQueried) {
                    log('[' + accountObj.name + '] POOL_WAIT_ALL ' + poolId);
                }

                try {
                    await new Promise((resolve) => chrome.storage.local.set({
                        poolStatus: nextPoolStatus,
                        currentPeriodKey: periodKey
                    }, resolve));
                } catch (_) {}
            }

            if (forceChanged) {
                try {
                    await new Promise((resolve) => chrome.storage.local.set({
                        poolForceMembers: nextForceMap,
                        forceDisableQueue: nextForceQueue
                    }, resolve));
                } catch (_) {}
            }

            const forceMeta = nextForceMap[accountKey(accountObj.name)];
            const forcedByPool = !!(forceMeta && normalizePoolId(forceMeta.poolId) === poolId);
            const forceReason = forcedByPool
                ? (forceMeta.reason || 'Pool ' + forceMeta.poolId + ' reached limit, group disable')
                : '';

            const isExceeded =
                individualExceeded || poolSingleExceeded || poolExceeded ||
                forcedByPool || !!accountObj.forceDisableOnly;

            if (hasData) {
                const resultMeta = {
                    poolId: poolId || '',
                    poolMode,
                    queryStart: queryRangeInfo.start || (periodStart ? toDateTimeSearch(periodStart) : ''),
                    queryEnd: queryRangeInfo.end || '',
                    queryRange: queryRangeInfo.label ||
                                (periodStart ? toDateTimeSearch(periodStart) + ' ~ 目前' : '本週'),
                    resetAt: effectiveAnchor || '',
                    periodStart: periodStart ? toDateTimeSearch(periodStart) : '',
                    isSharedPool: !!poolId,
                    resetPayout: payoutStr,
                    resetPayoutNumber: Number.isFinite(payoutNum) ? payoutNum : null,
                    weeklyPayout: weeklyPayoutStr,
                    weeklyPayoutNumber,
                    weeklyQueryRange: weeklyQueryRangeInfo.label || ''
                };
                results = updateResult(results, accountObj.name, balanceStr, payoutStr, isExceeded, resultMeta);
            } else {
                log('[' + accountObj.name + '] SKIP_NODATA');
            }

            if (individualExceeded)  log('[' + accountObj.name + '] INDIVIDUAL_LIMIT_HIT');
            if (poolSingleExceeded)  log('[' + accountObj.name + '] POOL_SINGLE_LIMIT_HIT ' + poolSingleAlertText);
            if (poolExceeded)        log('[' + accountObj.name + '] POOL_LIMIT_HIT ' + poolAlertText);
            if (forcedByPool || accountObj.forceDisableOnly) log('[' + accountObj.name + '] POOL_FORCE_DISABLE');

            const disabledKey = accountKey(accountObj.name);

            if (isExceeded) {
                log('[' + accountObj.name + '] EXCEEDED_LIMIT_START');
                try {
                    const infoTab = await waitFor(() => document.querySelector('a.nav-link[href="#account"]'), 3000);
                    if (infoTab) infoTab.click();
                    await sleep(1000);

                    const statusSelect = await waitFor(() => document.querySelector('select[name="ustatus"]'), 3000);
                    if (statusSelect) {
                        statusSelect.value = '0';
                        triggerNativeEvent(statusSelect, 'change');
                    }

                    const modifySubmitBtn = await waitFor(() => {
                        const btns = document.querySelectorAll('button[type="submit"]');
                        for (let i = 0; i < btns.length; i++) {
                            const b = btns[i];
                            if ((b.innerText || '').includes('修改') && b.offsetWidth > 0) return b;
                        }
                        return null;
                    }, 3000);
                    if (modifySubmitBtn) modifySubmitBtn.click();

                    const clickSwalBtn = async (btnText, timeout = 5000) => {
                        const btn = await waitFor(() => {
                            const btns = document.querySelectorAll('.swal2-confirm');
                            for (let i = 0; i < btns.length; i++) {
                                const b = btns[i];
                                if ((b.innerText || '').trim() === btnText && b.offsetWidth > 0) return b;
                            }
                            return null;
                        }, timeout);
                        if (btn) {
                            btn.click();
                            await sleep(1000);
                            return true;
                        }
                        return false;
                    };

                    await clickSwalBtn('確定', 5000);
                    await clickSwalBtn('OK', 5000);

                    const transferBtn = await waitFor(() => document.querySelector('button.totalAll'), 3000);
                    if (transferBtn) transferBtn.click();

                    await clickSwalBtn('確定', 5000);
                    await clickSwalBtn('OK', 15000);

                    const alertReason = [];
                    if (individualExceeded) alertReason.push('個人' + (payoutNum < 0 ? '輸' : '贏') + '達上限');
                    if (poolSingleExceeded) alertReason.push(poolSingleAlertText || '共用池單帳達上限');
                    if (poolExceeded)       alertReason.push(poolAlertText || '共用額度達上限');
                    if (!poolExceeded && forcedByPool) alertReason.push(forceReason || '共用池總和達上限');
                    const reasonText = alertReason.join(' / ') || '已達上限';
                    const alertMsg = '帳號 ' + accountObj.name + ' ' + reasonText + '，已停用並轉回主錢包，請前往查詢';

                    const storedData = await new Promise((resolve) => {
                        try {
                            chrome.storage.local.get(['disabledRecords', 'disabledAccounts'], (v) => resolve(v || {}));
                        } catch (_) { resolve({}); }
                    });
                    const disabledRecords = Array.isArray(storedData.disabledRecords) ? storedData.disabledRecords.slice() : [];
                    const latestDisabledAccounts =
                        (storedData.disabledAccounts && typeof storedData.disabledAccounts === 'object')
                            ? storedData.disabledAccounts : {};
                    const firstDisableNotice =
                        !latestDisabledAccounts[disabledKey] &&
                        !disabledRecords.some((it) => accountKey(it && it.account) === disabledKey);

                    const disabledAccountsToStore = { ...latestDisabledAccounts };
                    disabledAccountsToStore[disabledKey] = true;

                    const poolTotalNumber  = forceMeta && Number.isFinite(Number(forceMeta.poolTotalNumber))  ? Number(forceMeta.poolTotalNumber)  : null;
                    const poolLimitNumber  = forceMeta && Number.isFinite(Number(forceMeta.poolLimitNumber))  ? Number(forceMeta.poolLimitNumber)  : null;
                    const poolDirection    = forceMeta && forceMeta.poolDirection                            ? String(forceMeta.poolDirection)   : '';
                    const poolMemberCount  = forceMeta && Number.isFinite(Number(forceMeta.poolMemberCount)) ? Number(forceMeta.poolMemberCount)  : null;

                    const disabledRecord = {
                        account: accountObj.name,
                        payout: payoutStr,
                        payoutNumber: Number.isFinite(payoutNum) ? payoutNum : null,
                        resetPayout: payoutStr,
                        resetPayoutNumber: Number.isFinite(payoutNum) ? payoutNum : null,
                        weeklyPayout: weeklyPayoutStr,
                        weeklyPayoutNumber,
                        balance: balanceStr,
                        reason: reasonText,
                        poolId: poolId || '',
                        poolMode,
                        poolTotalNumber,
                        poolLimitNumber,
                        poolDirection,
                        poolMemberCount,
                        queryStart: queryRangeInfo.start || (periodStart ? toDateTimeSearch(periodStart) : ''),
                        queryEnd: queryRangeInfo.end || '',
                        queryRange: queryRangeInfo.label || (periodStart ? toDateTimeSearch(periodStart) + ' ~ 目前' : '本週'),
                        weeklyQueryRange: weeklyQueryRangeInfo.label || '',
                        time: new Date().toLocaleString('zh-TW', { hour12: false }),
                        at: new Date().toISOString()
                    };
                    const existingIdx = disabledRecords.findIndex((it) => accountKey(it.account) === disabledKey);
                    if (existingIdx >= 0) {
                        disabledRecords[existingIdx] = { ...disabledRecords[existingIdx], ...disabledRecord };
                    } else {
                        disabledRecords.push(disabledRecord);
                    }

                    try {
                        await new Promise((resolve) => chrome.storage.local.set({
                            disabledAccounts: disabledAccountsToStore,
                            disabledRecords
                        }, resolve));
                    } catch (_) {}

                    if (firstDisableNotice) {
                        try {
                            chrome.runtime.sendMessage({
                                action: 'SHOW_ALERT',
                                title: 'ALERT',
                                account: accountObj.name,
                                message: alertMsg
                            }).catch(() => {});
                        } catch (_) {}
                        log('[' + accountObj.name + '] EXCEEDED_LIMIT_ALERT_FIRST');
                    } else {
                        log('[' + accountObj.name + '] EXCEEDED_LIMIT_ALERT_SUPPRESSED');
                    }

                    log('[' + accountObj.name + '] EXCEEDED_LIMIT_DONE');
                } catch (ex) {
                    log('[' + accountObj.name + '] EXCEEDED_LIMIT_ERR: ' + (ex && ex.message || String(ex)));
                }
            }

            await nextAccount(state, results, { isForceTask });
        }
    } catch (error) {
        log('[' + accountObj.name + '] ERR: ' + (error && error.message || String(error)));
        await nextAccount(state, results, { isForceTask });
    }
})();
