(() => {
    if (window.__momoRankSnifferBridgeLoaded) return;
    window.__momoRankSnifferBridgeLoaded = true;

    const isRankPage = () => /(?:^|\/)rank(?:[/?#]|$)|rank/i.test(`${location.pathname || ''}${location.search || ''}${location.hash || ''}`);
    if (!isRankPage()) return;

    const injectMainSniffer = () => {
        try {
            if (!chrome?.runtime?.getURL) return;
            const script = document.createElement('script');
            script.src = chrome.runtime.getURL('rank-sniffer-main.js');
            script.async = false;
            script.onload = () => script.remove();
            script.onerror = () => script.remove();
            (document.documentElement || document.head || document.body)?.appendChild(script);
        } catch (error) {}
    };

    const MASKED_ACCOUNT_RE = /\b([a-z][a-z0-9_]{1,12})\*{2,}([a-z0-9_]{1,12})\b/ig;
    const ACCOUNT_RE = /^[a-z][a-z0-9_]{3,29}$/i;
    let knownAccounts = [];
    let lastApplyAt = 0;
    let lastSignalAt = 0;
    let lastSignalKey = '';

    const clean = (value) => String(value || '').replace(/\s+/g, ' ').trim();
    const storageSet = (payload) => new Promise(resolve => {
        try {
            chrome.storage.local.set(payload, () => {
                void chrome.runtime.lastError;
                resolve();
            });
        } catch (error) {
            resolve();
        }
    });
    const validAccount = (value) => {
        const text = clean(value);
        return ACCOUNT_RE.test(text) && /\d/.test(text) && !text.includes('*') ? text : '';
    };
    const mergeAccounts = (accounts) => {
        const seen = new Set(knownAccounts.map(account => account.toLowerCase()));
        for (const raw of accounts || []) {
            const account = validAccount(raw);
            const key = account.toLowerCase();
            if (account && !seen.has(key)) {
                knownAccounts.push(account);
                seen.add(key);
            }
        }
        knownAccounts = knownAccounts.slice(0, 300);
        return knownAccounts;
    };
    const matchMaskedAccount = (prefix, suffix) => {
        const p = String(prefix || '').toLowerCase();
        const s = String(suffix || '').toLowerCase();
        const matches = knownAccounts.filter(account => {
            const lower = account.toLowerCase();
            return lower.startsWith(p) && lower.endsWith(s) && lower.length > p.length + s.length;
        });
        return matches.length === 1 ? matches[0] : '';
    };
    const replaceMaskedText = (text) => String(text || '').replace(MASKED_ACCOUNT_RE, (token, prefix, suffix) => {
        const account = matchMaskedAccount(prefix, suffix);
        return account || token;
    });
    const applyRankReplacements = () => {
        const now = Date.now();
        if (!knownAccounts.length || now - lastApplyAt < 600) return 0;
        lastApplyAt = now;
        let changed = 0;
        const roots = Array.from(document.querySelectorAll('tbody tr, tr, [role="row"], li, .rank-item, .ranking-item, .list-group-item')).slice(0, 220);
        for (const root of roots) {
            if (!root || !root.textContent || !root.textContent.includes('***')) continue;
            const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
            let node;
            let scanned = 0;
            while ((node = walker.nextNode()) && scanned < 50) {
                scanned += 1;
                const before = node.nodeValue || '';
                if (!before.includes('***')) continue;
                const after = replaceMaskedText(before);
                if (after !== before) {
                    node.nodeValue = after;
                    changed += 1;
                }
            }
        }
        return changed;
    };
    const storeSignal = async (accounts, url, replaced) => storageSet({
        momoRankSignals: {
            accounts,
            sourceUrl: url || '',
            pageUrl: location.href,
            replaced,
            receivedAt: Date.now()
        }
    });
    const notifyRankUpdated = () => {
        try {
            window.dispatchEvent(new CustomEvent('momo-rank-sniffer-updated'));
        } catch (error) {}
    };

    if (!window.__momoRankSnifferMainLoaded) injectMainSniffer();

    window.addEventListener('message', event => {
        if (event.source !== window || event.origin !== location.origin) return;
        const data = event.data;
        if (!data || data.source !== 'momo-rank-sniffer' || data.type !== 'MOMO_RANK_SIGNAL') return;
        const incoming = Array.isArray(data.accounts) ? data.accounts : [];
        const signalKey = incoming.join('|').toLowerCase();
        const now = Date.now();
        if (signalKey && signalKey === lastSignalKey && now - lastSignalAt < 1200) return;
        lastSignalKey = signalKey;
        lastSignalAt = now;
        const beforeCount = knownAccounts.length;
        const accounts = mergeAccounts(incoming);
        const replaced = applyRankReplacements();
        const hasNewAccount = accounts.length !== beforeCount;
        if (!hasNewAccount && !replaced) return;
        void storeSignal(accounts, data.url || '', replaced);
        notifyRankUpdated();
        window.setTimeout(() => {
            const nextReplaced = applyRankReplacements();
            if (nextReplaced) {
                void storeSignal(accounts, data.url || '', nextReplaced);
                notifyRankUpdated();
            }
        }, 900);
    }, false);
})();
