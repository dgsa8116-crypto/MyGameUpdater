document.addEventListener('DOMContentLoaded', () => {
    // --- 導覽切換 ---
    const navBtns = document.querySelectorAll('.nav-btn');
    const tabPanes = document.querySelectorAll('.tab-pane');

    navBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            navBtns.forEach(b => b.classList.remove('active'));
            tabPanes.forEach(p => p.classList.remove('active'));
            btn.classList.add('active');
            const target = document.getElementById(btn.dataset.target);
            if (target) target.classList.add('active');
        });
    });

    // --- 複製功能 ---
    function copyToClipboard(text) {
        if (!text || text === "無資料") return;
        navigator.clipboard.writeText(text.trim()).then(() => {
            const toast = document.getElementById('toast');
            toast.classList.add('show');
            setTimeout(() => toast.classList.remove('show'), 1500);
        });
    }

    // ================= 原有一般功能綁定 =================
    document.getElementById('btn-copy-dep-combined').addEventListener('click', () => {
        copyToClipboard(`${document.getElementById('dep-no').value}\t${document.getElementById('dep-acc').value}\t${document.getElementById('dep-amt').value}`);
    });
    document.getElementById('btn-copy-dep-time-only').addEventListener('click', () => {
        copyToClipboard(document.getElementById('dep-time').value);
    });
    document.getElementById('btn-copy-wd-full-combined').addEventListener('click', () => {
        const d = new Date();
        const today = `${d.getFullYear()}/${String(d.getMonth()+1).padStart(2,'0')}/${String(d.getDate()).padStart(2,'0')}`;
        copyToClipboard(`${today}\t出款\t${document.getElementById('wd-no').value}\t${document.getElementById('wd-acc').value}\t\t${document.getElementById('wd-amt').value}`);
    });

    // ================= USDT 功能綁定 =================
    document.getElementById('btn-copy-usdt-dep-combined').addEventListener('click', () => {
        copyToClipboard(`${document.getElementById('usdt-dep-no').value}\t${document.getElementById('usdt-dep-acc').value}\t${document.getElementById('usdt-dep-amt').value}`);
    });
    document.getElementById('btn-copy-usdt-dep-time-only').addEventListener('click', () => {
        copyToClipboard(document.getElementById('usdt-dep-time').value);
    });
    document.getElementById('btn-copy-usdt-wd-combined').addEventListener('click', () => {
        const d = new Date();
        const today = `${d.getFullYear()}/${String(d.getMonth()+1).padStart(2,'0')}/${String(d.getDate()).padStart(2,'0')}`;
        copyToClipboard(`${today}\t出款\t${document.getElementById('usdt-wd-no').value}\t${document.getElementById('usdt-wd-acc').value}\t\t${document.getElementById('usdt-wd-amt').value}`);
    });

    // ================= 富鼎出 功能綁定 =================
    document.getElementById('btn-copy-fuding').addEventListener('click', () => {
        const no = document.getElementById('fd-no').value;
        const bName = document.getElementById('fd-bank-name').value;
        const bCode = document.getElementById('fd-bank-code').value;
        const acc = document.getElementById('fd-acc').value;
        const branch = document.getElementById('fd-branch').value;
        const amt = document.getElementById('fd-amt').value;

        const template = `【代付確認提單】\n交易編號 ${no}\n銀行名稱 ${bName}\n銀行代碼 ( ${bCode} )\n銀行帳號 ${acc}\n分行 ${branch}\n金額 ${amt}`;
        copyToClipboard(template);
    });

    // --- 資料讀取核心 ---
    async function handleFetch(statusId, type, isUsdt = false) {
        const statusEl = document.getElementById(statusId);
        statusEl.textContent = "SCANNING...";
        
        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            const results = await chrome.scripting.executeScript({
                target: { tabId: tab.id, allFrames: true },
                func: grabPageData,
                args: [type, isUsdt]
            });

            let data = { no: '', acc: '', amt: '', time: '', bankName: '', bankCode: '', branch: '' };
            results.forEach(res => {
                if (res.result) {
                    Object.keys(res.result).forEach(k => { 
                        if (res.result[k] && (!data[k] || data[k] === '')) data[k] = res.result[k]; 
                    });
                }
            });

            if (type === 'fuding') {
                document.getElementById('fd-no').value = data.no || '無資料';
                document.getElementById('fd-bank-name').value = data.bankName || '無資料';
                document.getElementById('fd-bank-code').value = data.bankCode || '無資料';
                document.getElementById('fd-acc').value = data.acc || '無資料';
                document.getElementById('fd-branch').value = data.branch || '無資料';
                document.getElementById('fd-amt').value = data.amt ? Number(data.amt).toLocaleString() : '無資料';
            } else {
                let p = '';
                if (type === 'deposit') p = isUsdt ? 'usdt-dep' : 'dep';
                else p = isUsdt ? 'usdt-wd' : 'wd';

                document.getElementById(`${p}-no`).value = data.no || '無資料';
                document.getElementById(`${p}-acc`).value = data.acc || '無資料';
                document.getElementById(`${p}-amt`).value = data.amt || '無資料';
                
                // 只有存款類需要賦值時間
                if (type === 'deposit') document.getElementById(`${p}-time`).value = data.time || '無資料';
            }

            statusEl.textContent = data.no ? "DATA UNLOCKED" : "DATA NOT FOUND";
            statusEl.style.color = data.no ? "#00ffaa" : "#ff4d4d"; // 讀取成功改為亮綠色提示
        } catch (e) {
            statusEl.textContent = "ERROR";
        }
    }

    // ================= 核心邏輯：注入網頁的抓取腳本 =================
    function grabPageData(type, isUsdt) {
        const tds = Array.from(document.querySelectorAll('td'));
        
        const getVal = (labels, isAmountField = false) => {
            for (let td of tds) {
                const txt = td.innerText.replace(/\s+/g, '');
                if (labels.some(l => txt === l || txt === l + ':' || txt === l + '：')) {
                    const next = td.nextElementSibling;
                    if (next && next.tagName === 'TD') {
                        let rawVal = next.innerText.trim();
                        
                        if (isAmountField) {
                            if (isUsdt) {
                                const usdtMatch = rawVal.match(/([\d,.]+)[^\d]*USDT/i);
                                if (usdtMatch) return usdtMatch[1].replace(/,/g, '');
                                continue;
                            } else {
                                if (rawVal.toUpperCase().includes('USDT')) {
                                    if (type === 'withdraw' || type === 'fuding') continue;
                                    const normalMatch = rawVal.match(/[\d,.]+/);
                                    return normalMatch ? normalMatch[0].replace(/,/g, '') : rawVal;
                                } else {
                                    const normalMatch = rawVal.match(/[\d,.]+/);
                                    return normalMatch ? normalMatch[0].replace(/,/g, '') : rawVal;
                                }
                            }
                        }
                        return rawVal;
                    }
                }
            }
            return '';
        };

        if (type === 'deposit') {
            // 【全面檢查優化】確保「一般存款」與「USDT存款」絕對優先抓取「存款時間」
            let targetTime = getVal(['存款時間']);
            
            // 如果真的沒有「存款時間」這四個字，才啟動備案
            if (!targetTime) targetTime = getVal(['申請日期']);
            if (!targetTime) targetTime = getVal(['時間']);

            return {
                no: getVal(['存款單號', '單號']),
                acc: getVal(['會員帳號', '帳號']),
                amt: getVal(['金額', '實際金額'], true),
                time: targetTime
            };
        } else if (type === 'withdraw') {
            return {
                no: getVal(['提款單號', '單號']),
                acc: getVal(['會員帳號', '帳號']),
                amt: getVal(['金額', '實際金額', '實際提領金額'], true)
            };
        } else if (type === 'fuding') {
            const rawBank = getVal(['銀行']); 
            let bankCode = '';
            let bankName = rawBank;
            
            const bankMatch = rawBank.match(/\(\s*(\d+)\s*\)\s*(.*)/);
            if (bankMatch) {
                bankCode = bankMatch[1];       
                bankName = bankMatch[2].trim(); 
            }

            return {
                no: getVal(['提款單號', '單號']),
                bankCode: bankCode,
                bankName: bankName,
                branch: getVal(['分行']),
                acc: getVal(['帳號']), 
                amt: getVal(['金額', '實際金額', '實際提領金額'], true)
            };
        }
    }

    // ================= 綁定所有抓取按鈕 =================
    document.getElementById('btn-fetch-deposit').addEventListener('click', () => handleFetch('dep-status', 'deposit', false));
    document.getElementById('btn-fetch-withdraw').addEventListener('click', () => handleFetch('wd-status', 'withdraw', false));
    
    document.getElementById('btn-fetch-usdt-dep').addEventListener('click', () => handleFetch('usdt-dep-status', 'deposit', true));
    document.getElementById('btn-fetch-usdt-wd').addEventListener('click', () => handleFetch('usdt-wd-status', 'withdraw', true));
    
    document.getElementById('btn-fetch-fuding').addEventListener('click', () => handleFetch('fuding-status', 'fuding', false));
});