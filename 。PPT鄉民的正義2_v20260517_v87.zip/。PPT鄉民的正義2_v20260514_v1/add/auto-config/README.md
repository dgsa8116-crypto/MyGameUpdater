﻿# Auto Config

這個資料夾放自動查詢設定檔。

- `default-auto-config.json`：第一次啟動時會自動讀取的預設值。
- popup 會把最新設定寫進 `chrome.storage.local.autoConfig`。
- 你可在 popup 使用「載入JSON / 匯出JSON」做版本管理。

## JSON 欄位

- `resetRule.anchor`：重製基準時間（`YYYY-MM-DDTHH:mm`，可留空；留空=不強制重製，走本週）
- `resetRule.repeatWeekly`：是否每週循環重製
- `sharedPools[].id`：共用池代號
- `sharedPools[].limitWan`：共用池額度（萬）
- `accounts[].name`：帳號
- `accounts[].poolId`：帳號所屬共用池
  - 可設為空字串 `""` 代表單獨帳號（不吃共用池）
- `accounts[].individualLimitWan`：帳號個人額度（萬，可選）
- `accounts[].resetAt`：該帳號的重製時間（`YYYY-MM-DDTHH:mm`，可選；有填才套用逐筆重製）

## 名單輸入簡化

- `帳號`：預設走共用池
- `帳號,SOLO`：單獨帳號（預設本週）
- `帳號,SOLO,8`：單獨帳號＋個人上限 8 萬
- `帳號,POOL-A,5,2026-05-17T23:15`：指定共用池＋上限＋逐筆重製時間
