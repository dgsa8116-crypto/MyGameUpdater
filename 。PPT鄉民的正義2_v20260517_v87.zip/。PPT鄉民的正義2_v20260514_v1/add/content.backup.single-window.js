﻿(async function() {
    if (window.hasRun) return;
    window.hasRun = true;

    const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

    const waitFor = async (findFn, timeout = 12000) => {
        const start = Date.now();
        let stateObj = await chrome.storage.local.get(['adaptiveDelay']);
        let currentDelay = stateObj.adaptiveDelay || 800;

        while (Date.now() - start < timeout) {
            const el = findFn();
            if (el) {
                const elapsed = Date.now() - start;
                let newDelay = Math.floor(currentDelay * 0.7 + Math.min(elapsed, 2500) * 0.3);
                newDelay = Math.max(300, Math.min(2500, newDelay));
                
                if (Math.abs(newDelay - currentDelay) > 50) {
                    chrome.storage.local.set({ adaptiveDelay: newDelay });
                }
                return el;
            }
            await sleep(200);
        }
        return null;
    };

    const triggerNativeEvent = (el, type) => {
        el.dispatchEvent(new Event(type, { bubbles: true, cancelable: true }));
    };

    const now = () => new Date().toLocaleTimeString('zh-TW', { hour12: false });

    const log = (text) => {
        chrome.runtime.sendMessage({ action: 'DEBUG_LOG', text }).catch(() => {});
    };

    const updateResult = (resArr, acc, bal, pay, isExceeded = false) => {
        const idx = resArr.findIndex(r => r.account === acc);
        const t = now();
        if (idx !== -1) {
            resArr[idx].balance = bal;
            resArr[idx].payout = pay;
            resArr[idx].time = t;
            resArr[idx].exceeded = isExceeded;
        } else {
            resArr.push({ id: resArr.length + 1, account: acc, balance: bal, payout: pay, time: t, exceeded: isExceeded });
        }
        return resArr;
    };

    const parseMoney = (raw) => {
        if (raw === null || raw === undefined) return NaN;
        const n = parseFloat(String(raw).replace(/,/g, '').replace(/[^\d.-]/g, ''));
        return Number.isFinite(n) ? n : NaN;
    };

    const pad2 = (n) => String(n).padStart(2, '0');
    const toDateSlash = (d) => `${d.getFullYear()}/${pad2(d.getMonth() + 1)}/${pad2(d.getDate())}`;
    const toDateKey = (d) => `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
    const toDateTimeLocal = (d) => `${toDateKey(d)} ${pad2(d.getHours())}:${pad2(d.getMinutes())}`;

    const getCurrentPeriodStart = (resetRule) => {
        const anchorRaw = resetRule?.anchor;
        const anchorDate = anchorRaw ? new Date(anchorRaw) : null;
        const anchor = (anchorDate && !Number.isNaN(anchorDate.getTime())) ? anchorDate : null;
        if (!anchor) return null;

        const repeatWeekly = resetRule?.repeatWeekly !== false;
        if (!repeatWeekly) return anchor;

        const nowDate = new Date();
        const stepMs = 7 * 24 * 60 * 60 * 1000;
        if (nowDate < anchor) return anchor;

        const diffMs = nowDate.getTime() - anchor.getTime();
        const weeks = Math.floor(diffMs / stepMs);
        return new Date(anchor.getTime() + weeks * stepMs);
    };

    const getPeriodKey = (periodStart, repeatWeekly) => {
        if (!periodStart) return 'default';
        return repeatWeekly ? `W:${toDateKey(periodStart)}` : `F:${toDateKey(periodStart)}`;
    };

    const normalizePoolId = (raw) => String(raw || '').trim().toUpperCase().replace(/\s+/g, '-');

    const nextAccount = async (state, results) => {
        await chrome.storage.local.set({
            results,
            currentIndex: state.currentIndex + 1,
            step: 'SEARCH'
        });

        const currentUrl = window.location.href.split('?')[0];
        const targetUrl  = state.startUrl.split('?')[0];

        if (currentUrl === targetUrl) {
            window.location.reload(true);
        } else {
            window.location.href = state.startUrl;
        }
    };

    chrome.storage.local.get(null, async (state) => {
        if (!state.isRunning || !state.accounts || state.currentIndex >= state.accounts.length) {
            if (state.isRunning && state.currentIndex >= state.accounts.length) {
                if (state.intervalMin > 0 && !state.isWaiting) {
                    log(`WAIT_${state.intervalMin}`);
                    await chrome.storage.local.set({ isWaiting: true });
                    chrome.runtime.sendMessage({ action: 'START_INTERVAL', minutes: state.intervalMin }).catch(() => {});
                } else if (!state.intervalMin && !state.isWaiting) {
                    chrome.storage.local.set({ isRunning: false });
                    log('FINISH');
                }
            }
            return;
        }

        const accountObj = state.accounts[state.currentIndex];
        let results = state.results || [];
        const currentHref = window.location.href;
        const autoConfig = state.autoConfig || {};
        const fallbackAnchor = autoConfig?.resetRule?.anchor || '';
        const effectiveAnchor = accountObj.resetAt || (accountObj.poolId ? fallbackAnchor : '') || '';
        const effectiveRepeatWeekly = accountObj.repeatWeekly !== false;
        const periodStart = effectiveAnchor ? getCurrentPeriodStart({ anchor: effectiveAnchor, repeatWeekly: effectiveRepeatWeekly }) : null;
        const periodKey = getPeriodKey(periodStart, effectiveRepeatWeekly);
        const queryDate = periodStart ? toDateSlash(periodStart) : (accountObj.date || '0');
        
        let adaptiveDly = state.adaptiveDelay || 800;

        log(`[${accountObj.name}] | ${state.step} | ${periodStart ? toDateTimeLocal(periodStart) : '本週快捷(無重製時間)'}`);

        await waitFor(() => document.body);
        await sleep(adaptiveDly); 

        try {
            if (currentHref.toLowerCase().includes('/index/home')) {
                let manageBtn = await waitFor(() => {
                    const btn = document.querySelector('a[href="/index/user_info"]');
                    return (btn && btn.offsetWidth > 0) ? btn : null;
                }, 3000);

                if (!manageBtn) {
                    const memberMenu = await waitFor(() => {
                        for (const a of document.querySelectorAll('a[href="#"]')) {
                            if (a.innerText.includes('會員') && !a.innerText.includes('管理')) return a;
                        }
                        const icon = document.querySelector('i.fa-users');
                        return icon ? icon.closest('a') : null;
                    }, 3000);

                    if (memberMenu) {
                        memberMenu.click();
                        await waitFor(() => document.querySelector('a[href="/index/user_info"]'), 2000);
                    }
                    manageBtn = document.querySelector('a[href="/index/user_info"]');
                }

                const nextUrl = manageBtn ? (manageBtn.href || window.location.origin + '/index/user_info') : window.location.origin + '/index/user_info';
                await chrome.storage.local.set({ startUrl: nextUrl });

                if (manageBtn) {
                    manageBtn.click();
                    const urlChanged = await waitFor(() => !window.location.href.toLowerCase().includes('/index/home'), 2000);
                    if (!urlChanged) window.location.href = nextUrl;
                } else {
                    window.location.href = nextUrl;
                }
                return;
            }

            const isKnownPage = currentHref.toLowerCase().includes('/index/user_info') || state.step === 'EXTRACT';

            if (!isKnownPage) {
                log(`[${accountObj.name}] SKIP_PAGE_ERR`);
                await nextAccount(state, results);
                return;
            }

            if (state.step === 'SEARCH') {
                const input     = await waitFor(() => document.querySelector('#UserAccount'));
                const searchBtn = await waitFor(() => document.querySelector('#ulbtn'));

                if (!input || !searchBtn) throw new Error('UI_ERR');

                input.value = accountObj.name;
                triggerNativeEvent(input, 'input');
                triggerNativeEvent(input, 'change');
                triggerNativeEvent(input, 'keyup');
                searchBtn.click();

                const modifyBtn = await waitFor(() => {
                    for (const btn of document.querySelectorAll('button')) {
                        const text = btn.innerText.trim();
                        const onclick = btn.getAttribute('onclick') || '';
                        if (text === '修改' && onclick.includes('user_info') && onclick.toLowerCase().includes(accountObj.name.toLowerCase())) {
                            return btn;
                        }
                    }
                    return null;
                }, 10000);

                if (modifyBtn) {
                    await chrome.storage.local.set({ step: 'EXTRACT' });
                    const match = (modifyBtn.getAttribute('onclick') || '').match(/location\.href\s*=\s*['"]([^'"]+)['"]/i);
                    if (match?.[1]) {
                        window.location.href = match[1].replace(/&amp;/g, '&');
                    } else {
                        modifyBtn.click();
                    }
                } else {
                    log(`[${accountObj.name}] NOT_FOUND`);
                    await nextAccount(state, results);
                }
            }
            else if (state.step === 'EXTRACT') {
                let balanceStr = '0.00';
                let payoutStr  = '0';
                let hasData = false;

                const accTab = await waitFor(() => document.querySelector('a[href="#account"]'));
                if (accTab) {
                    accTab.click();
                    const balEl = await waitFor(() => {
                        const el = document.querySelector('#totalBalanceValue');
                        return el && el.innerText.trim() !== '' ? el : null;
                    }, 3000);
                    if (balEl) balanceStr = balEl.innerText.trim();
                }

                const resTab = await waitFor(() => document.querySelector('a[href="#Result"]'));
                if (resTab) {
                    resTab.click();
                    
                    await waitFor(() => {
                        return document.querySelector('input[name="startDate"]') || Array.from(document.querySelectorAll('button')).find(b => b.innerText.includes('本週'));
                    }, 3000);

                    if (!queryDate || queryDate === '0') {
                        const weekBtn = await waitFor(() => {
                            for (const b of document.querySelectorAll('button')) {
                                if (b.innerText.includes('本週') && (b.getAttribute('onclick') || '').includes('setDate')) return b;
                            }
                            return null;
                        }, 3000);
                        if (weekBtn) weekBtn.click();
                    } else {
                        const dateInput = await waitFor(() => document.querySelector('input[name="startDate"]'), 3000);
                        const queryBtn = await waitFor(() => document.querySelector('button.btn-submit[onclick*="uTResult"]'), 3000);
                        if (dateInput && queryBtn) {
                            dateInput.value = queryDate;
                            triggerNativeEvent(dateInput, 'input');
                            triggerNativeEvent(dateInput, 'change');
                            const enterEvent = new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true });
                            dateInput.dispatchEvent(enterEvent);
                            queryBtn.click();
                        }
                    }

                    const resultFound = await waitFor(() => {
                        const noData = Array.from(document.querySelectorAll('td')).find(td => td.innerText.includes('查無資料') && td.offsetWidth > 0);
                        if (noData) return { type: 'nodata', val: '查無資料' };
                        
                        const boldEls = Array.from(document.querySelectorAll('td.text-right[style*="bold"]')).filter(td => td.offsetWidth > 0);
                        if (boldEls.length > 0) return { type: 'data', val: boldEls[boldEls.length - 1].innerText.trim() };

                        const trs = Array.from(document.querySelectorAll('tr')).filter(tr => tr.offsetWidth > 0 && tr.innerText.includes('總計'));
                        if (trs.length > 0) {
                            const tds = trs[trs.length - 1].querySelectorAll('td');
                            if (tds.length > 0) return { type: 'data', val: tds[tds.length - 1].innerText.trim() };
                        }

                        const rightTds = Array.from(document.querySelectorAll('td.text-right')).filter(td => td.offsetWidth > 0);
                        if (rightTds.length > 0) return { type: 'data', val: rightTds[rightTds.length - 1].innerText.trim() };
                        return null;
                    }, 8000);

                    if (resultFound) {
                        payoutStr = resultFound.val;
                        if (resultFound.type === 'data') {
                            hasData = true;
                        }
                    }
                }

                const payoutNum = parseMoney(payoutStr);
                const individualLimit = Number(accountObj.limit);
                const individualExceeded = Number.isFinite(individualLimit) && individualLimit > 0 && Number.isFinite(payoutNum) && payoutNum > 0 && payoutNum >= individualLimit;

                let poolExceeded = false;
                let poolAlertText = '';
                const poolId = normalizePoolId(accountObj.poolId);
                const poolLimit = Number(accountObj.poolLimit);
                let nextPoolStatus = state.poolStatus || {};

                if (poolId && Number.isFinite(poolLimit) && poolLimit > 0 && hasData) {
                    const prevPool = nextPoolStatus[poolId];
                    const members = (prevPool && prevPool.periodKey === periodKey && prevPool.members && typeof prevPool.members === 'object')
                        ? { ...prevPool.members }
                        : {};

                    if (Number.isFinite(payoutNum) && payoutNum > 0) {
                        members[accountObj.name] = payoutNum;
                    } else {
                        delete members[accountObj.name];
                    }

                    const total = Object.values(members).reduce((sum, v) => {
                        const n = Number(v);
                        return Number.isFinite(n) ? sum + n : sum;
                    }, 0);

                    nextPoolStatus = {
                        ...nextPoolStatus,
                        [poolId]: {
                            periodKey,
                            limit: poolLimit,
                            total,
                            members
                        }
                    };

                    poolExceeded = total >= poolLimit && poolLimit > 0;
                    if (poolExceeded) {
                        poolAlertText = `共用池 ${poolId} 已達上限 ${poolLimit.toLocaleString()}，目前 ${total.toLocaleString()}`;
                    }
                    await chrome.storage.local.set({ poolStatus: nextPoolStatus, currentPeriodKey: periodKey });
                }

                const isExceeded = individualExceeded || poolExceeded;

                if (hasData) {
                    results = updateResult(results, accountObj.name, balanceStr, payoutStr, isExceeded);
                } else {
                    log(`[${accountObj.name}] SKIP_NODATA`);
                }

                if (individualExceeded) {
                    log(`[${accountObj.name}] INDIVIDUAL_LIMIT_HIT`);
                }
                if (poolExceeded) {
                    log(`[${accountObj.name}] POOL_LIMIT_HIT ${poolAlertText}`);
                }

                if (isExceeded) {
                    log(`[${accountObj.name}] EXCEEDED_LIMIT_START`);
                    try {
                        const infoTab = await waitFor(() => document.querySelector('a.nav-link[href="#account"]'), 3000);
                        if (infoTab) infoTab.click();
                        await sleep(1000);

                        const statusSelect = await waitFor(() => document.querySelector('select[name="ustatus"]'), 3000);
                        if (statusSelect) {
                            statusSelect.value = "0";
                            triggerNativeEvent(statusSelect, 'change');
                        }

                        const modifySubmitBtn = await waitFor(() => {
                            const btns = Array.from(document.querySelectorAll('button[type="submit"]'));
                            return btns.find(b => b.innerText.includes('修改') && b.offsetWidth > 0);
                        }, 3000);
                        if (modifySubmitBtn) modifySubmitBtn.click();

                        const clickSwalBtn = async (btnText, timeout = 5000) => {
                            const btn = await waitFor(() => {
                                const btns = Array.from(document.querySelectorAll('.swal2-confirm'));
                                return btns.find(b => b.innerText.trim() === btnText && b.offsetWidth > 0);
                            }, timeout);
                            if (btn) {
                                btn.click();
                                await sleep(1000);
                                return true;
                            }
                            return false;
                        };

                        await clickSwalBtn('確定', 5000);
                        await clickSwalBtn('OK', 5000);

                        const transferBtn = await waitFor(() => document.querySelector('button.totalAll'), 3000);
                        if (transferBtn) transferBtn.click();

                        await clickSwalBtn('確定', 5000);
                        await clickSwalBtn('OK', 15000);

                        const alertReason = [];
                        if (individualExceeded) alertReason.push('個人額度達上限');
                        if (poolExceeded) alertReason.push(poolAlertText || '共用額度達上限');
                        const reasonText = alertReason.join(' / ') || '已達上限';
                        const alertMsg = `帳號 ${accountObj.name} ${reasonText}，已停用並轉回主錢包，請前往查詢`;

                        const storedData = await chrome.storage.local.get(['persistentAlerts']);
                        const pAlerts = storedData.persistentAlerts || [];
                        pAlerts.push(alertMsg);
                        await chrome.storage.local.set({ persistentAlerts: pAlerts });

                        chrome.runtime.sendMessage({
                            action: 'SHOW_ALERT',
                            title: 'ALERT',
                            account: accountObj.name,
                            message: alertMsg
                        }).catch(() => {});

                        log(`[${accountObj.name}] EXCEEDED_LIMIT_DONE`);
                    } catch (ex) {
                        log(`[${accountObj.name}] EXCEEDED_LIMIT_ERR: ${ex.message}`);
                    }
                }
                
                await nextAccount(state, results);
            }

        } catch (error) {
            log(`[${accountObj.name}] ERR: ${error.message}`);
            await nextAccount(state, results);
        }
    });
})();

